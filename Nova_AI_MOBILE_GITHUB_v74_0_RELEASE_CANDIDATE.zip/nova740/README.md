# Nova AI Mobile — v74.0 Release Candidate

This release candidate consolidates the Nova mobile foundation: AI brain, voice/wake flow, Android control, screen vision, WhatsApp confirmation flow, memory/task agent, remote mobile control, Nova Doctor, and security controls.

## Release gate
The APK is considered release-ready only after GitHub Actions successfully completes `:app:assembleDebug` and the APK artifact is downloaded and tested on a real Android device.

## Safety
Sensitive actions remain confirmation-gated. Remote credentials are stored locally using the app security layer.

## Version
- Version name: 74.0-RC1
- Version code: 82
