# Nova Mobile — GitHub Ready

This folder is the Android/mobile portion of Nova. It is prepared for GitHub Actions APK builds.

Build workflow: `.github/workflows/build-apk.yml`

Output: `app/build/outputs/apk/debug/app-debug.apk`


## IMPORTANT: GitHub ZIP upload
The ZIP itself is a package, not an Android-installable APK. GitHub Actions builds the APK from the extracted repository files.

### Easiest method
1. Download this ZIP.
2. Extract it.
3. Create an empty GitHub repository.
4. Upload the **contents of this extracted folder** to the repository root (including `.github/workflows/build-apk.yml`).
5. Open **Actions → Build Nova Android APK → Run workflow**.
6. Download the `nova-mobile-debug-apk` artifact and install the generated APK on Android.

### Why not upload the ZIP as one file?
A ZIP uploaded as `Nova.zip` is only a file in GitHub; GitHub Actions does not automatically treat its contents as the repository source, and the workflow inside that ZIP cannot start until a workflow exists in the repository.


## Fixed build configuration
- GitHub Actions uses JDK 17 and Gradle 8.11.1.
- Android Java and Kotlin JVM targets are both 17.
- Compose build features are enabled.
- Accessibility-service description is stored as an Android string resource.
- Fragment KTX is included because Nova uses FragmentActivity for biometric confirmation.

After uploading this project to GitHub, open **Actions → Build Nova Android APK → Run workflow**.
The generated APK is uploaded as the `nova-mobile-debug-apk` artifact.


## v73.4 Screen Vision
- Nova can capture the current visible Android screen after Accessibility is explicitly enabled.
- The screenshot is sent to the configured Gemini model for visual explanation.
- Password-like UI is not described by the vision system; keep sensitive screens closed when using cloud vision.
- Voice/text commands include: `screen samjho`, `screen explain`, `what is on my screen`.

## v73.5 Female Voice
Nova now prefers an available female/woman TTS voice for English and Urdu, with a slightly warm pitch and natural speech rate. Exact voice availability depends on the Android device/TTS engine and installed language packs.


### Voice v73.8
Enable Continuous Listening from the Nova Voice section. Say “Nova” or “نوا”; the wake recognizer alternates `en-US` and `ur-PK`. Manual Voice pauses wake listening to avoid microphone contention. Nova speech output pauses microphone recognition and resumes continuous listening after the reply.

## v74.0-RC1 — Nova Doctor + Security Center
Run the normal GitHub Actions `Build Nova APK` workflow. The APK version is 74.0-RC1 / build 81.
