@echo off
setlocal
cd /d "%~dp0"
echo ================================================
echo NOVA MOBILE - GITHUB UPLOAD HELPER
echo ================================================
echo.
where git >nul 2>nul
if errorlevel 1 (
  echo Git is not installed. Install Git for Windows first.
  pause
  exit /b 1
)
set /p REPO=Enter your GitHub repository URL (example: https://github.com/USER/nova-mobile.git):
if "%REPO%"=="" exit /b 1
if not exist .git git init
 git add .
 git commit -m "Nova Mobile v72.2 initial import"
 git branch -M main
 git remote remove origin >nul 2>nul
 git remote add origin "%REPO%"
 git push -u origin main
if errorlevel 1 (
  echo.
  echo Push failed. GitHub may require sign-in/token authentication.
  pause
  exit /b 1
)
echo.
echo Upload complete. Open GitHub Actions and run Build Nova Android APK.
pause
