package com.nova.mobile.control

import android.graphics.Bitmap
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Optional on-device OCR bridge for Nova. OCR is transient: recognized text is
 * returned to the caller and is not persisted by this class. Password-like
 * accessibility fields are excluded from the returned OCR regions.
 */
class NovaAndroidVision {
    data class OcrBlock(val text: String, val left: Int, val top: Int, val right: Int, val bottom: Int)
    data class OcrResult(val success: Boolean, val blocks: List<OcrBlock>, val message: String)

    fun recognize(bitmap: Bitmap, passwordRects: List<android.graphics.Rect> = emptyList(), callback: (OcrResult) -> Unit) {
        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        val delivered = AtomicBoolean(false)
        fun finish(result: OcrResult) {
            if (delivered.compareAndSet(false, true)) {
                recognizer.close()
                callback(result)
            }
        }
        recognizer.process(InputImage.fromBitmap(bitmap, 0))
            .addOnSuccessListener { result ->
                val blocks = result.textBlocks.flatMap { block ->
                    block.lines.mapNotNull { line ->
                        val box = line.boundingBox ?: return@mapNotNull null
                        if (passwordRects.any { Rects.overlap(box, it) }) return@mapNotNull null
                        val text = line.text.trim()
                        if (text.isBlank()) null else OcrBlock(text.take(300), box.left, box.top, box.right, box.bottom)
                    }
                }
                finish(OcrResult(true, blocks, "OCR complete: ${blocks.size} text regions."))
            }
            .addOnFailureListener { finish(OcrResult(false, emptyList(), "OCR failed: ${it.message ?: "unknown error"}")) }
    }

    private object Rects {
        fun overlap(a: android.graphics.Rect, b: android.graphics.Rect): Boolean =
            android.graphics.Rect.intersects(a, b)
    }
}
