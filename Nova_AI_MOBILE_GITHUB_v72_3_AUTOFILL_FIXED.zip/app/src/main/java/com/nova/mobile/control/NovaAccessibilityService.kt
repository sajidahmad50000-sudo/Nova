package com.nova.mobile.control

import android.accessibilityservice.AccessibilityService
import android.os.Bundle
import android.graphics.Bitmap
import java.io.File
import java.io.FileOutputStream
import android.view.accessibility.AccessibilityNodeInfo
import android.graphics.Rect
import java.util.Locale

/**
 * Explicit, user-enabled Android UI control bridge for Nova.
 * The service only acts on the currently visible accessibility tree and
 * cannot silently grant itself Android permissions.
 */
class NovaAccessibilityService : AccessibilityService() {
    companion object { var instance: NovaAccessibilityService? = null }

    override fun onServiceConnected() { super.onServiceConnected(); instance = this }
    override fun onAccessibilityEvent(event: android.view.accessibility.AccessibilityEvent?) { }
    override fun onInterrupt() { }
    override fun onDestroy() { if (instance === this) instance = null; super.onDestroy() }

    fun rootNode(): AccessibilityNodeInfo? = rootInActiveWindow

    fun clickText(text: String): Boolean = clickNode(findBest(rootInActiveWindow, text))

    fun clickNode(node: AccessibilityNodeInfo?): Boolean {
        if (node == null) return false
        if (node.isClickable && node.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
        var p = node.parent
        while (p != null) {
            if (p.isClickable && p.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            p = p.parent
        }
        return false
    }

    fun setText(text: String): Boolean = setTextOn(findEditable(rootInActiveWindow), text)

    fun setTextOn(target: String, text: String): Boolean = setTextOn(findEditable(rootInActiveWindow, target), text)

    fun setTextOnNode(node: AccessibilityNodeInfo?, text: String): Boolean = setTextOn(node, text)

    private fun setTextOn(node: AccessibilityNodeInfo?, text: String): Boolean {
        if (node == null) return false
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    fun back(): Boolean = performGlobalAction(GLOBAL_ACTION_BACK)
    fun home(): Boolean = performGlobalAction(GLOBAL_ACTION_HOME)
    fun recents(): Boolean = performGlobalAction(GLOBAL_ACTION_RECENTS)
    fun notifications(): Boolean = performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
    fun quickSettings(): Boolean = if (android.os.Build.VERSION.SDK_INT >= 31) performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS) else false
    fun lockScreen(): Boolean = if (android.os.Build.VERSION.SDK_INT >= 28) performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN) else false

    fun takeScreenshotToFile(onComplete: ((File?) -> Unit)? = null): Boolean {
        if (android.os.Build.VERSION.SDK_INT < 30) return false
        val dir = File(getExternalFilesDir(null), "screenshots").apply { mkdirs() }
        val out = File(dir, "Nova_${System.currentTimeMillis()}.png")
        val executor = java.util.concurrent.Executors.newSingleThreadExecutor()
        takeScreenshot(android.view.Display.DEFAULT_DISPLAY, executor, object : TakeScreenshotCallback {
            override fun onSuccess(result: ScreenshotResult) {
                var saved: File? = null
                try {
                    result.hardwareBuffer.use { hb ->
                        val bitmap = Bitmap.wrapHardwareBuffer(hb, result.colorSpace)
                        if (bitmap != null) {
                            FileOutputStream(out).use { stream -> bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream) }
                            bitmap.recycle()
                            if (out.exists() && out.length() > 0) saved = out
                        }
                    }
                } catch (_: Exception) { } finally {
                    executor.shutdown()
                    onComplete?.invoke(saved)
                }
            }
            override fun onFailure(errorCode: Int) {
                executor.shutdown()
                onComplete?.invoke(null)
            }
        })
        return true
    }

    fun scrollForward(target: String? = null): Boolean = scroll(target, AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)
    fun scrollBackward(target: String? = null): Boolean = scroll(target, AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD)

    data class VisualNode(
        val role: String,
        val label: String,
        val resourceId: String?,
        val boundsLeft: Int,
        val boundsTop: Int,
        val boundsRight: Int,
        val boundsBottom: Int,
        val clickable: Boolean,
        val editable: Boolean,
        val scrollable: Boolean,
        val enabled: Boolean
    )

    /** Structured visual/layout model derived from the current accessibility tree.
     * It exposes bounds and semantics for visual grounding without pretending to
     * have pixel-level OCR or image understanding when those engines are absent.
     */
    fun visualNodes(maxNodes: Int = 160): List<VisualNode> {
        val out = mutableListOf<VisualNode>()
        collectVisual(rootInActiveWindow, out, maxNodes)
        return out
    }

    fun visualScreenSummary(maxNodes: Int = 160): Map<String, Any> {
        val nodes = visualNodes(maxNodes)
        val clickable = nodes.count { it.clickable }
        val editable = nodes.count { it.editable }
        val scrollable = nodes.count { it.scrollable }
        return mapOf(
            "nodeCount" to nodes.size,
            "clickableCount" to clickable,
            "editableCount" to editable,
            "scrollableCount" to scrollable,
            "nodes" to nodes
        )
    }

    private fun collectVisual(node: AccessibilityNodeInfo?, out: MutableList<VisualNode>, max: Int) {
        if (node == null || out.size >= max) return
        if (node.isVisibleToUser) {
            val r = Rect()
            node.getBoundsInScreen(r)
            val label = listOfNotNull(
                node.text?.toString()?.takeIf { it.isNotBlank() },
                node.contentDescription?.toString()?.takeIf { it.isNotBlank() },
                node.hintText?.toString()?.takeIf { it.isNotBlank() }
            ).distinct().joinToString(" | ").take(160)
            if (label.isNotBlank() || node.isClickable || node.isEditable || node.isScrollable) {
                val role = node.className?.toString()?.substringAfterLast('.') ?: "Node"
                out += VisualNode(
                    role = role, label = label, resourceId = node.viewIdResourceName,
                    boundsLeft = r.left, boundsTop = r.top, boundsRight = r.right, boundsBottom = r.bottom,
                    clickable = node.isClickable, editable = node.isEditable, scrollable = node.isScrollable, enabled = node.isEnabled
                )
            }
        }
        for (i in 0 until node.childCount) collectVisual(node.getChild(i), out, max)
    }

    /** Returns a bounded, privacy-conscious summary of visible UI nodes. */
    fun visibleUi(maxNodes: Int = 120): List<String> {
        val out = mutableListOf<String>()
        walk(rootInActiveWindow, out, maxNodes, 0)
        return out
    }

    private fun walk(node: AccessibilityNodeInfo?, out: MutableList<String>, max: Int, depth: Int) {
        if (node == null || out.size >= max) return
        if (node.isVisibleToUser) {
            val label = listOfNotNull(
                node.text?.toString()?.takeIf { it.isNotBlank() },
                node.contentDescription?.toString()?.takeIf { it.isNotBlank() }
            ).joinToString(" | ")
            if (label.isNotBlank() || node.isClickable || node.isEditable || node.isScrollable) {
                val type = node.className?.toString()?.substringAfterLast('.') ?: "Node"
                out += "${"  ".repeat(depth)}$type: ${label.take(160)}"
            }
        }
        for (i in 0 until node.childCount) walk(node.getChild(i), out, max, depth + 1)
    }

    private fun scroll(target: String?, action: Int): Boolean {
        val root = rootInActiveWindow ?: return false
        val node = if (target.isNullOrBlank()) findScrollable(root) else findBest(root, target)
        return node?.performAction(action) == true
    }

    private fun findBest(node: AccessibilityNodeInfo?, query: String): AccessibilityNodeInfo? {
        if (node == null) return null
        val q = query.trim().lowercase(Locale.ROOT)
        val label = listOfNotNull(node.text?.toString(), node.contentDescription?.toString(), node.viewIdResourceName)
            .joinToString(" ").lowercase(Locale.ROOT)
        if (label == q || (label.contains(q) && (node.isClickable || node.isEditable || node.isScrollable))) return node
        for (i in 0 until node.childCount) findBest(node.getChild(i), query)?.let { return it }
        return null
    }

    private fun findEditable(node: AccessibilityNodeInfo?, target: String? = null): AccessibilityNodeInfo? {
        if (node == null) return null
        if (node.isEditable && node.isVisibleToUser && (target.isNullOrBlank() || matches(node, target))) return node
        for (i in 0 until node.childCount) findEditable(node.getChild(i), target)?.let { return it }
        return null
    }

    private fun findScrollable(node: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (node == null) return null
        if (node.isScrollable && node.isVisibleToUser) return node
        for (i in 0 until node.childCount) findScrollable(node.getChild(i))?.let { return it }
        return null
    }

    private fun matches(node: AccessibilityNodeInfo, query: String): Boolean {
        val q = query.lowercase(Locale.ROOT)
        return listOfNotNull(node.text?.toString(), node.hintText?.toString(), node.contentDescription?.toString(), node.viewIdResourceName)
            .any { it.lowercase(Locale.ROOT).contains(q) }
    }
}
