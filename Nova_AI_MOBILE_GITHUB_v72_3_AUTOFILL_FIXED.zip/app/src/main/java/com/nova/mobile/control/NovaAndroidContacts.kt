package com.nova.mobile.control

import android.content.ContentResolver
import android.content.Context
import android.provider.ContactsContract
import android.content.Intent
import android.net.Uri

class NovaAndroidContacts(private val context: Context) {
    private val resolver: ContentResolver get() = context.contentResolver
    fun search(query:String): AndroidControlResult {
        val rows=mutableListOf<Map<String,String>>()
        val projection=arrayOf(ContactsContract.Contacts._ID,ContactsContract.Contacts.DISPLAY_NAME,ContactsContract.Contacts.HAS_PHONE_NUMBER)
        resolver.query(ContactsContract.Contacts.CONTENT_URI,projection,"${ContactsContract.Contacts.DISPLAY_NAME} LIKE ?",arrayOf("%$query%"),ContactsContract.Contacts.DISPLAY_NAME+" ASC")?.use { c ->
            while(c.moveToNext()) {
                val id=c.getString(0); val name=c.getString(1) ?: ""; var phone=""
                resolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),"${ContactsContract.CommonDataKinds.Phone.CONTACT_ID}=?",arrayOf(id),null)?.use { p -> if(p.moveToFirst()) phone=p.getString(0) ?: "" }
                rows.add(mapOf("id" to id,"name" to name,"phone" to phone))
            }
        }
        return AndroidControlResult(true,true,"Contact search complete.",mapOf("contacts" to rows))
    }
    fun openContact(id:String): AndroidControlResult {
        return try { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.withAppendedPath(ContactsContract.Contacts.CONTENT_URI,id)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); AndroidControlResult(true,true,"Contact opened.") } catch(e:Exception){ AndroidControlResult(false,false,"Could not open contact: ${e.message}") }
    }
}
