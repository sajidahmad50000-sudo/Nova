package com.nova.mobile.control

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.util.UUID

class NovaAndroidCalendar(private val context: Context) {
    private val prefs = context.getSharedPreferences("nova_calendar", Context.MODE_PRIVATE)
    private val fmt = DateTimeFormatter.ISO_LOCAL_DATE_TIME

    private fun events(): JSONArray = try { JSONArray(prefs.getString("events", "[]") ?: "[]") } catch (_: Exception) { JSONArray() }
    private fun save(a: JSONArray) { prefs.edit().putString("events", a.toString()).apply() }

    fun parseDateTime(text: String): LocalDateTime? {
        val now = LocalDateTime.now(); val s=text.lowercase(Locale.ROOT)
        val base = when { s.contains("day after tomorrow") || s.contains("parson") -> now.plusDays(2); s.contains("tomorrow") || s.contains("kal") -> now.plusDays(1); else -> now }
        val m=Regex("(\\d{1,2})(?::(\\d{2}))?\\s*(am|pm)?", RegexOption.IGNORE_CASE).find(s) ?: return null
        var h=m.groupValues[1].toInt(); val min=m.groupValues[2].ifBlank { "0" }.toInt(); val ap=m.groupValues[3].lowercase()
        if (ap=="pm" && h!=12) h+=12; if (ap=="am" && h==12) h=0
        if (h !in 0..23 || min !in 0..59) return null
        return base.withHour(h).withMinute(min).withSecond(0).withNano(0)
    }

    fun create(title:String, whenText:String, confirmed:Boolean): AndroidControlResult {
        val dt=parseDateTime(whenText) ?: return AndroidControlResult(false,false,"Date/time samajh nahi aaya.")
        if (!confirmed) return AndroidControlResult(false,false,"${dt.format(DateTimeFormatter.ofPattern("dd MMM yyyy, hh:mm a"))} par '$title' event create karun? Confirm karein.",requiresUserAction=true)
        val a=events(); val o=JSONObject(); o.put("id",UUID.randomUUID().toString()); o.put("title",title.trim()); o.put("start",dt.format(fmt)); o.put("end",dt.plusHours(1).format(fmt)); a.put(o); save(a)
        return AndroidControlResult(true,true,"'$title' event create ho gaya.",mapOf("id" to o.getString("id"),"start" to o.getString("start")))
    }
    fun list(): AndroidControlResult { val a=events(); return AndroidControlResult(true,true,"Calendar events ready.",mapOf("events" to (0 until a.length()).map { a.getJSONObject(it).toMap() })) }
    fun search(q:String): AndroidControlResult { val a=events(); val out=mutableListOf<Map<String,Any?>>(); for(i in 0 until a.length()){ val o=a.getJSONObject(i); if(o.optString("title").contains(q,true)) out.add(o.toMap()) }; return AndroidControlResult(true,true,"Calendar search complete.",mapOf("events" to out)) }
    fun delete(id:String, confirmed:Boolean): AndroidControlResult { val a=events(); for(i in 0 until a.length()){ val o=a.getJSONObject(i); if(o.optString("id")==id){ if(!confirmed)return AndroidControlResult(false,false,"'${o.optString("title")}' event delete karun? Confirm karein.",requiresUserAction=true); a.remove(i); save(a); return AndroidControlResult(true,true,"Event delete ho gaya.") } }; return AndroidControlResult(false,false,"Event nahi mila.") }
    private fun JSONObject.toMap(): Map<String,Any?> = keys().asSequence().associateWith { opt(it) }
}
