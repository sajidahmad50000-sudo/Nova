package com.nova.mobile

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.fragment.app.FragmentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalContext
import com.nova.mobile.core.NovaConfigStore
import com.nova.mobile.data.NovaDatabase
import com.nova.mobile.health.NovaHealth
import com.nova.mobile.logging.NovaLogger
import org.json.JSONObject
import android.util.Base64
import com.nova.mobile.security.NovaSecureStore
import com.nova.mobile.security.NovaBiometricAuth
import com.nova.mobile.security.NovaQrPairing
import com.nova.mobile.control.NovaAccessibilityService
import com.nova.mobile.control.NovaAndroidCommandRouter
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec
import java.nio.charset.StandardCharsets
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

private fun b64(data: ByteArray): String = Base64.encodeToString(data, Base64.NO_WRAP or Base64.URL_SAFE)
private fun b64d(value: String): ByteArray = Base64.decode(value, Base64.NO_WRAP or Base64.URL_SAFE)
private fun secureEnvelope(secretB64: String, payload: JSONObject): JSONObject {
    val secret = b64d(secretB64)
    val nonce = ByteArray(12).also { SecureRandom().nextBytes(it) }
    val cipher = Cipher.getInstance("AES/GCM/NoPadding")
    cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(secret, "AES"), GCMParameterSpec(128, nonce))
    val encrypted = cipher.doFinal(payload.toString().toByteArray(StandardCharsets.UTF_8))
    return JSONObject().put("nonce", b64(nonce)).put("ciphertext", b64(encrypted))
}
private fun decryptEnvelope(secretB64: String, body: String): JSONObject {
    val env = JSONObject(body); val nonce = b64d(env.getString("nonce")); val encrypted = b64d(env.getString("ciphertext"))
    val cipher = Cipher.getInstance("AES/GCM/NoPadding")
    cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(b64d(secretB64), "AES"), GCMParameterSpec(128, nonce))
    return JSONObject(String(cipher.doFinal(encrypted), StandardCharsets.UTF_8))
}

private enum class NovaLang { ENGLISH, URDU, ROMAN }
private enum class NovaState { IDLE, APP_OPENED, WAITING_RECIPIENT, WAITING_MESSAGE, WAITING_LANGUAGE, WAITING_CONFIRMATION, WAITING_PHONE }

private data class NovaSession(
    var state: NovaState = NovaState.IDLE,
    var lang: NovaLang = NovaLang.ROMAN,
    var app: String = "",
    var recipient: String = "",
    var message: String = ""
)

class MainActivity : androidx.fragment.app.FragmentActivity() {
    private lateinit var tts: TextToSpeech
    private lateinit var db: NovaDatabase
    private lateinit var androidRouter: NovaAndroidCommandRouter

    private val voiceLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            ?.firstOrNull()?.let { onVoiceResult?.invoke(it) }
    }

    private var onVoiceResult: ((String) -> Unit)? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = NovaDatabase(applicationContext)
        androidRouter = NovaAndroidCommandRouter(applicationContext)
        NovaLogger.info(this, "Nova started; health=${NovaHealth.check(this).ok}")
        tts = TextToSpeech(this) { if (it == TextToSpeech.SUCCESS) tts.language = Locale.US }

        val permissions = mutableListOf<String>()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            permissions += Manifest.permission.RECORD_AUDIO
        }
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            permissions += Manifest.permission.CAMERA
        }
        if (android.os.Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            permissions += Manifest.permission.POST_NOTIFICATIONS
        }
        if (permissions.isNotEmpty()) {
            requestPermissions(permissions.toTypedArray(), 50)
        } else {
            startNovaWakeService()
        }

        val deviceId = Settings.Secure.getString(contentResolver, Settings.Secure.ANDROID_ID) ?: "unknown-device"
        setContent {
            NovaApp(
                deviceId = deviceId,
                startVoice = { callback ->
                    onVoiceResult = callback
                    val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ur-PK")
                        putExtra(RecognizerIntent.EXTRA_PROMPT, "Nova ko command bolain")
                    }
                    voiceLauncher.launch(intent)
                },
                speak = { speakNova(it) }
            )
        }
    }

    private fun startNovaWakeService() {
        if (android.os.Build.VERSION.SDK_INT >= 26) {
            androidx.core.content.ContextCompat.startForegroundService(this, Intent(this, NovaWakeService::class.java))
        } else {
            startService(Intent(this, NovaWakeService::class.java))
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 50 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startNovaWakeService()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        intent.getStringExtra("nova_wake_command")?.let { command ->
            if (command.isBlank()) speakNova("Ji, main sun rahi hoon.")
            else {
                val result = androidRouter.execute(command, confirmed = false)
                speakNova(result.message)
            }
        }
    }

    private fun speakNova(text: String) {
        val urdu = text.any { it in '\u0600'..'\u06FF' }
        tts.language = if (urdu) Locale("ur", "PK") else Locale.US
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "nova-response")
    }

    override fun onDestroy() {
        // Do not stop the foreground wake service here; it is intentionally independent of the UI lifecycle.
        NovaLogger.info(this, "Nova UI stopped")
        tts.stop()
        tts.shutdown()
        db.close()
        super.onDestroy()
    }
}

private data class AppTarget(val name: String, val packageName: String?, val fallbackUrl: String? = null)

private fun appTarget(text: String): AppTarget? {
    val t = text.lowercase()
    return when {
        listOf("whatsapp", "واٹس ایپ").any(t::contains) -> AppTarget("WhatsApp", "com.whatsapp", "https://wa.me/")
        listOf("youtube", "یوٹیوب").any(t::contains) -> AppTarget("YouTube", "com.google.android.youtube", "https://youtube.com")
        listOf("chrome", "browser", "کروم", "براؤزر").any(t::contains) -> AppTarget("Chrome", "com.android.chrome", "https://www.google.com")
        listOf("calculator", "calc", "کیلکولیٹر").any(t::contains) -> AppTarget("Calculator", null, "https://www.google.com/search?q=calculator")
        listOf("settings", "سیٹنگز").any(t::contains) -> AppTarget("Settings", null)
        listOf("camera", "کیمرہ").any(t::contains) -> AppTarget("Camera", null)
        else -> null
    }
}

private fun openTarget(activity: ComponentActivity, target: AppTarget) {
    try {
        when (target.name) {
            "Settings" -> activity.startActivity(Intent(Settings.ACTION_SETTINGS))
            "Camera" -> activity.startActivity(Intent("android.media.action.IMAGE_CAPTURE"))
            else -> {
                val launched = target.packageName?.let { pkg ->
                    activity.packageManager.getLaunchIntentForPackage(pkg)?.also(activity::startActivity)
                }
                if (launched == null) target.fallbackUrl?.let {
                    activity.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(it)))
                }
            }
        }
    } catch (e: Exception) {
        target.fallbackUrl?.let { activity.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(it))) }
    }
}

private fun langOf(text: String): NovaLang {
    if (Regex("[\\u0600-\\u06FF]").containsMatchIn(text)) return NovaLang.URDU
    val t = text.lowercase()
    if (listOf("what", "open", "send", "message", "english", "yes", "no", "how are you").any(t::contains)) return NovaLang.ENGLISH
    return NovaLang.ROMAN
}

private fun containsAny(text: String, words: List<String>) = words.any { text.contains(it, ignoreCase = true) }

private fun openingReply(app: String, l: NovaLang) = when (l) {
    NovaLang.ENGLISH -> "$app is open. What would you like me to do?"
    NovaLang.URDU -> "$app کھل گیا ہے۔ آپ کیا کرنا چاہتے ہیں؟"
    NovaLang.ROMAN -> "$app khul gaya hai. Kya karna hai?"
}

private fun askRecipient(l: NovaLang) = when (l) {
    NovaLang.ENGLISH -> "Who should I message?"
    NovaLang.URDU -> "کس کو پیغام بھیجنا ہے؟"
    NovaLang.ROMAN -> "Kis ko message bhejna hai?"
}

private fun askMessage(name: String, l: NovaLang) = when (l) {
    NovaLang.ENGLISH -> "What message should I send to $name?"
    NovaLang.URDU -> "$name کو کیا پیغام بھیجنا ہے؟"
    NovaLang.ROMAN -> "$name ko kya message bhejna hai?"
}

private fun askLanguage(l: NovaLang) = when (l) {
    NovaLang.ENGLISH -> "Should I write it in English, Urdu, or Roman Urdu?"
    NovaLang.URDU -> "پیغام English، اردو یا Roman Urdu میں لکھنا ہے؟"
    NovaLang.ROMAN -> "Message English, Urdu ya Roman Urdu mein likhna hai?"
}

private fun isYes(t: String) = containsAny(t, listOf("yes", "haan", "han", "جی", "ہاں", "ok", "okay", "bhej do", "send karo"))
private fun isNo(t: String) = containsAny(t, listOf("no", "nahi", "نہیں", "cancel", "mat bhejo"))
private fun isMessageIntent(t: String) = containsAny(t, listOf("message", "msg", "پیغام", "میسج"))

private fun extractRecipient(t: String): String? {
    val x = t.replace("\n", " ").trim()
    listOf(
        Regex("(?i)(?:to|ko)\\s+([A-Za-z][A-Za-z0-9_-]{1,30})"),
        Regex("([A-Za-z][A-Za-z0-9_-]{1,30})\\s+(?:ko|message)")
    ).forEach { p -> p.find(x)?.groupValues?.getOrNull(1)?.let { return it } }
    if (Regex("[\\u0600-\\u06FF]").containsMatchIn(x)) {
        Regex("(?:کو|کی طرف)\\s*([\\u0600-\\u06FF]{2,30})").find(x)?.groupValues?.getOrNull(1)?.let { return it }
    }
    return null
}

private fun normalizeUrdu(message: String): String = when (message.trim().lowercase()) {
    "kya haal hai", "kya hal hai" -> "کیا حال ہے؟"
    "kaise ho" -> "کیسے ہو؟"
    "kaisi ho" -> "کیسی ہو؟"
    "theek ho" -> "ٹھیک ہو؟"
    "shukriya" -> "شکریہ"
    "salam", "assalam o alaikum" -> "السلام علیکم"
    else -> message
}

private fun normalizeEnglish(message: String): String = when (message.trim().lowercase()) {
    "kya haal hai", "kya hal hai", "kaise ho" -> "How are you?"
    "shukriya" -> "Thank you"
    "salam" -> "Hello"
    else -> message
}

private fun toFinalMessage(message: String, l: NovaLang) = when (l) {
    NovaLang.URDU -> normalizeUrdu(message)
    NovaLang.ENGLISH -> normalizeEnglish(message)
    NovaLang.ROMAN -> message.trim()
}

private fun openWhatsAppWithText(activity: ComponentActivity, message: String, phone: String? = null) {
    val target = if (!phone.isNullOrBlank()) {
        "https://wa.me/${phone.filter(Char::isDigit)}?text=${Uri.encode(message)}"
    } else "https://wa.me/?text=${Uri.encode(message)}"
    activity.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(target)))
}

@Composable
fun NovaApp(deviceId: String, startVoice: (((String) -> Unit)) -> Unit, speak: (String) -> Unit) {
    val activity = LocalContext.current as FragmentActivity
    val context = LocalContext.current
    val db = remember { NovaDatabase(context.applicationContext) }
    val androidRouter = remember { NovaAndroidCommandRouter(context.applicationContext) }
    val config = remember { NovaConfigStore.load(context) }
    var pcIp by remember { mutableStateOf("") }
    var pcPort by remember { mutableStateOf(config.pcPort.toString()) }
    val secureStore = remember { NovaSecureStore(context) }
    var code by remember { mutableStateOf("") }
    var command by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("Ready") }
    var answer by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var pendingPcCommand by remember { mutableStateOf("") }
    var pendingPcChallenge by remember { mutableStateOf("") }
    var pendingAndroidCommand by remember { mutableStateOf("") }
    var session by remember { mutableStateOf(NovaSession()) }

    fun respond(text: String) {
        answer = "Nova: $text"
        db.saveConversation(session.lang.name, command, text)
        NovaLogger.info(context, "Response generated: ${text.take(100)}")
        speak(text)
    }

    fun sendToPc(input: String, confirmation: String = "") {
        if (pcIp.isBlank() || input.isBlank()) return
        val token = secureStore.token; val secret = secureStore.secret
        if (token.isNullOrBlank() || secret.isNullOrBlank()) { status = "Pair this device first"; return }
        busy = true; status = "Secure connection..."
        Thread {
            try {
                val c = URL("http://${pcIp.trim()}:${pcPort.toIntOrNull() ?: config.pcPort}/nova/command").openConnection() as HttpURLConnection
                c.requestMethod = "POST"; c.doOutput = true
                c.connectTimeout = config.requestTimeoutMs; c.readTimeout = config.requestTimeoutMs
                c.setRequestProperty("Content-Type", "application/json")
                c.setRequestProperty("X-Nova-Device", deviceId)
                c.setRequestProperty("X-Nova-Token", token)
                val request = JSONObject().put("action", "command").put("command", input)
                if (confirmation.isNotBlank()) request.put("confirmation", confirmation)
                c.outputStream.use { it.write(secureEnvelope(secret, request).toString().toByteArray()) }
                val body = c.inputStream.bufferedReader().readText(); c.disconnect()
                val msgJson = decryptEnvelope(secret, body)
                if (msgJson.optBoolean("confirmation_required")) {
                    val challenge = msgJson.optString("challenge")
                    activity.runOnUiThread { pendingPcCommand = input; pendingPcChallenge = challenge; answer = "Confirmation required. Say YES to allow this action or NO to cancel."; status = "Waiting for confirmation"; busy = false }
                    return@Thread
                }
                val msg = msgJson.optString("message", msgJson.toString())
                activity.runOnUiThread { answer = "Nova: $msg"; status = "Command accepted"; busy = false; speak(msg) }
            } catch (e: Exception) {
                NovaLogger.error(context, "Secure PC command failed", e)
                activity.runOnUiThread { answer = "Nova se secure connection nahi ho saka."; status = "Secure connection failed"; busy = false }
            }
        }.start()
    }

    fun handleLocal(input: String): Boolean {
        val text = input.trim()
        if (text.isBlank()) return true
        command = text
        if (pendingAndroidCommand.isNotBlank()) {
            if (isYes(text)) {
                val pending = pendingAndroidCommand
                pendingAndroidCommand = ""
                val result = androidRouter.execute(pending, confirmed = true)
                respond(result.message)
                return true
            }
            if (isNo(text)) {
                pendingAndroidCommand = ""
                respond("Okay, Android action cancelled.")
                return true
            }
            respond("Please say YES to confirm or NO to cancel.")
            return true
        }
        if (pendingPcChallenge.isNotBlank()) {
            if (isYes(text)) {
                val pcCommand = pendingPcCommand; val challenge = pendingPcChallenge
                NovaBiometricAuth.confirm(activity, "Confirm this protected Nova action") { approved ->
                    if (approved) {
                        pendingPcCommand = ""; pendingPcChallenge = ""
                        sendToPc(pcCommand, challenge)
                    } else {
                        pendingPcCommand = ""; pendingPcChallenge = ""
                        activity.runOnUiThread { respond("Biometric confirmation nahi mili. Action cancel kar diya.") }
                    }
                }
                return true
            }
            if (isNo(text)) {
                pendingPcCommand = ""; pendingPcChallenge = ""
                respond("Okay, action cancelled."); return true
            }
            respond("Please say YES to confirm or NO to cancel."); return true
        }
        val detected = langOf(text)
        session = session.copy(lang = detected)

        when (session.state) {
            NovaState.APP_OPENED -> if (isMessageIntent(text)) {
                val name = extractRecipient(text)
                session = if (name != null) session.copy(state = NovaState.WAITING_MESSAGE, recipient = name)
                else session.copy(state = NovaState.WAITING_RECIPIENT)
                respond(if (name != null) askMessage(name, session.lang) else askRecipient(session.lang))
                return true
            }
            NovaState.WAITING_RECIPIENT -> {
                session = session.copy(state = NovaState.WAITING_MESSAGE, recipient = text)
                respond(askMessage(text, session.lang)); return true
            }
            NovaState.WAITING_MESSAGE -> {
                session = session.copy(state = NovaState.WAITING_LANGUAGE, message = text)
                respond(askLanguage(session.lang)); return true
            }
            NovaState.WAITING_PHONE -> {
                val phone = text.filter(Char::isDigit)
                if (phone.length >= 10) {
                    openWhatsAppWithText(activity, session.message, phone)
                    respond("WhatsApp mein message tayyar hai. Check karke Send dabayein.")
                    session = NovaSession(lang = session.lang)
                } else respond("Please valid WhatsApp number batayein.")
                return true
            }
            NovaState.WAITING_LANGUAGE -> {
                val chosen = when {
                    containsAny(text, listOf("english", "انگلش")) -> NovaLang.ENGLISH
                    containsAny(text, listOf("urdu", "اردو")) -> NovaLang.URDU
                    containsAny(text, listOf("roman", "roman urdu")) -> NovaLang.ROMAN
                    else -> session.lang
                }
                val final = toFinalMessage(session.message, chosen)
                session = session.copy(state = NovaState.WAITING_CONFIRMATION, lang = chosen, message = final)
                respond(when (chosen) {
                    NovaLang.ENGLISH -> "Your message is ready: \"$final\". Shall I open WhatsApp with it?"
                    NovaLang.URDU -> "آپ کا پیغام تیار ہے: \"$final\"۔ کیا میں اسے WhatsApp میں تیار کر دوں؟"
                    NovaLang.ROMAN -> "Message tayyar hai: \"$final\". Kya WhatsApp mein tayyar kar doon?"
                }); return true
            }
            NovaState.WAITING_CONFIRMATION -> {
                if (isYes(text)) {
                    val phone = db.getContact(session.recipient) ?: ""
                    if (phone.isBlank()) {
                        session = session.copy(state = NovaState.WAITING_PHONE)
                        respond("${session.recipient} ka number save nahi hai. WhatsApp number batayein.")
                    } else {
                        openWhatsAppWithText(activity, session.message, phone)
                        respond("WhatsApp mein message tayyar hai. Check karke Send dabayein.")
                        session = NovaSession(lang = session.lang)
                    }
                    return true
                }
                if (isNo(text)) {
                    val l = session.lang
                    session = NovaSession(lang = l)
                    respond(if (l == NovaLang.URDU) "Theek hai, cancel kar diya." else "Okay, cancelled.")
                    return true
                }
            }
            else -> Unit
        }

        // Natural WhatsApp navigation example: "Ali ki chat kholo".
        val chat = Regex("(?i)^(.+?)\\s+(?:ki|ka)\\s+chat\\s+(?:kholo|khol|open)").find(text)
        if (chat != null && containsAny(text, listOf("chat", "whatsapp", "ki chat", "ka chat"))) {
            val name = chat.groupValues[1].trim()
            val accessChat = NovaAccessibilityService.instance
            if (accessChat == null) {
                respond("WhatsApp ki visible UI control ke liye Nova Accessibility Service enable karein.")
            } else {
                val ok = accessChat.clickText(name)
                if (ok) {
                    session = session.copy(state = NovaState.WAITING_MESSAGE, recipient = name)
                    respond("$name ki chat khol di. Kya message tayyar karna hai?")
                } else respond("$name ki visible WhatsApp chat nahi mili.")
            }
            return true
        }

        // Unified Android device/app/UI control. Protected actions are confirmed once.
        val androidResult = androidRouter.execute(text, confirmed = false)
        if (androidResult.success || androidResult.requiresUserAction || androidResult.message.startsWith("Yeh Android action")) {
            if (androidRouter.isHighImpact(text) && !androidResult.success) {
                pendingAndroidCommand = text
                respond(androidResult.message)
            } else {
                respond(androidResult.message)
            }
            return true
        }

        // Explicit Android UI control. Requires the user to enable Nova Accessibility Service.
        val access = NovaAccessibilityService.instance
        if (access != null) {
            if (containsAny(text, listOf("back", "go back", "peeche jao", "wapas jao", "پیچھے جاؤ"))) {
                val ok = access.back(); respond(if (ok) "Back ho gaya hai." else "Back action nahi ho saka."); return true
            }
            if (containsAny(text, listOf("home", "home screen", "ghar jao", "home par jao", "ہوم"))) {
                val ok = access.home(); respond(if (ok) "Home screen open kar di." else "Home action nahi ho saka."); return true
            }
            val click = Regex("(?i)^(?:click|press|tap|dabao|click karo|press karo)\\s+(.+)$").find(text)
            if (click != null) {
                val targetText = click.groupValues[1].trim()
                val ok = access.clickText(targetText)
                respond(if (ok) "'$targetText' par click kar diya." else "'$targetText' ka visible control nahi mila."); return true
            }
            val fillTarget = Regex("(?i)^(?:type|enter|likho|fill)\\s+(.+?)\\s+(?:in|into|mein|me)\\s+(.+)$").find(text)
            if (fillTarget != null) {
                val value = fillTarget.groupValues[1].trim()
                val target = fillTarget.groupValues[2].trim()
                val ok = access.setTextOn(target, value)
                respond(if (ok) "'$target' field fill kar di." else "'$target' ki visible field nahi mili."); return true
            }
            val fill = Regex("(?i)^(?:type|enter|likho|fill)\\s+(.+)$").find(text)
            if (fill != null) {
                val ok = access.setText(fill.groupValues[1].trim())
                respond(if (ok) "Text field fill kar di." else "Visible text field nahi mili."); return true
            }
            if (containsAny(text, listOf("recent apps", "recents", "recent kholo", "recent apps kholo"))) {
                val ok = access.recents(); respond(if (ok) "Recent apps open kar di." else "Recent apps open nahi ho sakin."); return true
            }
            if (containsAny(text, listOf("notifications", "notification kholo", "notifications kholo"))) {
                val ok = access.notifications(); respond(if (ok) "Notifications open kar di." else "Notifications open nahi ho sakin."); return true
            }
            if (containsAny(text, listOf("scroll down", "neeche scroll", "neeche karo", "scroll neeche"))) {
                val ok = access.scrollForward(); respond(if (ok) "Neeche scroll kar diya." else "Scroll nahi ho saka."); return true
            }
            if (containsAny(text, listOf("scroll up", "upar scroll", "upar karo", "scroll upar"))) {
                val ok = access.scrollBackward(); respond(if (ok) "Upar scroll kar diya." else "Scroll nahi ho saka."); return true
            }
            if (containsAny(text, listOf("screen read", "screen dekho", "screen par kya hai", "visible ui", "screen samjho"))) {
                val nodes = access.visibleUi(80)
                respond(if (nodes.isEmpty()) "Visible UI read nahi ho saki." else nodes.take(20).joinToString("\n"))
                return true
            }
        }
        if (containsAny(text, listOf("accessibility on", "accessibility enable", "nova accessibility", "accessibility service"))) {
            activity.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            respond("Android Accessibility Settings open kar di hain. Wahan Nova Accessibility Service enable karein.")
            return true
        }

        val target = appTarget(text)
        if (target != null && containsAny(text, listOf("open", "kholo", "khol", "کھولو", "کھول", "launch", "start", target.name))) {
            openTarget(activity, target)
            session = NovaSession(state = NovaState.APP_OPENED, lang = detected, app = target.name)
            respond(openingReply(target.name, detected))
            return true
        }
        return false
    }

    fun rotatePcToken() {
        val token = secureStore.token; val secret = secureStore.secret
        if (pcIp.isBlank() || token.isNullOrBlank() || secret.isNullOrBlank()) { status = "Pair this device first"; return }
        busy = true; status = "Rotating secure session..."
        Thread {
            try {
                val c = URL("http://${pcIp.trim()}:${pcPort.toIntOrNull() ?: config.pcPort}/nova/command").openConnection() as HttpURLConnection
                c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = config.requestTimeoutMs; c.readTimeout = config.requestTimeoutMs
                c.setRequestProperty("Content-Type", "application/json"); c.setRequestProperty("X-Nova-Device", deviceId); c.setRequestProperty("X-Nova-Token", token)
                c.outputStream.use { it.write(secureEnvelope(secret, JSONObject().put("action", "rotate_token")).toString().toByteArray()) }
                val body = c.inputStream.bufferedReader().readText(); c.disconnect(); val rotated = decryptEnvelope(secret, body)
                if (!rotated.optBoolean("ok")) throw IllegalStateException(rotated.optString("error", "Token rotation failed"))
                secureStore.token = rotated.getString("token"); secureStore.secret = rotated.getString("secret"); secureStore.role = rotated.optString("role", secureStore.role); secureStore.tokenExpiresAt = rotated.optLong("token_expires_at", 0L)
                activity.runOnUiThread { status = "Secure session rotated"; busy = false; speak("Secure session rotated") }
            } catch (e: Exception) { activity.runOnUiThread { status = "Token rotation failed"; busy = false; answer = e.message ?: "Rotation failed" } }
        }.start()
    }

    MaterialTheme {
        Surface(Modifier.fillMaxSize()) {
            Column(
                Modifier.padding(20.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("Nova AI", style = MaterialTheme.typography.headlineMedium)
                Text("Urdu • Roman Urdu • English", style = MaterialTheme.typography.titleMedium)
                Text("State: ${session.state}", style = MaterialTheme.typography.bodySmall)
                OutlinedTextField(pcIp, { pcIp = it }, label = { Text("PC IP address") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                OutlinedTextField(code, { code = it }, label = { Text("6-digit pairing code") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                Button(enabled = !busy && pcIp.isNotBlank() && code.length == 6, onClick = {
                    busy = true; status = "Pairing..."
                    Thread {
                        try {
                            val c = URL("http://${pcIp.trim()}:${pcPort.toIntOrNull() ?: config.pcPort}/nova/pair").openConnection() as HttpURLConnection
                            c.requestMethod = "POST"; c.doOutput = true
                            c.connectTimeout = config.requestTimeoutMs; c.readTimeout = config.requestTimeoutMs
                            c.setRequestProperty("Content-Type", "application/json")
                            c.outputStream.use {
                                it.write(JSONObject(mapOf("code" to code, "device_id" to deviceId, "device_name" to "Nova Android")).toString().toByteArray())
                            }
                            val body = c.inputStream.bufferedReader().readText(); c.disconnect()
                            val paired = JSONObject(body)
                            if (!paired.optBoolean("ok")) throw IllegalStateException(paired.optString("error", "Pairing failed"))
                            secureStore.token = paired.getString("token")
                            secureStore.secret = paired.getString("secret")
                            secureStore.role = paired.optString("role", "operator")
                            secureStore.tokenExpiresAt = paired.optLong("token_expires_at", 0L)
                            activity.runOnUiThread { status = "Securely paired (${secureStore.role})"; busy = false; speak("Mobile securely paired with Nova") }
                        } catch (e: Exception) {
                            NovaLogger.error(context, "Pairing failed", e)
                            activity.runOnUiThread { status = "Pairing failed"; answer = e.message ?: "Pairing error"; busy = false }
                        }
                    }.start()
                }, modifier = Modifier.fillMaxWidth()) { Text("Pair Mobile") }
                Button(enabled = !busy, onClick = {
                    NovaQrPairing.scan(context) { info ->
                        activity.runOnUiThread {
                            if (info == null) { status = "QR invalid or expired"; return@runOnUiThread }
                            pcIp = info.host; pcPort = info.port.toString(); code = info.code
                            status = "QR scanned — press Pair Mobile"
                        }
                    }
                }, modifier = Modifier.fillMaxWidth()) { Text("Scan Pairing QR") }

                HorizontalDivider()
                Text("Device ID: $deviceId")
                Text("Status: $status")
                Text("Role: ${secureStore.role} • Token: ${if (secureStore.tokenExpired()) "expired" else "active"}", style = MaterialTheme.typography.bodySmall)
                OutlinedTextField(
                    value = command,
                    onValueChange = { command = it },
                    label = { Text("Nova command") },
                    supportingText = { Text("Enter a command or use Voice") },
                    modifier = Modifier.fillMaxWidth().height(120.dp)
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(enabled = !busy && secureStore.token != null, onClick = { rotatePcToken() }, modifier = Modifier.weight(1f)) { Text("Rotate Token") }
                    Button(enabled = !busy, onClick = {
                        startVoice { spoken -> command = spoken; if (!handleLocal(spoken)) sendToPc(spoken) }
                    }, modifier = Modifier.weight(1f)) { Text("Voice") }
                    Button(enabled = !busy && command.isNotBlank(), onClick = {
                        if (!handleLocal(command)) sendToPc(command)
                    }, modifier = Modifier.weight(1f)) { Text("Send") }
                }
                if (answer.isNotBlank()) Card(Modifier.fillMaxWidth()) {
                    Text(answer, Modifier.padding(16.dp))
                }
                HorizontalDivider()
                Text("Health: ${if (NovaHealth.check(context).ok) "OK" else "CHECK REQUIRED"}")
                Text("Final WhatsApp Send user ke control mein rahega.", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}
