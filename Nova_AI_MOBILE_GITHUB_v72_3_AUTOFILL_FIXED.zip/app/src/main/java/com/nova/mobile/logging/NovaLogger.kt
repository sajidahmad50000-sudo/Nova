package com.nova.mobile.logging

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object NovaLogger {
    private const val FILE_NAME = "nova.log"
    private val lock = Any()

    fun info(context: Context, message: String) = write(context, "INFO", message, null)
    fun warn(context: Context, message: String) = write(context, "WARN", message, null)
    fun error(context: Context, message: String, error: Throwable? = null) = write(context, "ERROR", message, error)

    private fun write(context: Context, level: String, message: String, error: Throwable?) {
        synchronized(lock) {
            runCatching {
                val dir = File(context.filesDir, "logs").apply { mkdirs() }
                val file = File(dir, FILE_NAME)
                val stamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US).format(Date())
                val suffix = error?.let { " | ${it.javaClass.simpleName}: ${it.message}" } ?: ""
                file.appendText("$stamp [$level] $message$suffix\n")
                if (file.length() > 2_000_000) {
                    val backup = File(dir, "nova.log.1")
                    backup.delete()
                    file.renameTo(backup)
                }
            }
        }
    }
}
