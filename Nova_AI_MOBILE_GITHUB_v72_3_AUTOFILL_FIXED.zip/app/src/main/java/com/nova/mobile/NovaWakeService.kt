package com.nova.mobile

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.IBinder
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import java.util.Locale

class NovaWakeService : Service() {
    private var recognizer: SpeechRecognizer? = null
    @Volatile private var stopped = false
    private val channelId = "nova_wake"

    override fun onCreate() {
        super.onCreate()
        // Service is started only after a visible user permission flow in MainActivity.
        createChannel()
        startForeground(4101, notification("Nova wake listening is active"))
        startRecognition()
    }

    private fun startRecognition() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) return
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onResults(results: android.os.Bundle?) {
                    val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
                    val lower = text.trim().lowercase(Locale.ROOT)
                    val wake = lower.startsWith("nova ") || lower == "nova" || lower.startsWith("نوا ") || lower == "نوا"
                    if (wake) {
                        val command = text.trim().replaceFirst(Regex("^(nova|نوا)[,:\\-]?\\s*", RegexOption.IGNORE_CASE), "").trim()
                        val intent = Intent(this@NovaWakeService, MainActivity::class.java).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                            putExtra("nova_wake_command", command)
                        }
                        startActivity(intent)
                    }
                    restartRecognition()
                }
                override fun onError(error: Int) { restartRecognition() }
                override fun onReadyForSpeech(params: android.os.Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(partialResults: android.os.Bundle?) {}
                override fun onEvent(eventType: Int, params: android.os.Bundle?) {}
            })
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-US")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        }
        recognizer?.startListening(intent)
    }

    private fun restartRecognition() {
        recognizer?.cancel()
        android.os.Handler(mainLooper).postDelayed({ if (!stopped) startRecognition() }, 350)
    }

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(channelId, "Nova Wake Service", NotificationManager.IMPORTANCE_LOW))
    }

    private fun notification(text: String): Notification =
        Notification.Builder(this, channelId)
            .setContentTitle("Nova AI")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .build()

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (android.os.Build.VERSION.SDK_INT >= 29) {
            // The service is declared as microphone foreground service in the manifest.
        }
        return START_STICKY
    }
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        stopped = true
        recognizer?.destroy()
        recognizer = null
        super.onDestroy()
    }
}
