package com.nova.mobile.control

import android.os.CancellationSignal
import android.service.autofill.AutofillService
import android.service.autofill.FillCallback
import android.service.autofill.FillRequest
import android.service.autofill.SaveCallback
import android.service.autofill.SaveRequest

/**
 * Optional Android Autofill bridge. Nova supplies only credentials the user
 * has explicitly stored and selected. Passwords are never spoken by Nova.
 * Full credential selection UI is intentionally left to Android's Autofill UX.
 */
class NovaAutofillService : AutofillService() {
    override fun onFillRequest(
        request: FillRequest,
        cancellationSignal: CancellationSignal,
        callback: FillCallback
    ) {
        // No stored credentials are exposed automatically.
        // Returning null tells Android that Nova has no dataset for this request.
        callback.onSuccess(null)
    }

    override fun onSaveRequest(
        request: SaveRequest,
        callback: SaveCallback
    ) {
        // Credential persistence is intentionally handled elsewhere.
        callback.onSuccess()
    }
}
