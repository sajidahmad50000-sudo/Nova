package com.nova.mobile.control

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Environment
import androidx.documentfile.provider.DocumentFile
import androidx.core.content.FileProvider
import java.io.File
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * Android file operations. App workspace is always available; broader storage uses
 * a user-granted Storage Access Framework tree URI. Destructive operations are gated.
 */
class NovaAndroidFileManager(private val context: Context) {
    private val prefs = context.getSharedPreferences("nova_file_manager", Context.MODE_PRIVATE)
    private val workspace: File get() = File(context.filesDir, "NovaWorkspace").apply { mkdirs() }

    fun requestFolderAccess(): AndroidControlResult {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        return try {
            context.startActivity(intent)
            AndroidControlResult(false, false, "Choose the folder you want Nova to manage. Access will be saved after you approve it.", requiresUserAction = true)
        } catch (e: Exception) { AndroidControlResult(false, false, "Folder access picker nahi khul saka: ${e.message}") }
    }

    fun rememberTree(uri: Uri): AndroidControlResult {
        return try {
            context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            prefs.edit().putString("tree_uri", uri.toString()).apply()
            AndroidControlResult(true, true, "Folder access saved.", mapOf("uri" to uri.toString()))
        } catch (e: Exception) { AndroidControlResult(false, false, "Folder access save nahi ho saka: ${e.message}") }
    }

    fun search(query: String): AndroidControlResult {
        val q = query.lowercase(Locale.ROOT)
        val out = mutableListOf<Map<String, Any?>>()
        fun walk(f: File) {
            if (out.size >= 100) return
            val children = runCatching { f.listFiles().orEmpty() }.getOrDefault(emptyArray())
            for (x in children) {
                if (x.name.lowercase(Locale.ROOT).contains(q)) out += metadata(x)
                if (x.isDirectory) walk(x)
                if (out.size >= 100) return
            }
        }
        walk(workspace)
        return AndroidControlResult(true, true, "${out.size} matching items found.", mapOf("items" to out, "scope" to "Nova workspace"))
    }

    fun list(path: String = ""): AndroidControlResult {
        val f = safeWorkspace(path)
        if (!f.isDirectory) return AndroidControlResult(false, false, "Folder nahi mili: ${f.name}")
        val items = f.listFiles().orEmpty().take(200).map(::metadata)
        return AndroidControlResult(true, true, "${items.size} items found.", mapOf("items" to items, "path" to f.absolutePath))
    }

    fun metadata(path: String): Map<String, Any?> = metadata(safeWorkspace(path))
    private fun metadata(f: File): Map<String, Any?> = mapOf("name" to f.name, "path" to f.absolutePath, "type" to if (f.isDirectory) "folder" else (f.extension.ifBlank { "file" }), "size" to if (f.isFile) f.length() else 0L, "modified" to f.lastModified())

    fun createFolder(path: String): AndroidControlResult = try {
        val f = safeWorkspace(path); val ok = f.mkdirs() || f.isDirectory
        AndroidControlResult(ok, ok, if (ok) "Folder created: ${f.name}" else "Folder create nahi hua.", mapOf("path" to f.absolutePath))
    } catch (e: Exception) { AndroidControlResult(false, false, "Folder create nahi hua: ${e.message}") }

    fun open(path: String): AndroidControlResult {
        val f = safeWorkspace(path)
        if (!f.exists()) return AndroidControlResult(false, false, "File/folder nahi mila: $path")
        return try {
            val uri = FileProvider.getUriForFile(context, "${context.packageName}.files", f)
            val intent = Intent(Intent.ACTION_VIEW).setDataAndType(uri, if (f.isDirectory) "resource/folder" else mime(f)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
            context.startActivity(intent)
            AndroidControlResult(true, false, "Open request submitted: ${f.name}")
        } catch (e: Exception) { AndroidControlResult(false, false, "Open nahi ho saka: ${e.message}") }
    }

    fun rename(path: String, newName: String, confirmed: Boolean): AndroidControlResult {
        if (!confirmed) return confirm("rename", path)
        val f=safeWorkspace(path); if (!f.exists()) return AndroidControlResult(false,false,"Not found: $path")
        if (File(newName).name != newName) return AndroidControlResult(false,false,"Invalid new name.")
        val out=File(f.parentFile,newName); if (out.exists()) return AndroidControlResult(false,false,"Target already exists.")
        val ok=f.renameTo(out); return AndroidControlResult(ok,ok,if(ok) "Renamed to ${out.name}" else "Rename failed.")
    }

    fun delete(path: String, confirmed: Boolean): AndroidControlResult {
        if (!confirmed) return confirm("delete", path)
        val f=safeWorkspace(path); if (!f.exists()) return AndroidControlResult(false,false,"Not found: $path")
        val ok=deleteRecursive(f); return AndroidControlResult(ok,ok,if(ok) "Deleted: ${f.name}" else "Delete failed.")
    }

    fun copy(src: String, dst: String, confirmed: Boolean): AndroidControlResult {
        if (!confirmed) return confirm("copy", dst)
        return try { copyRecursive(safeWorkspace(src), safeWorkspace(dst)); AndroidControlResult(true,true,"Copied successfully.") }
        catch(e:Exception){AndroidControlResult(false,false,"Copy failed: ${e.message}")}
    }

    fun move(src: String, dst: String, confirmed: Boolean): AndroidControlResult {
        if (!confirmed) return confirm("move", src)
        return try { val s=safeWorkspace(src); val d=safeWorkspace(dst); if (!s.renameTo(d)) { copyRecursive(s,d); deleteRecursive(s) }; AndroidControlResult(true,true,"Moved successfully.") }
        catch(e:Exception){AndroidControlResult(false,false,"Move failed: ${e.message}")}
    }

    fun zip(src: String, out: String): AndroidControlResult = try {
        val s=safeWorkspace(src); val o=safeWorkspace(out); o.parentFile?.mkdirs()
        ZipOutputStream(o.outputStream().buffered()).use { z -> zipRecursive(s,s.parentFile,z) }
        AndroidControlResult(true,true,"ZIP created: ${o.name}")
    } catch(e:Exception){AndroidControlResult(false,false,"ZIP create failed: ${e.message}")}

    fun extract(zipPath: String, outDir: String, confirmed: Boolean): AndroidControlResult {
        if (!confirmed) return confirm("extract", outDir)
        return try {
            val zip=safeWorkspace(zipPath); val out=safeWorkspace(outDir); out.mkdirs(); val base=out.canonicalPath + File.separator
            ZipInputStream(zip.inputStream().buffered()).use { zin ->
                var e=zin.nextEntry
                while(e!=null){ val target=File(out,e.name).canonicalFile; if(target.canonicalPath != out.canonicalPath && !target.canonicalPath.startsWith(base)) return AndroidControlResult(false,false,"Unsafe ZIP path blocked."); target.parentFile?.mkdirs(); if(!e.isDirectory) target.outputStream().use{zin.copyTo(it)}; e=zin.nextEntry }
            }
            AndroidControlResult(true,true,"ZIP extracted to ${out.name}")
        } catch(e:Exception){AndroidControlResult(false,false,"ZIP extract failed: ${e.message}")}
    }

    private fun safeWorkspace(path:String):File { val root=workspace.canonicalFile; val p=File(root,path).canonicalFile; require(p.path==root.path || p.path.startsWith(root.path+File.separator)); return p }
    private fun confirm(action:String,target:String)=AndroidControlResult(false,false,"Confirmation required before $action: $target",requiresUserAction=true)
    private fun deleteRecursive(f:File):Boolean = if(f.isDirectory) f.listFiles().orEmpty().all(::deleteRecursive) && f.delete() else f.delete()
    private fun copyRecursive(s:File,d:File){ if(s.isDirectory){d.mkdirs(); s.listFiles().orEmpty().forEach{copyRecursive(it,File(d,it.name))}} else {d.parentFile?.mkdirs(); s.copyTo(d,overwrite=false)} }
    private fun zipRecursive(root:File, base:File?, z:ZipOutputStream){ if(root.isDirectory) root.listFiles().orEmpty().forEach{zipRecursive(it,base,z)} else {val name=if(base!=null) root.relativeTo(base).path else root.name; z.putNextEntry(ZipEntry(name)); root.inputStream().use{it.copyTo(z)}; z.closeEntry()} }
    private fun mime(f:File)=when(f.extension.lowercase(Locale.ROOT)){"pdf"->"application/pdf";"jpg","jpeg"->"image/jpeg";"png"->"image/png";"txt","log","md"->"text/plain";"zip"->"application/zip";"mp3"->"audio/mpeg";"mp4"->"video/mp4";else->"*/*"}
}
