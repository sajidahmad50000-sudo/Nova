package com.nova.mobile.control

import android.view.accessibility.AccessibilityNodeInfo
import java.util.Locale

/** Semantic Android UI target resolver. It uses accessibility metadata, never blind coordinates. */
class NovaAndroidUiAgent(private val service: NovaAccessibilityService) {
    data class Candidate(val label: String, val score: Int, val clickable: Boolean, val editable: Boolean, val scrollable: Boolean)

    fun candidates(query: String, limit: Int = 5): List<Candidate> {
        val q = normalize(query)
        if (q.isBlank()) return emptyList()
        val out = mutableListOf<Candidate>()
        collect(service.rootNode(), q, out)
        return out.sortedByDescending { it.score }.take(limit)
    }

    fun resolve(query: String): AccessibilityNodeInfo? {
        val q = normalize(query)
        if (q.isBlank()) return null
        return find(service.rootNode(), q)
    }

    fun click(query: String): Pair<Boolean, String> {
        val list = candidates(query, 3)
        if (list.isEmpty()) return false to "'$query' visible UI mein nahi mila."
        if (list.size > 1 && list[0].score - list[1].score < 15) {
            return false to "'$query' ke multiple possible UI targets mile: ${list.joinToString { it.label }}"
        }
        val node = resolve(query) ?: return false to "'$query' resolve nahi hua."
        val ok = service.clickNode(node)
        return ok to if (ok) "'${list[0].label}' click ho gaya." else "'${list[0].label}' click nahi ho saka."
    }

    fun fill(query: String, text: String): Pair<Boolean, String> {
        val list = candidates(query, 3)
        if (list.isEmpty()) return false to "'$query' text field nahi mili."
        if (list.size > 1 && list[0].score - list[1].score < 15) {
            return false to "'$query' ke multiple possible fields mile: ${list.joinToString { it.label }}"
        }
        val node = resolve(query) ?: return false to "'$query' resolve nahi hua."
        val ok = service.setTextOnNode(node, text)
        return ok to if (ok) "'${list[0].label}' field fill ho gayi." else "'${list[0].label}' field fill nahi ho saki."
    }

    private fun collect(node: AccessibilityNodeInfo?, q: String, out: MutableList<Candidate>) {
        if (node == null) return
        if (node.isVisibleToUser) {
            val label = label(node)
            if (label.isNotBlank()) {
                val score = score(label, q, node)
                if (score > 0) out += Candidate(label.take(120), score, node.isClickable, node.isEditable, node.isScrollable)
            }
        }
        for (i in 0 until node.childCount) collect(node.getChild(i), q, out)
    }

    private fun find(node: AccessibilityNodeInfo?, q: String): AccessibilityNodeInfo? {
        if (node == null) return null
        val label = label(node)
        if (node.isVisibleToUser && score(label, q, node) >= 100) return node
        var best: AccessibilityNodeInfo? = null
        var bestScore = 0
        if (node.isVisibleToUser) {
            val s = score(label, q, node)
            if (s > bestScore) { best = node; bestScore = s }
        }
        for (i in 0 until node.childCount) {
            val child = find(node.getChild(i), q)
            if (child != null) return child
        }
        return best
    }

    private fun score(label: String, q: String, node: AccessibilityNodeInfo): Int {
        val n = normalize(label)
        if (n == q) return 120 + if (node.isClickable || node.isEditable) 20 else 0
        if (n.startsWith(q)) return 95 + if (node.isClickable || node.isEditable) 10 else 0
        if (n.contains(q)) return 70 + if (node.isClickable || node.isEditable) 10 else 0
        val tokens = q.split(' ').filter { it.length > 1 }
        val hits = tokens.count { n.contains(it) }
        return if (hits > 0) 20 + hits * 12 else 0
    }

    private fun label(node: AccessibilityNodeInfo): String = listOfNotNull(
        node.text?.toString()?.takeIf { it.isNotBlank() },
        node.contentDescription?.toString()?.takeIf { it.isNotBlank() },
        node.hintText?.toString()?.takeIf { it.isNotBlank() },
        node.viewIdResourceName?.substringAfterLast('/')?.takeIf { it.isNotBlank() }
    ).distinct().joinToString(" | ")

    private fun normalize(value: String): String = value.lowercase(Locale.ROOT).replace(Regex("[^\\p{L}\\p{N}]+"), " ").trim()
}
