package com.nova.mobile.control

import android.graphics.Rect
import java.util.Locale

/**
 * Visual grounding layer for Android. It combines semantic accessibility data
 * with screen bounds so Nova can reason about where UI elements are located.
 * Pixel/OCR vision is optional and is never claimed when unavailable.
 */
class NovaAndroidVisualIntelligence(private val service: NovaAccessibilityService) {
    data class VisualTarget(
        val label: String,
        val role: String,
        val score: Int,
        val bounds: Rect,
        val clickable: Boolean,
        val editable: Boolean
    )

    fun screen(): Map<String, Any> = service.visualScreenSummary()

    fun find(query: String, limit: Int = 5): List<VisualTarget> {
        val q = normalize(query)
        if (q.isBlank()) return emptyList()
        return service.visualNodes().mapNotNull { n ->
            val hay = normalize(listOf(n.label, n.resourceId ?: "", n.role).joinToString(" "))
            val score = score(hay, q, n.clickable, n.editable)
            if (score <= 0) null else VisualTarget(
                n.label.ifBlank { n.resourceId ?: n.role }, n.role, score,
                Rect(n.boundsLeft, n.boundsTop, n.boundsRight, n.boundsBottom), n.clickable, n.editable
            )
        }.sortedByDescending { it.score }.take(limit)
    }

    fun describe(): String {
        val nodes = service.visualNodes()
        if (nodes.isEmpty()) return "Visible visual UI information available nahi hai."
        val buttons = nodes.filter { it.clickable }.take(8).joinToString(", ") { it.label.ifBlank { it.role } }
        val fields = nodes.filter { it.editable }.take(5).joinToString(", ") { it.label.ifBlank { "text field" } }
        return buildString {
            append("Screen par ${nodes.size} visible UI elements mile.")
            if (buttons.isNotBlank()) append(" Buttons/options: $buttons.")
            if (fields.isNotBlank()) append(" Text fields: $fields.")
        }
    }

    private fun score(hay: String, q: String, clickable: Boolean, editable: Boolean): Int {
        if (hay == q) return 140 + if (clickable || editable) 20 else 0
        if (hay.startsWith(q)) return 110 + if (clickable || editable) 15 else 0
        if (hay.contains(q)) return 80 + if (clickable || editable) 15 else 0
        val tokens = q.split(' ').filter { it.length > 1 }
        val hits = tokens.count { hay.contains(it) }
        return if (hits == 0) 0 else 25 + hits * 15
    }

    private fun normalize(value: String): String = value.lowercase(Locale.ROOT).replace(Regex("[^\\p{L}\\p{N}]+"), " ").trim()
}
