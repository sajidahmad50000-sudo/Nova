package com.nova.mobile

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.nova.mobile.logging.NovaLogger

/**
 * Android intentionally does not start a microphone foreground service from
 * BOOT_COMPLETED on modern Android releases. We log the boot event so the UI
 * can explain the OS restriction instead of silently pretending wake is active.
 */
class NovaBootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action == Intent.ACTION_BOOT_COMPLETED) {
            NovaLogger.info(context, "Device boot detected; microphone wake requires user-visible start on supported Android versions")
        }
    }
}
