package com.nova.mobile.control

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.util.UUID

class NovaAndroidReminders(private val context: Context) {
    private val prefs=context.getSharedPreferences("nova_reminders",Context.MODE_PRIVATE)
    private val fmt=DateTimeFormatter.ISO_LOCAL_DATE_TIME
    private fun all(): JSONArray=try{JSONArray(prefs.getString("items","[]")?:("[]"))}catch(_:Exception){JSONArray()}
    private fun save(a:JSONArray){prefs.edit().putString("items",a.toString()).apply()}
    fun parseDateTime(text:String):LocalDateTime?{
        val now=LocalDateTime.now(); val s=text.lowercase(Locale.ROOT)
        val base=when{ s.contains("day after tomorrow")||s.contains("parson")->now.plusDays(2); s.contains("tomorrow")||s.contains("kal")->now.plusDays(1); else->now }
        val m=Regex("(\\d{1,2})(?::(\\d{2}))?\\s*(am|pm)?",RegexOption.IGNORE_CASE).find(s)?:return null
        var h=m.groupValues[1].toInt(); val min=m.groupValues[2].ifBlank{"0"}.toInt(); val ap=m.groupValues[3].lowercase()
        if(ap=="pm"&&h!=12)h+=12;if(ap=="am"&&h==12)h=0;if(h !in 0..23||min !in 0..59)return null
        return base.withHour(h).withMinute(min).withSecond(0).withNano(0)
    }
    fun create(title:String,whenText:String,confirmed:Boolean):AndroidControlResult{
        val dt=parseDateTime(whenText)?:return AndroidControlResult(false,false,"Reminder ka date/time samajh nahi aaya.")
        if(!confirmed)return AndroidControlResult(false,false,"${dt.format(DateTimeFormatter.ofPattern("dd MMM yyyy, hh:mm a"))} par '$title' reminder set karun? Confirm karein.",requiresUserAction=true)
        val a=all();val o=JSONObject().put("id",UUID.randomUUID().toString()).put("title",title.trim()).put("due",dt.format(fmt)).put("enabled",true);a.put(o);save(a)
        return AndroidControlResult(true,true,"Reminder '$title' set ho gaya.",mapOf("id" to o.getString("id"),"due" to o.getString("due")))
    }
    fun list():AndroidControlResult{val a=all();return AndroidControlResult(true,true,"Reminders ready.",mapOf("reminders" to (0 until a.length()).map{a.getJSONObject(it).toMap()}))}
    fun search(q:String):AndroidControlResult{val a=all();val out=mutableListOf<Map<String,Any?>>();for(i in 0 until a.length()){val o=a.getJSONObject(i);if(o.optString("title").contains(q,true)&&o.optBoolean("enabled",true))out.add(o.toMap())};return AndroidControlResult(true,true,"Reminder search complete.",mapOf("reminders" to out))}
    fun snooze(id:String,minutes:Int,confirmed:Boolean):AndroidControlResult{val a=all();for(i in 0 until a.length()){val o=a.getJSONObject(i);if(o.optString("id")==id){if(!confirmed)return AndroidControlResult(false,false,"'${o.optString("title")}' reminder ${minutes} minutes ke liye snooze karun? Confirm karein.",requiresUserAction=true);o.put("due",LocalDateTime.now().plusMinutes(minutes.toLong()).format(fmt));save(a);return AndroidControlResult(true,true,"Reminder snooze ho gaya.")}};return AndroidControlResult(false,false,"Reminder nahi mila.")}
    fun cancel(id:String,confirmed:Boolean):AndroidControlResult{val a=all();for(i in 0 until a.length()){val o=a.getJSONObject(i);if(o.optString("id")==id){if(!confirmed)return AndroidControlResult(false,false,"'${o.optString("title")}' reminder cancel karun? Confirm karein.",requiresUserAction=true);o.put("enabled",false);save(a);return AndroidControlResult(true,true,"Reminder cancel ho gaya.")}};return AndroidControlResult(false,false,"Reminder nahi mila.")}
    private fun JSONObject.toMap(): Map<String, Any?> = keys().asSequence().associateWith { key -> opt(key) }
}
