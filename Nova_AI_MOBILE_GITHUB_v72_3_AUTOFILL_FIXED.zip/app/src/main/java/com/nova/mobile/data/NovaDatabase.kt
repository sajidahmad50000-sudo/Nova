package com.nova.mobile.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class NovaDatabase(context: Context) :
    SQLiteOpenHelper(context, "nova.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""
            CREATE TABLE conversation_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                created_at INTEGER NOT NULL,
                language TEXT NOT NULL,
                user_text TEXT NOT NULL,
                nova_text TEXT NOT NULL
            )
        """.trimIndent())
        db.execSQL("""
            CREATE TABLE contacts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL UNIQUE,
                phone TEXT NOT NULL,
                created_at INTEGER NOT NULL,
                updated_at INTEGER NOT NULL
            )
        """.trimIndent())
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // Future migrations belong here. Never delete user data silently.
    }

    fun saveConversation(language: String, userText: String, novaText: String) {
        writableDatabase.insert("conversation_log", null, ContentValues().apply {
            put("created_at", System.currentTimeMillis())
            put("language", language)
            put("user_text", userText)
            put("nova_text", novaText)
        })
    }

    fun saveContact(name: String, phone: String) {
        val now = System.currentTimeMillis()
        writableDatabase.insertWithOnConflict("contacts", null, ContentValues().apply {
            put("name", name)
            put("phone", phone)
            put("created_at", now)
            put("updated_at", now)
        }, SQLiteDatabase.CONFLICT_REPLACE)
    }

    fun getContact(name: String): String? =
        readableDatabase.query(
            "contacts", arrayOf("phone"), "name = ?", arrayOf(name),
            null, null, null
        ).use { cursor -> if (cursor.moveToFirst()) cursor.getString(0) else null }
}
