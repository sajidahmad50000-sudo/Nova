package com.nova.mobile.control

import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.provider.Settings
import java.io.File
import kotlin.math.roundToInt

/**
 * Unified Android device/app/UI control facade.
 *
 * Important Android restrictions are explicit: normal apps cannot silently
 * toggle some protected settings or force-stop arbitrary apps. Those methods
 * return a permission/settings action instead of claiming success.
 */
data class AndroidControlResult(
    val success: Boolean,
    val verified: Boolean = false,
    val message: String,
    val data: Map<String, Any?> = emptyMap(),
    val requiresUserAction: Boolean = false
)

class NovaAndroidControl(private val context: Context) {
    private val audio by lazy { context.getSystemService(Context.AUDIO_SERVICE) as AudioManager }

    fun deviceInfo(): AndroidControlResult = AndroidControlResult(true, true, "Device information ready.", mapOf(
        "manufacturer" to Build.MANUFACTURER,
        "model" to Build.MODEL,
        "brand" to Build.BRAND,
        "android" to Build.VERSION.RELEASE,
        "sdk" to Build.VERSION.SDK_INT,
        "device" to Build.DEVICE
    ))

    fun batteryInfo(): AndroidControlResult {
        val bm = context.getSystemService(Context.BATTERY_SERVICE) as android.os.BatteryManager
        val pct = bm.getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val charging = bm.isCharging
        return AndroidControlResult(true, pct in 0..100, "Battery: $pct%, ${if (charging) "charging" else "not charging"}.", mapOf("percent" to pct, "charging" to charging))
    }

    fun storageInfo(): AndroidControlResult {
        val stat = StatFs(Environment.getDataDirectory().path)
        val total = stat.totalBytes
        val free = stat.availableBytes
        return AndroidControlResult(true, total > 0, "Storage information ready.", mapOf("totalBytes" to total, "freeBytes" to free, "usedBytes" to (total - free)))
    }

    fun volume(direction: String, amount: Int = 1): AndroidControlResult {
        val stream = AudioManager.STREAM_MUSIC
        val delta = amount.coerceIn(1, 10)
        val current = audio.getStreamVolume(stream)
        val max = audio.getStreamMaxVolume(stream)
        val target = when (direction.lowercase()) {
            "up", "increase", "louder", "barhao" -> (current + delta).coerceAtMost(max)
            "down", "decrease", "lower", "kam" -> (current - delta).coerceAtLeast(0)
            "mute" -> 0
            else -> return AndroidControlResult(false, false, "Volume direction samajh nahi aayi.")
        }
        audio.setStreamVolume(stream, target, 0)
        val verified = audio.getStreamVolume(stream) == target
        return AndroidControlResult(verified, verified, if (verified) "Volume set to $target/$max." else "Volume change verify nahi ho saka.", mapOf("current" to audio.getStreamVolume(stream), "max" to max))
    }

    fun brightness(valuePercent: Int): AndroidControlResult {
        if (!Settings.System.canWrite(context)) return openSettings(Settings.ACTION_MANAGE_WRITE_SETTINGS, "Brightness control ke liye Write Settings permission required hai.", Uri.parse("package:${context.packageName}"))
        val value = valuePercent.coerceIn(1, 100)
        return try {
            val ok = Settings.System.putInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS, (value * 255 / 100f).roundToInt())
            val now = Settings.System.getInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS)
            AndroidControlResult(ok && now > 0, ok && now > 0, "Brightness set to $value%.", mapOf("percent" to (now * 100 / 255)))
        } catch (e: Exception) { AndroidControlResult(false, false, "Brightness change nahi ho saka: ${e.message}") }
    }

    fun rotation(auto: Boolean): AndroidControlResult {
        if (!Settings.System.canWrite(context)) return openSettings(Settings.ACTION_MANAGE_WRITE_SETTINGS, "Rotation control ke liye Write Settings permission required hai.", Uri.parse("package:${context.packageName}"))
        return try {
            Settings.System.putInt(context.contentResolver, Settings.System.ACCELEROMETER_ROTATION, if (auto) 1 else 0)
            val now = Settings.System.getInt(context.contentResolver, Settings.System.ACCELEROMETER_ROTATION)
            AndroidControlResult(now == if (auto) 1 else 0, true, if (auto) "Auto-rotation on." else "Auto-rotation off.", mapOf("auto" to (now == 1)))
        } catch (e: Exception) { AndroidControlResult(false, false, "Rotation change nahi ho saka: ${e.message}") }
    }

    fun wifi(): AndroidControlResult = panel(Settings.ACTION_WIFI_SETTINGS, "Wi-Fi settings/panel open kar raha hoon.")
    fun mobileData(): AndroidControlResult = panel(Settings.ACTION_WIRELESS_SETTINGS, "Connectivity settings open kar raha hoon; mobile data direct toggle normal app se restricted ho sakta hai.")
    fun bluetooth(): AndroidControlResult = panel(Settings.ACTION_BLUETOOTH_SETTINGS, "Bluetooth settings open kar raha hoon.")
    fun dnd(enabled: Boolean? = null): AndroidControlResult {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (!nm.isNotificationPolicyAccessGranted) return openSettings(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS, "Do Not Disturb control ke liye notification policy access required hai.")
        if (enabled == null) return AndroidControlResult(true, true, "DND access granted.")
        return try {
            nm.setInterruptionFilter(if (enabled) NotificationManager.INTERRUPTION_FILTER_PRIORITY else NotificationManager.INTERRUPTION_FILTER_ALL)
            val verified = nm.currentInterruptionFilter == if (enabled) NotificationManager.INTERRUPTION_FILTER_PRIORITY else NotificationManager.INTERRUPTION_FILTER_ALL
            AndroidControlResult(verified, verified, if (enabled) "Do Not Disturb on." else "Do Not Disturb off.")
        } catch (e: SecurityException) { AndroidControlResult(false, false, "DND change blocked by Android policy: ${e.message}") }
    }

    fun torch(on: Boolean): AndroidControlResult {
        if (Build.VERSION.SDK_INT < 23) return AndroidControlResult(false, false, "Torch API is Android 6+ only.")
        if (context.checkSelfPermission(android.Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            return openSettings(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, "Torch ke liye Camera permission required hai.", Uri.parse("package:${context.packageName}"))
        }
        return try {
            val cm = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull { id ->
                cm.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true &&
                    cm.getCameraCharacteristics(id).get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
            } ?: return AndroidControlResult(false, false, "Torch camera available nahi hai.")
            cm.setTorchMode(id, on)
            AndroidControlResult(true, true, if (on) "Torch on." else "Torch off.", mapOf("on" to on))
        } catch (e: Exception) { AndroidControlResult(false, false, "Torch change nahi ho saka: ${e.message}") }
    }

    fun screenshot(): AndroidControlResult {
        val service = NovaAccessibilityService.instance
        if (Build.VERSION.SDK_INT >= 30 && service != null) {
            val ok = service.takeScreenshotToFile()
            return if (ok) AndroidControlResult(true, false, "Screenshot capture request submitted; completion is asynchronous.")
            else AndroidControlResult(false, false, "Screenshot capture nahi ho saka.")
        }
        return openSettings(Settings.ACTION_ACCESSIBILITY_SETTINGS, "Screenshot ke liye Nova Accessibility Service enable karein.")
    }

    fun screenInfo(): AndroidControlResult {
        val wm = context.getSystemService(Context.WINDOW_SERVICE) as android.view.WindowManager
        val metrics = context.resources.displayMetrics
        return AndroidControlResult(true, true, "Screen information ready.", mapOf("widthPx" to metrics.widthPixels, "heightPx" to metrics.heightPixels, "density" to metrics.density, "rotation" to if (Build.VERSION.SDK_INT >= 30) wm.defaultDisplay.rotation else 0))
    }

    fun home(): AndroidControlResult = global(AccessibilityServiceAction.HOME, "Home")
    fun back(): AndroidControlResult = global(AccessibilityServiceAction.BACK, "Back")
    fun recents(): AndroidControlResult = global(AccessibilityServiceAction.RECENTS, "Recent Apps")
    fun notifications(): AndroidControlResult = global(AccessibilityServiceAction.NOTIFICATIONS, "Notifications")
    fun quickSettings(): AndroidControlResult = global(AccessibilityServiceAction.QUICK_SETTINGS, "Quick Settings")
    fun lock(): AndroidControlResult = global(AccessibilityServiceAction.LOCK, "Lock screen")

    fun openApp(packageName: String): AndroidControlResult {
        val intent = context.packageManager.getLaunchIntentForPackage(packageName)
            ?: return AndroidControlResult(false, false, "App installed/launchable nahi mili: $packageName")
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try { context.startActivity(intent); AndroidControlResult(true, false, "App launch requested: $packageName", mapOf("package" to packageName)) }
        catch (e: Exception) { AndroidControlResult(false, false, "App open nahi ho saki: ${e.message}") }
    }


    fun openAppByName(name: String): AndroidControlResult {
        val pm = context.packageManager
        val match = pm.getInstalledApplications(PackageManager.ApplicationInfoFlags.of(0))
            .mapNotNull { app ->
                val label = pm.getApplicationLabel(app).toString()
                if (label.equals(name.trim(), true) || label.contains(name.trim(), true)) label to app.packageName else null
            }.firstOrNull()
            ?: return AndroidControlResult(false, false, "App nahi mili: $name")
        return openApp(match.second)
    }

    fun appSearch(query: String): AndroidControlResult {
        val pm = context.packageManager
        val apps = pm.getInstalledApplications(PackageManager.ApplicationInfoFlags.of(0))
            .mapNotNull { app ->
                val label = pm.getApplicationLabel(app).toString()
                if (label.contains(query, true) || app.packageName.contains(query, true)) label to app.packageName else null
            }.take(20)
        return AndroidControlResult(true, true, "${apps.size} matching apps found.", mapOf("apps" to apps.map { mapOf("name" to it.first, "package" to it.second) }))
    }

    fun closeApp(): AndroidControlResult = global(AccessibilityServiceAction.HOME, "Close request")

    private enum class AccessibilityServiceAction { HOME, BACK, RECENTS, NOTIFICATIONS, QUICK_SETTINGS, LOCK }

    private fun global(action: AccessibilityServiceAction, label: String): AndroidControlResult {
        val service = NovaAccessibilityService.instance ?: return openSettings(Settings.ACTION_ACCESSIBILITY_SETTINGS, "$label ke liye Nova Accessibility Service enable karein.")
        val ok = when (action) {
            AccessibilityServiceAction.HOME -> service.home()
            AccessibilityServiceAction.BACK -> service.back()
            AccessibilityServiceAction.RECENTS -> service.recents()
            AccessibilityServiceAction.NOTIFICATIONS -> service.notifications()
            AccessibilityServiceAction.QUICK_SETTINGS -> service.quickSettings()
            AccessibilityServiceAction.LOCK -> service.lockScreen()
        }
        return AndroidControlResult(ok, ok, if (ok) "$label action complete." else "$label action verify nahi ho saka.")
    }

    private fun panel(action: String, message: String): AndroidControlResult = try {
        context.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        AndroidControlResult(true, false, message, requiresUserAction = true)
    } catch (e: Exception) { AndroidControlResult(false, false, "Settings panel open nahi ho saka: ${e.message}") }

    private fun openSettings(action: String, message: String, data: Uri? = null): AndroidControlResult = try {
        val intent = Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (data != null) intent.data = data
        context.startActivity(intent)
        AndroidControlResult(false, false, message, requiresUserAction = true)
    } catch (e: Exception) { AndroidControlResult(false, false, "$message ${e.message}") }
}
