package com.nova.ai

/**
 * Nova conversational command state.
 * Language can be ENGLISH, URDU, or ROMAN_URDU.
 */
enum class NovaLanguage { ENGLISH, URDU, ROMAN_URDU }

enum class NovaState {
    IDLE,
    APP_OPENED_ASK_ACTION,
    WAITING_RECIPIENT,
    WAITING_MESSAGE,
    WAITING_LANGUAGE,
    WAITING_CONFIRMATION
}

data class NovaConversation(
    var state: NovaState = NovaState.IDLE,
    var language: NovaLanguage = NovaLanguage.ROMAN_URDU,
    var openedApp: String = "",
    var recipient: String = "",
    var draftMessage: String = ""
)

object NovaConversationEngine {
    fun detectLanguage(text: String): NovaLanguage {
        val t = text.lowercase()
        if (Regex("[\u0600-\u06FF]").containsMatchIn(text)) return NovaLanguage.URDU
        if (listOf("what","open","send","message","english","yes","no").any { t.contains(it) })
            return NovaLanguage.ENGLISH
        return NovaLanguage.ROMAN_URDU
    }

    fun opened(app: String, language: NovaLanguage): String = when(language) {
        NovaLanguage.ENGLISH -> "$app is open. What would you like me to do?"
        NovaLanguage.URDU -> "$app کھل گیا ہے۔ آپ کیا کرنا چاہتے ہیں؟"
        NovaLanguage.ROMAN_URDU -> "$app khul gaya hai. Kya karna hai?"
    }

    fun askRecipient(language: NovaLanguage): String = when(language) {
        NovaLanguage.ENGLISH -> "Who should I message?"
        NovaLanguage.URDU -> "کس کو پیغام بھیجنا ہے؟"
        NovaLanguage.ROMAN_URDU -> "Kis ko message bhejna hai?"
    }

    fun askMessage(recipient: String, language: NovaLanguage): String = when(language) {
        NovaLanguage.ENGLISH -> "What message should I send to $recipient?"
        NovaLanguage.URDU -> "$recipient کو کیا پیغام بھیجنا ہے؟"
        NovaLanguage.ROMAN_URDU -> "$recipient ko kya message bhejna hai?"
    }

    fun askLanguage(language: NovaLanguage): String = when(language) {
        NovaLanguage.ENGLISH -> "Should I write it in English, Urdu, or Roman Urdu?"
        NovaLanguage.URDU -> "پیغام English، اردو یا Roman Urdu میں لکھنا ہے؟"
        NovaLanguage.ROMAN_URDU -> "Message English, Urdu ya Roman Urdu mein likhna hai?"
    }

    fun confirmation(message: String, language: NovaLanguage): String = when(language) {
        NovaLanguage.ENGLISH -> "Your message is ready: \"$message\". Shall I open WhatsApp with it?"
        NovaLanguage.URDU -> "آپ کا پیغام تیار ہے: \"$message\"۔ کیا میں اسے WhatsApp میں تیار کر دوں؟"
        NovaLanguage.ROMAN_URDU -> "Message tayyar hai: \"$message\". Kya WhatsApp mein tayyar kar doon?"
    }
}
