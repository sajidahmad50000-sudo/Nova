# Nova AI Mobile v72.1

Clean Android-only project for GitHub Actions APK builds.

## GitHub
Upload the **contents of this `android` folder** to the root of a new GitHub repository.
Then open **Actions → Build Nova Android APK → Run workflow**.

The workflow uses JDK 17 + Gradle 8.11.1 and produces `app-debug.apk` as the `nova-mobile-debug-apk` artifact.

## Local build
If Gradle is installed:

```bash
gradle --no-daemon :app:assembleDebug
```

APK:
`app/build/outputs/apk/debug/app-debug.apk`

## Important Android permissions
Nova uses Android Accessibility, Notification Access, microphone, camera and other capabilities only where the corresponding feature needs them. Android Settings may require the user to enable special access manually.
