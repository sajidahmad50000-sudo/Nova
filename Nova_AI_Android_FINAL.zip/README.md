# Nova AI Android — GitHub Ready

Nova is a female-voice Android AI assistant starter with:
- Gemini chat
- Urdu / Roman Urdu / English conversation
- Voice input
- Android Text-to-Speech female voice selection
- Chat history during the current session
- Settings for voice/language behavior
- No hard-coded Gemini API key
- GitHub Actions APK build

## IMPORTANT SECURITY
For a public production app, do NOT ship a Gemini API key directly in the APK.
This demo supports a GitHub Actions secret for building, but the safer production architecture is:
Android app -> your secure backend -> Gemini API.

## Build locally
Create `local.properties`:
GEMINI_API_KEY=YOUR_KEY

Then open in Android Studio and build.

## GitHub
Add repository secret:
GEMINI_API_KEY = your Gemini API key

Then Actions -> Build Nova APK.

## Voice
The app uses Android TextToSpeech and attempts to select a female voice. Availability depends on the installed TTS engine and language voices on the phone. Users can change the TTS voice in Android settings.

## Language behavior
Nova is instructed to reply in the user's language/style:
- Urdu
- Roman Urdu
- English
- mixed Urdu + English
It does not claim unsupported actions were completed.
