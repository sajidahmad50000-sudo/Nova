package com.nova.ai

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody

data class Message(val text: String, val fromUser: Boolean)

class MainActivity : ComponentActivity() {
    private var tts: TextToSpeech? = null
    private var recognizer: SpeechRecognizer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                selectFemaleVoice()
            }
        }

        setContent {
            NovaApp(
                onSpeak = { speak(it) },
                onListen = { callback -> startVoice(callback) }
            )
        }
    }

    private fun selectFemaleVoice() {
        val engine = tts ?: return
        val voices = engine.voices ?: return
        val preferred = voices.firstOrNull { voice ->
            !voice.isNetworkConnectionRequired &&
            (voice.locale.language == "ur" || voice.locale.language == "en") &&
            (voice.name.contains("female", true) ||
             voice.name.contains("woman", true) ||
             voice.name.contains("samantha", true))
        }
        if (preferred != null) {
            engine.voice = preferred
        } else {
            engine.language = Locale.US
        }
    }

    private fun speak(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "nova-response")
    }

    private fun startVoice(onText: (String) -> Unit) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 100)
            return
        }

        if (!SpeechRecognizer.isRecognitionAvailable(this)) return

        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : android.speech.RecognitionListener {
                override fun onResults(results: Bundle?) {
                    results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull()?.let(onText)
                }
                override fun onError(error: Int) {}
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(
                RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
            )
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ur-PK")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Nova ko boliye")
        }
        recognizer?.startListening(intent)
    }

    override fun onDestroy() {
        recognizer?.destroy()
        tts?.shutdown()
        super.onDestroy()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NovaApp(
    onSpeak: (String) -> Unit,
    onListen: ((String) -> Unit) -> Unit
) {
    var input by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }

    val messages = remember {
        mutableStateListOf(
            Message(
                "Assalam-o-Alaikum! Main Nova hoon. Aap Urdu, Roman Urdu ya English mein baat kar sakte hain.",
                false
            )
        )
    }

    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()

    fun send() {
        val prompt = input.trim()
        if (prompt.isEmpty() || loading) return

        messages.add(Message(prompt, true))
        input = ""
        loading = true

        scope.launch {
            val answer = GeminiClient.generate(prompt)
            messages.add(Message(answer, false))
            loading = false
            onSpeak(answer)
        }
    }

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.lastIndex)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Nova AI")
                        Text(
                            "Female voice • Urdu + English",
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                },
                actions = {
                    IconButton(onClick = { showSettings = true }) {
                        Icon(Icons.Default.Settings, "Settings")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(12.dp)
        ) {
            LazyColumn(
                state = listState,
                modifier = Modifier.weight(1f).fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(messages) { msg ->
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement =
                            if (msg.fromUser) Arrangement.End else Arrangement.Start
                    ) {
                        Surface(
                            shape = RoundedCornerShape(18.dp),
                            tonalElevation = 2.dp,
                            modifier = Modifier.widthIn(max = 340.dp)
                        ) {
                            Text(msg.text, Modifier.padding(12.dp))
                        }
                    }
                }

                if (loading) {
                    item {
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.Start
                        ) {
                            CircularProgressIndicator(Modifier.size(24.dp))
                        }
                    }
                }
            }

            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("Nova ko message karein...") },
                    maxLines = 4
                )

                IconButton(onClick = { onListen { input = it } }) {
                    Icon(Icons.Default.Mic, "Voice input")
                }

                IconButton(onClick = { send() }) {
                    Icon(Icons.Default.Send, "Send")
                }
            }
        }
    }

    if (showSettings) {
        AlertDialog(
            onDismissRequest = { showSettings = false },
            title = { Text("Nova Settings") },
            text = {
                Text(
                    "Voice: Female (device TTS dependent)
" +
                    "Language: Urdu / Roman Urdu / English
" +
                    "AI: Gemini

" +
                    "For the best female voice, install a female Urdu/English voice in your Android Text-to-Speech settings."
                )
            },
            confirmButton = {
                TextButton(onClick = { showSettings = false }) {
                    Text("OK")
                }
            }
        )
    }
}

object GeminiClient {
    private const val MODEL = "gemini-2.5-flash"
    private const val ENDPOINT =
        "https://generativelanguage.googleapis.com/v1beta/models/$MODEL:generateContent"

    private val client = OkHttpClient()

    suspend fun generate(userText: String): String =
        kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            try {
                val key = BuildConfig.GEMINI_API_KEY
                if (key.isBlank()) {
                    return@withContext "Gemini API key configured nahi hai. GitHub Secret GEMINI_API_KEY set karein."
                }

                val systemInstruction =
                    "You are Nova, a helpful female-voice Android assistant. " +
                    "Reply in the same language and style the user uses: Urdu script, Roman Urdu, English, " +
                    "or a natural mixture. Keep answers clear and conversational. " +
                    "Never claim an app was opened, a message was sent, or an action was completed unless the app actually performed it."

                val contents = JSONArray()
                    .put(
                        JSONObject()
                            .put(
                                "parts",
                                JSONArray().put(
                                    JSONObject().put(
                                        "text",
                                        "$systemInstruction\n\nUser: $userText"
                                    )
                                )
                            )
                    )

                val body = JSONObject().put("contents", contents).toString()

                val request = Request.Builder()
                    .url("$ENDPOINT?key=$key")
                    .post(body.toRequestBody("application/json".toMediaType()))
                    .build()

                client.newCall(request).execute().use { response ->
                    val raw = response.body?.string().orEmpty()

                    if (!response.isSuccessful) {
                        return@withContext "Gemini connection error (${response.code}). API key aur internet check karein."
                    }

                    val json = JSONObject(raw)
                    json.optJSONArray("candidates")
                        ?.optJSONObject(0)
                        ?.optJSONObject("content")
                        ?.optJSONArray("parts")
                        ?.optJSONObject(0)
                        ?.optString("text")
                        ?: "Mujhe abhi response nahi mila."
                }
            } catch (e: Exception) {
                "Connection error: ${e.message ?: "Unknown error"}"
            }
        }
}
