# Nova Step 8 — Android Control (GitHub Build Fixed)

This project intentionally does **not** require `gradlew`.

GitHub Actions installs Gradle 8.11.1 with `gradle/actions/setup-gradle@v6` and builds with:

`gradle --no-daemon --stacktrace :app:assembleDebug`

## Important
Use the workflow at `.github/workflows/build-apk-v808.yml`.
Do not use an older workflow that runs `chmod +x gradlew` or `./gradlew`.

## Step 8 features
- Android Accessibility Service
- Home / Back / Recent Apps / Notifications
- Scroll up/down
- Open installed apps by name
- Tap visible text
- Type into visible editable fields
- Nova wake-mode foreground microphone service
- Speech-to-text
- Gemini conversation + natural voice flow from earlier steps

The Gemini API key is not included in this project.

FINAL QA: fixes Compose annotation and AccessibilityService capability check; workflow performs pre-build source QA.
