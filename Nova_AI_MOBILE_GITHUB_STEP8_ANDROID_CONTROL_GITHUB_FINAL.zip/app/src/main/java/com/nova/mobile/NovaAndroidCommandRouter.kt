package com.nova.mobile

import android.content.Context
import android.content.Intent
import android.provider.Settings
import com.nova.mobile.control.NovaAccessibilityService
import java.util.Locale

object NovaAndroidCommandRouter {
    data class Result(val handled: Boolean, val success: Boolean, val message: String)

    fun isAccessibilityEnabled(context: Context): Boolean = NovaAccessibilityService.instance != null || try {
        val enabled = Settings.Secure.getString(context.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES).orEmpty()
        enabled.contains(context.packageName, ignoreCase = true)
    } catch (_: Exception) { false }

    fun openAccessibilitySettings(context: Context) {
        context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    fun execute(context: Context, raw: String): Result {
        val text = raw.trim()
        val lower = text.lowercase(Locale.ROOT)
        val svc = NovaAccessibilityService.instance
        if (lower in listOf("home", "go home", "open home")) {
            return Result(true, svc?.goHome() == true, if (svc != null) "Home command sent." else needAccess())
        }
        if (lower in listOf("back", "go back", "press back")) {
            return Result(true, svc?.goBack() == true, if (svc != null) "Back command sent." else needAccess())
        }
        if (lower in listOf("recent", "recents", "open recent apps", "show recent apps")) {
            return Result(true, svc?.openRecents() == true, if (svc != null) "Recent apps opened." else needAccess())
        }
        if (lower in listOf("open notifications", "show notifications", "notifications")) {
            return Result(true, svc?.openNotifications() == true, if (svc != null) "Notifications opened." else needAccess())
        }
        if (lower == "scroll down" || lower == "scroll down page") {
            return Result(true, svc?.scroll("down") == true, if (svc != null) "Scrolled down." else needAccess())
        }
        if (lower == "scroll up" || lower == "scroll up page") {
            return Result(true, svc?.scroll("up") == true, if (svc != null) "Scrolled up." else needAccess())
        }
        Regex("^(?:tap|click)\\s+(.+)$", RegexOption.IGNORE_CASE).find(text)?.let {
            val target = it.groupValues[1].trim()
            val ok = svc?.clickText(target) == true
            return Result(true, ok, if (ok) "Tapped $target." else if (svc == null) needAccess() else "I could not find '$target' on the visible screen.")
        }
        Regex("^(?:type|enter|write)\\s+(.+)$", RegexOption.IGNORE_CASE).find(text)?.let {
            val value = it.groupValues[1]
            val ok = svc?.typeText(value) == true
            return Result(true, ok, if (ok) "Text entered." else if (svc == null) needAccess() else "I could not find an editable field on the visible screen.")
        }
        Regex("^open\\s+(.+)$", RegexOption.IGNORE_CASE).find(text)?.let {
            val appName = it.groupValues[1].trim()
            val ok = openApp(context, appName)
            return Result(true, ok, if (ok) "Opening $appName." else "I could not find an installed app named '$appName'.")
        }
        return Result(false, false, "")
    }

    private fun needAccess() = "Android Control is not enabled. Open Android Accessibility settings and enable Nova."

    private fun openApp(context: Context, name: String): Boolean {
        val pm = context.packageManager
        val needle = name.lowercase(Locale.ROOT)
        val apps = pm.getInstalledApplications(0)
        val match = apps.firstOrNull {
            val label = pm.getApplicationLabel(it).toString().lowercase(Locale.ROOT)
            label == needle || label.contains(needle)
        } ?: return false
        val launch = pm.getLaunchIntentForPackage(match.packageName) ?: return false
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(launch)
        return true
    }
}
