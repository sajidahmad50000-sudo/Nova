package com.nova.mobile

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.app.ServiceCompat
import java.util.Locale

class NovaWakeService : Service() {
    private var recognizer: SpeechRecognizer? = null
    private var stopping = false

    override fun onCreate() {
        super.onCreate()
        createChannel()
        val notification = buildNotification("Nova wake mode is listening")
        if (Build.VERSION.SDK_INT >= 29) {
            ServiceCompat.startForeground(
                this,
                7001,
                notification,
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            )
        } else {
            startForeground(7001, notification)
        }
        startRecognition()
    }

    private fun startRecognition() {
        if (stopping || checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            stopSelf()
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            sendWakeEvent("", "Speech recognition service is unavailable.")
            stopSelf()
            return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) = Unit
            override fun onBeginningOfSpeech() = Unit
            override fun onRmsChanged(rmsdB: Float) = Unit
            override fun onBufferReceived(buffer: ByteArray?) = Unit
            override fun onEndOfSpeech() = Unit
            override fun onEvent(eventType: Int, params: Bundle?) = Unit

            override fun onError(error: Int) {
                if (!stopping) {
                    // Wake mode is deliberately one-shot after a recognition error.
                    sendWakeEvent("", "Wake listening stopped: speech error $error")
                    stopSelf()
                }
            }

            override fun onPartialResults(results: Bundle?) = Unit

            override fun onResults(results: Bundle?) {
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
                val heard = matches.firstOrNull().orEmpty().trim()
                val command = extractWakeCommand(heard)
                if (command != null) {
                    sendWakeEvent(command, "Wake word detected")
                }
                stopSelf()
            }
        })

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-US")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "en-US")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        }
        recognizer?.startListening(intent)
    }

    private fun extractWakeCommand(text: String): String? {
        val normalized = text.trim()
            .replace(Regex("[,:;.!?]+"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
        if (normalized.isBlank()) return null
        val lower = normalized.lowercase(Locale.ROOT)
        val wakePrefixes = listOf("nova", "نوا")
        for (wake in wakePrefixes) {
            if (lower == wake) return ""
            if (lower.startsWith("$wake ")) return normalized.substring(wake.length).trim()
        }
        return null
    }

    private fun sendWakeEvent(command: String, status: String) {
        val intent = Intent(ACTION_WAKE).apply {
            setPackage(packageName)
            putExtra(EXTRA_COMMAND, command)
            putExtra(EXTRA_STATUS, status)
        }
        sendBroadcast(intent)
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Nova Wake Mode",
                NotificationManager.IMPORTANCE_LOW
            ).apply { description = "Shows when Nova wake mode is listening." }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(text: String): Notification {
        return if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("Nova AI")
                .setContentText(text)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setOngoing(true)
                .build()
        } else {
            Notification.Builder(this)
                .setContentTitle("Nova AI")
                .setContentText(text)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setOngoing(true)
                .build()
        }
    }

    override fun onDestroy() {
        stopping = true
        try { recognizer?.cancel() } catch (_: Exception) {}
        recognizer?.destroy()
        recognizer = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_WAKE = "com.nova.mobile.NOVA_WAKE"
        const val EXTRA_COMMAND = "command"
        const val EXTRA_STATUS = "status"
        const val CHANNEL_ID = "nova_wake_mode"
    }
}
