# Nova AI — Step 8 Android Control

Step 8 adds real Android control through Android AccessibilityService. The user must explicitly enable Nova in Android Accessibility settings.

Supported commands include:
- Home
- Back
- Recent Apps
- Notifications
- Scroll up/down
- Open <app>
- Tap <visible text>
- Type <text> into the visible editable field

The app does not claim an action succeeded unless the local Android control layer reports success. Wake mode can route a recognized command to the same local control layer before sending it to Gemini.

Security note: Accessibility access is powerful. Enable it only if you want Nova to control the visible UI. High-impact actions such as purchases, sending messages, deleting data, or changing security settings are not automatically performed by this step.
