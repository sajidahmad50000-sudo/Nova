package com.nova.mobile.control

import java.util.Locale

/**
 * v70 visual-goal layer. Grounds goals through Accessibility + OCR and refuses
 * unsupported color-only guesses. External UI actions remain confirmation gated.
 */
class NovaAndroidVisualGoalAgent(private val service: NovaAccessibilityService) {
    data class GoalResult(
        val success: Boolean,
        val verified: Boolean,
        val message: String,
        val requiresUserAction: Boolean = false,
        val data: Map<String, Any> = emptyMap()
    )

    fun isVisualGoal(command: String): Boolean {
        val t = command.lowercase(Locale.ROOT)
        return listOf("visual goal", "screen par", "screen pe", "screen ko", "blue button", "red button", "green button", "visual click", "visual find", "screen analyze", "screen analyse").any { t.contains(it) }
    }

    fun execute(command: String, confirmed: Boolean): GoalResult {
        val t = command.lowercase(Locale.ROOT).trim()
        if (Regex("\\b(blue|red|green|yellow|black|white)\\s+(button|icon|box|field)\\b").containsMatchIn(t)) {
            return GoalResult(false, true, "Color-based target ko current Android vision reliably verify nahi kar sakti. Button/field ka text ya naam batayein.", data = mapOf("reason" to "color_grounding_unavailable"))
        }
        val vision = NovaAndroidUnifiedVisionAgent(service)
        if (t.contains("screen analyze") || t.contains("screen analyse") || t == "visual goal") {
            val r = vision.analyze()
            return GoalResult(r.success, r.verified, r.message, data = mapOf("targets" to r.targets.map { mapOf("label" to it.label, "source" to it.source, "score" to it.score, "clickable" to it.clickable, "editable" to it.editable) }, "ocrCount" to r.ocrCount))
        }
        val match = Regex("(?i)(?:visual click|click|visual find|find visual|button dhoondo|button find)\\s+(.+)$").find(command)
        if (match != null) {
            var target = match.groupValues[1].trim().trimEnd('.')
            target = Regex("(?i)\\s+button$").replace(target, "").trim()
            if (t.contains("find") || t.contains("dhoondo")) {
                val r = vision.analyze(target)
                return GoalResult(r.success, r.verified, r.message, data = mapOf("targets" to r.targets.map { mapOf("label" to it.label, "source" to it.source, "score" to it.score, "clickable" to it.clickable, "editable" to it.editable) }))
            }
            if (!confirmed) return GoalResult(false, false, "Screen par '$target' click karne se pehle confirmation chahiye.", true)
            val r = vision.click(target)
            return GoalResult(r.success, r.verified, r.message)
        }
        return GoalResult(false, false, "Visual goal samajh nahi aaya. Example: 'screen par Send button click karo'.")
    }
}
