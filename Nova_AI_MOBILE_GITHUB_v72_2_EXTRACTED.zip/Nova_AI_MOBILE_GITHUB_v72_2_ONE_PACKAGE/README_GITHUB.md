# Nova Mobile — GitHub Ready

This folder is the Android/mobile portion of Nova. It is prepared for GitHub Actions APK builds.

Build workflow: `.github/workflows/build-apk.yml`

Output: `app/build/outputs/apk/debug/app-debug.apk`


## IMPORTANT: GitHub ZIP upload
The ZIP itself is a package, not an Android-installable APK. GitHub Actions builds the APK from the extracted repository files.

### Easiest method
1. Download this ZIP.
2. Extract it.
3. Create an empty GitHub repository.
4. Upload the **contents of this extracted folder** to the repository root (including `.github/workflows/build-apk.yml`).
5. Open **Actions → Build Nova Android APK → Run workflow**.
6. Download the `nova-mobile-debug-apk` artifact and install the generated APK on Android.

### Why not upload the ZIP as one file?
A ZIP uploaded as `Nova.zip` is only a file in GitHub; GitHub Actions does not automatically treat its contents as the repository source, and the workflow inside that ZIP cannot start until a workflow exists in the repository.
