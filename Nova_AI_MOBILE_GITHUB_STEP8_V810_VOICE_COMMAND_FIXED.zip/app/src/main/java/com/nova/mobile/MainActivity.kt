package com.nova.mobile

import android.content.Context
import android.content.BroadcastReceiver
import android.content.IntentFilter
import android.os.Bundle
import android.os.Build
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.content.Intent
import android.content.pm.PackageManager
import android.Manifest
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.concurrent.Executors
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.media.AudioFormat
import android.media.AudioTrack
import android.media.AudioManager
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import android.util.Base64
import android.provider.Settings
import com.nova.mobile.control.NovaAccessibilityService

class MainActivity : ComponentActivity() {
    private var speechRecognizer: SpeechRecognizer? = null
    private var selectedLanguage by mutableStateOf("ur-PK")
    private var listening by mutableStateOf(false)
    private var status by mutableStateOf("Ready")
    private var finalText by mutableStateOf("")
    private var partialText by mutableStateOf("")
    private var errorMessage by mutableStateOf<String?>(null)
    private var micGranted by mutableStateOf(false)

    private var apiKey by mutableStateOf("")
    private var prompt by mutableStateOf("")
    private var answer by mutableStateOf("")
    private var aiBusy by mutableStateOf(false)
    private var speaking by mutableStateOf(false)
    private var voiceName by mutableStateOf("Kore")
    private var saveKey by mutableStateOf(false)
    private var previousInteractionId by mutableStateOf<String?>(null)
    private var conversationTurns by mutableStateOf(0)
    private var wakeEnabled by mutableStateOf(false)
    private var androidControlEnabled by mutableStateOf(false)
    private var androidTts: TextToSpeech? = null

    private val executor = Executors.newSingleThreadExecutor()
    private val keyStoreAlias = "NovaGeminiApiKey"

    private val wakeReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action != NovaWakeService.ACTION_WAKE) return
            val command = intent.getStringExtra(NovaWakeService.EXTRA_COMMAND).orEmpty()
            val wakeStatus = intent.getStringExtra(NovaWakeService.EXTRA_STATUS).orEmpty()
            wakeEnabled = false
            status = if (command.isBlank()) "Wake word detected — speak your command" else "Wake word detected"
            errorMessage = if (wakeStatus.startsWith("Wake listening stopped")) wakeStatus else null
            if (command.isBlank()) {
                // Say “Nova” first, then Nova immediately listens for the actual command.
                if (micGranted) {
                    status = "Nova heard you — now listening for your command..."
                    startListening()
                } else {
                    permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                }
            } else {
                prompt = command
                askGemini()
            }
        }
    }

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            micGranted = granted
            errorMessage = if (granted) null else "Microphone permission was denied. Enable it in Android Settings."
            if (granted) status = "Microphone ready"
        }

    override fun onResume() {
        super.onResume()
        androidControlEnabled = NovaAndroidCommandRouter.isAccessibilityEnabled(this)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        micGranted = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        apiKey = loadApiKey()
        androidControlEnabled = NovaAndroidCommandRouter.isAccessibilityEnabled(this)
        val filter = IntentFilter(NovaWakeService.ACTION_WAKE)
        ContextCompat.registerReceiver(this, wakeReceiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
        setupRecognizer()
        androidTts = TextToSpeech(this) { result ->
            if (result == TextToSpeech.SUCCESS) {
                androidTts?.language = Locale("en", "US")
            }
        }.also { tts ->
            tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) { }
                override fun onDone(utteranceId: String?) {
                    runOnUiThread {
                        speaking = false
                        status = "Nova is ready"
                    }
                }
                override fun onError(utteranceId: String?) {
                    runOnUiThread {
                        speaking = false
                        status = "Nova answered (voice failed)"
                    }
                }
            })
        }
        setContent { NovaStepSixScreen() }
    }

    private fun setupRecognizer() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            errorMessage = "No speech recognition service is available on this phone."
            return
        }
        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        speechRecognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                listening = true
                status = "Listening..."
                errorMessage = null
            }
            override fun onBeginningOfSpeech() { status = "Hearing your voice..." }
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {
                listening = false
                status = "Processing speech..."
            }
            override fun onError(error: Int) {
                listening = false
                partialText = ""
                status = "Ready"
                errorMessage = readableError(error)
            }
            override fun onResults(results: Bundle?) {
                listening = false
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                finalText = matches?.firstOrNull().orEmpty()
                partialText = ""
                prompt = finalText
                status = if (finalText.isBlank()) "No speech recognized" else "Speech recognized"
                if (finalText.isNotBlank()) {
                    // Voice button must complete the full pipeline: speech -> command/AI -> answer -> voice.
                    askGemini()
                }
            }
            override fun onPartialResults(partialResults: Bundle?) {
                val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                partialText = matches?.firstOrNull().orEmpty()
            }
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
    }

    private fun startListening() {
        errorMessage = null
        if (!micGranted) {
            permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            errorMessage = "Speech recognition is not available on this device."
            return
        }
        if (speechRecognizer == null) setupRecognizer()
        try {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, selectedLanguage)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, selectedLanguage)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                putExtra(RecognizerIntent.EXTRA_PROMPT, if (selectedLanguage == "ur-PK") "بولیں" else "Speak to Nova")
            }
            finalText = ""
            partialText = ""
            status = "Starting microphone..."
            speechRecognizer?.startListening(intent)
        } catch (_: Exception) {
            listening = false
            status = "Ready"
            errorMessage = "Could not start speech recognition. Please try again."
        }
    }

    private fun stopListening() {
        try { speechRecognizer?.stopListening() } catch (_: Exception) {}
        listening = false
        status = "Ready"
    }

    private fun askGemini() {
        val localControl = NovaAndroidCommandRouter.execute(this, prompt)
        if (localControl.handled) {
            answer = localControl.message
            status = if (localControl.success) "Android control completed" else "Android control needs attention"
            errorMessage = if (localControl.success) null else localControl.message
            if (localControl.success) {
                val keyForVoice = apiKey.trim()
                if (keyForVoice.isNotBlank()) speakGemini(localControl.message, keyForVoice)
                else speakAndroidFallback(localControl.message)
            }
            return
        }
        val key = apiKey.trim()
        val question = prompt.trim()
        if (key.isBlank()) {
            errorMessage = "Enter your Gemini API key first."
            return
        }
        if (question.isBlank()) {
            errorMessage = "Speak to Nova or type a question first."
            return
        }
        aiBusy = true
        answer = ""
        errorMessage = null
        status = "Nova is thinking..."
        executor.execute {
            try {
                val result = callGemini(key, question)
                runOnUiThread {
                    answer = result
                    aiBusy = false
                    status = "Nova answered — speaking..."
                    speakGemini(result, key)
                }
            } catch (e: Exception) {
                runOnUiThread {
                    aiBusy = false
                    status = "Ready"
                    errorMessage = cleanNetworkError(e.message ?: "Unknown Gemini error")
                }
            }
        }
    }

    private fun callGemini(key: String, question: String): String {
        val model = "gemini-3.8-flash"
        val endpoint = "https://generativelanguage.googleapis.com/v1beta/interactions"

        val url = URL(endpoint)
        val connection = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 20000
            readTimeout = 60000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("x-goog-api-key", key)
        }

        val systemPrompt = """
            You are Nova, a helpful Android personal assistant.
            Have a natural, friendly conversation.
            Remember the previous turns in this conversation and use them when relevant.
            The user may speak English, Urdu, or Roman Urdu.
            Reply in the user's language when practical.
            Keep normal answers concise unless the user asks for detail.
            Do not claim you performed an Android action unless the app actually performed it.
        """.trimIndent()

        val bodyObject = JSONObject()
            .put("model", model)
            .put("input", question)
            .put("system_instruction", systemPrompt)

        val previous = previousInteractionId
        if (!previous.isNullOrBlank()) {
            bodyObject.put("previous_interaction_id", previous)
        }

        connection.outputStream.use {
            it.write(bodyObject.toString().toByteArray(Charsets.UTF_8))
        }

        val code = connection.responseCode
        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
        val response = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
        connection.disconnect()

        if (code !in 200..299) {
            throw IllegalStateException("Gemini HTTP $code: ${extractError(response)}")
        }

        val root = JSONObject(response)
        val interactionId = root.optString("id").trim()
        if (interactionId.isNotBlank()) {
            previousInteractionId = interactionId
        }

        val steps = root.optJSONArray("steps")
            ?: throw IllegalStateException("Gemini returned no response steps.")

        val texts = buildString {
            for (i in steps.length() - 1 downTo 0) {
                val step = steps.optJSONObject(i) ?: continue
                if (step.optString("type") != "model_output") continue
                val content = step.optJSONArray("content") ?: continue
                for (j in 0 until content.length()) {
                    val item = content.optJSONObject(j) ?: continue
                    if (item.optString("type") != "text") continue
                    val t = item.optString("text").trim()
                    if (t.isNotBlank()) {
                        if (isNotEmpty()) append("\n")
                        append(t)
                    }
                }
                if (isNotEmpty()) break
            }
        }.trim()

        if (texts.isBlank()) throw IllegalStateException("Gemini returned an empty answer.")
        conversationTurns += 1
        return texts
    }

    private fun speakGemini(text: String, key: String) {
        val clean = text.trim()
        if (clean.isBlank()) return
        speaking = true
        executor.execute {
            try {
                val pcm = callGeminiTts(key, clean, voiceName)
                playPcm24k(pcm)
                runOnUiThread {
                    speaking = false
                    status = "Nova is ready"
                    errorMessage = null
                }
            } catch (e: Exception) {
                runOnUiThread {
                    errorMessage = "Natural voice unavailable: ${e.message ?: "TTS failed"}. Using Android voice."
                    speakAndroidFallback(clean)
                }
            }
        }
    }

    private fun speakAndroidFallback(text: String) {
        val tts = androidTts
        if (tts == null) {
            speaking = false
            status = "Nova answered (voice unavailable)"
            return
        }
        val locale = if (selectedLanguage.startsWith("ur")) Locale("ur", "PK") else Locale("en", "US")
        val result = tts.setLanguage(locale)
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            tts.setLanguage(Locale("en", "US"))
        }
        tts.setSpeechRate(0.95f)
        tts.setPitch(1.0f)
        val params = android.os.Bundle()
        params.putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, "nova-${System.currentTimeMillis()}")
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, params, params.getString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID))
        status = "Nova is speaking"
    }

    private fun callGeminiTts(key: String, text: String, voice: String): ByteArray {
        // Gemini 3.8 Flash TTS uses the generateContent endpoint for audio generation.
        // Request raw 24 kHz PCM so AudioTrack can play it directly.
        val model = "gemini-3.8-flash-tts"
        val endpoint = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent"
        val connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 20000
            readTimeout = 60000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("x-goog-api-key", key)
        }

        val part = JSONObject()
            .put("text", text)
            .put("speech_metadata", JSONObject().put("style", "warm, natural, friendly, conversational, clear"))
        val content = JSONObject()
            .put("role", "user")
            .put("parts", JSONArray().put(part))
        val generationConfig = JSONObject()
            .put("responseModalities", JSONArray().put("AUDIO"))
            .put("responseFormat", JSONObject().put(
                "audio", JSONObject()
                    .put("mimeType", "AUDIO_L16")
                    .put("sampleRate", 24000)
            ))
            .put("speechConfig", JSONObject().put(
                "voiceConfig", JSONObject().put("voice", voice)
            ))
        val body = JSONObject()
            .put("contents", JSONArray().put(content))
            .put("generationConfig", generationConfig)
            .toString()

        connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        val code = connection.responseCode
        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
        val response = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
        connection.disconnect()

        if (code !in 200..299) {
            throw IllegalStateException("Gemini TTS HTTP $code: ${extractError(response)}")
        }

        val candidates = JSONObject(response).optJSONArray("candidates")
            ?: throw IllegalStateException("Gemini TTS returned no candidates.")
        for (i in 0 until candidates.length()) {
            val candidate = candidates.optJSONObject(i) ?: continue
            val contentObject = candidate.optJSONObject("content") ?: continue
            val parts = contentObject.optJSONArray("parts") ?: continue
            for (j in 0 until parts.length()) {
                val inlineData = parts.optJSONObject(j)?.optJSONObject("inlineData") ?: continue
                val data = inlineData.optString("data").trim()
                if (data.isNotBlank()) return Base64.decode(data, Base64.DEFAULT)
            }
        }
        throw IllegalStateException("Gemini TTS returned no audio data.")
    }

    private fun playPcm24k(raw: ByteArray) {
        val pcm = if (raw.size >= 12 && String(raw, 0, 4, Charsets.US_ASCII) == "RIFF") extractWavPcm(raw) else raw
        val min = AudioTrack.getMinBufferSize(24000, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (min <= 0) throw IllegalStateException("Audio output is unavailable.")
        val track = AudioTrack(
            AudioManager.STREAM_MUSIC,
            24000,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_16BIT,
            maxOf(min, pcm.size),
            AudioTrack.MODE_STATIC
        )
        try {
            track.write(pcm, 0, pcm.size)
            track.play()
            val durationMs = (pcm.size.toLong() * 1000L / (24000L * 2L)).coerceAtLeast(100L)
            Thread.sleep(durationMs + 150L)
        } finally {
            track.stop()
            track.release()
        }
    }

    private fun extractWavPcm(wav: ByteArray): ByteArray {
        if (wav.size < 44) return wav
        var pos = 12
        while (pos + 8 <= wav.size) {
            val id = String(wav, pos, 4, Charsets.US_ASCII)
            val size = ByteBuffer.wrap(wav, pos + 4, 4).order(ByteOrder.LITTLE_ENDIAN).int
            if (id == "data") {
                val start = pos + 8
                val end = (start + size).coerceAtMost(wav.size)
                return wav.copyOfRange(start, end)
            }
            if (size < 0) break
            pos += 8 + size
        }
        return wav
    }

    private fun extractError(response: String): String {
        return try {
            JSONObject(response).optJSONObject("error")?.optString("message").orEmpty()
                .ifBlank { response.take(500) }
        } catch (_: Exception) { response.take(500) }
    }

    private fun cleanNetworkError(message: String): String {
        return when {
            message.contains("401") || message.contains("403") ->
                "Gemini rejected the API key. Check that the key is valid and authorized for the Gemini API."
            message.contains("429") ->
                "Gemini rate limit reached. Wait a little and try again."
            message.contains("404") ->
                "Gemini model/endpoint was not found. Check the current model availability."
            message.contains("timeout", ignoreCase = true) ->
                "Gemini request timed out. Check your internet connection."
            else -> message
        }
    }

    private fun readableError(error: Int): String = when (error) {
        SpeechRecognizer.ERROR_AUDIO -> "Audio recording error. Check the microphone."
        SpeechRecognizer.ERROR_CLIENT -> "Speech recognition client error. Please try again."
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission is required."
        SpeechRecognizer.ERROR_NETWORK -> "Speech service network error. Check your internet connection."
        SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Speech service timed out. Check your internet connection."
        SpeechRecognizer.ERROR_NO_MATCH -> "I couldn't understand that. Try speaking clearly."
        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Speech recognition is busy. Try again."
        SpeechRecognizer.ERROR_SERVER -> "Speech service server error. Please try again."
        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "No speech was detected."
        else -> "Speech recognition error ($error). Please try again."
    }

    private fun saveApiKeySecurely(value: String) {
        try {
            val key = getOrCreateSecretKey()
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.ENCRYPT_MODE, key)
            val encrypted = cipher.doFinal(value.toByteArray(Charsets.UTF_8))
            val iv = Base64.encodeToString(cipher.iv, Base64.NO_WRAP)
            val data = Base64.encodeToString(encrypted, Base64.NO_WRAP)
            getPreferences(Context.MODE_PRIVATE).edit()
                .putString("gemini_iv", iv)
                .putString("gemini_key", data)
                .apply()
        } catch (e: Exception) {
            errorMessage = "Could not securely save the API key on this device."
        }
    }

    private fun loadApiKey(): String {
        return try {
            val prefs = getPreferences(Context.MODE_PRIVATE)
            val ivString = prefs.getString("gemini_iv", null) ?: return ""
            val dataString = prefs.getString("gemini_key", null) ?: return ""
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(
                Cipher.DECRYPT_MODE,
                getOrCreateSecretKey(),
                GCMParameterSpec(128, Base64.decode(ivString, Base64.NO_WRAP))
            )
            String(cipher.doFinal(Base64.decode(dataString, Base64.NO_WRAP)), Charsets.UTF_8)
        } catch (_: Exception) { "" }
    }

    private fun clearSavedKey() {
        getPreferences(Context.MODE_PRIVATE).edit()
            .remove("gemini_iv")
            .remove("gemini_key")
            .apply()
        apiKey = ""
    }

    private fun getOrCreateSecretKey(): SecretKey {
        val keyStore = java.security.KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        val existing = keyStore.getKey(keyStoreAlias, null)
        if (existing is SecretKey) return existing
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(
            KeyGenParameterSpec.Builder(
                keyStoreAlias,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .build()
        )
        return generator.generateKey()
    }

    private fun startWakeMode() {
        if (!micGranted) {
            permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
            return
        }
        try {
            val intent = Intent(this, NovaWakeService::class.java)
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
            wakeEnabled = true
            status = "Wake mode starting — say Nova"
            errorMessage = null
        } catch (e: Exception) {
            wakeEnabled = false
            errorMessage = "Could not start Nova wake mode: ${e.message ?: "unknown error"}"
        }
    }

    private fun stopWakeMode() {
        stopService(Intent(this, NovaWakeService::class.java))
        wakeEnabled = false
        status = "Wake mode stopped"
    }

    override fun onDestroy() {
        try { stopWakeMode() } catch (_: Exception) {}
        try { unregisterReceiver(wakeReceiver) } catch (_: Exception) {}
        try { speechRecognizer?.cancel() } catch (_: Exception) {}
        speechRecognizer?.destroy()
        speechRecognizer = null
        androidTts?.stop()
        androidTts?.shutdown()
        androidTts = null
        executor.shutdownNow()
        super.onDestroy()
    }

    @Composable
    private fun NovaStepSixScreen() {
        MaterialTheme {
            Surface(modifier = Modifier.fillMaxSize()) {
                Column(
                    modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
                    verticalArrangement = Arrangement.Center
                ) {
                    Text("Nova AI", style = MaterialTheme.typography.headlineLarge)
                    Spacer(Modifier.height(6.dp))
                    Text("Step 8 — Android Control + Wake Word", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(18.dp))

                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp)) {
                            Text("STATUS", style = MaterialTheme.typography.labelLarge)
                            Spacer(Modifier.height(5.dp))
                            Text(status, style = MaterialTheme.typography.titleLarge)
                            Spacer(Modifier.height(4.dp))
                            Text("Android ${Build.VERSION.RELEASE} • API ${Build.VERSION.SDK_INT}")
                        }
                    }

                    Spacer(Modifier.height(14.dp))
                    OutlinedTextField(
                        value = apiKey,
                        onValueChange = { apiKey = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Gemini API key") },
                        placeholder = { Text("Paste your key here") },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true
                    )
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Checkbox(checked = saveKey, onCheckedChange = { saveKey = it })
                        Text("Save encrypted on this device", modifier = Modifier.padding(top = 12.dp))
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(onClick = {
                            if (apiKey.isBlank()) errorMessage = "Enter the API key first."
                            else if (saveKey) { saveApiKeySecurely(apiKey); status = "API key saved securely on this device" }
                            else { status = "API key ready for this session" }
                        }) { Text("Save / Use Key") }
                        OutlinedButton(onClick = { clearSavedKey(); status = "Saved key cleared" }) { Text("Clear Key") }
                    }

                    Spacer(Modifier.height(14.dp))
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(14.dp)) {
                            Text("Android Control", style = MaterialTheme.typography.labelLarge)
                            Spacer(Modifier.height(5.dp))
                            Text(if (androidControlEnabled) "Android Control: ENABLED" else "Android Control: OFF")
                            Spacer(Modifier.height(8.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Button(onClick = {
                                    NovaAndroidCommandRouter.openAccessibilitySettings(this@MainActivity)
                                }) { Text(if (androidControlEnabled) "Control Settings" else "Enable Control") }
                                OutlinedButton(onClick = {
                                    val result = NovaAndroidCommandRouter.execute(this@MainActivity, "home")
                                    status = result.message
                                    errorMessage = if (result.success) null else result.message
                                }) { Text("Test Home") }
                            }
                            Spacer(Modifier.height(6.dp))
                            Text(
                                "Commands: Home, Back, Recent Apps, Notifications, Scroll up/down, Open <app>, Tap <text>, Type <text>. Nova only acts on commands it can actually perform.",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }

                    Spacer(Modifier.height(14.dp))
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(14.dp)) {
                            Text("Wake Word", style = MaterialTheme.typography.labelLarge)
                            Spacer(Modifier.height(5.dp))
                            Text(if (wakeEnabled) "Listening for: Nova / نوا" else "Wake mode is off")
                            Spacer(Modifier.height(8.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Button(onClick = { if (wakeEnabled) stopWakeMode() else startWakeMode() }) {
                                    Text(if (wakeEnabled) "Stop Wake" else "Enable Wake")
                                }
                                Text(
                                    "Say “Nova” or “Nova, <command>”. Wake mode uses a microphone foreground service and stops after one recognition.",
                                    style = MaterialTheme.typography.bodySmall,
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }

                    Spacer(Modifier.height(14.dp))
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(14.dp)) {
                            Text("Conversation", style = MaterialTheme.typography.labelLarge)
                            Spacer(Modifier.height(4.dp))
                            Text(
                                if (conversationTurns == 0)
                                    "New conversation — Nova has no previous turns yet."
                                else
                                    "Context active — $conversationTurns turn(s) in this conversation."
                            )
                            Spacer(Modifier.height(8.dp))
                            OutlinedButton(
                                onClick = {
                                    previousInteractionId = null
                                    conversationTurns = 0
                                    answer = ""
                                    status = "New conversation started"
                                    errorMessage = null
                                }
                            ) { Text("New Conversation") }
                        }
                    }

                    Spacer(Modifier.height(14.dp))
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(14.dp)) {
                            Text("Settings", style = MaterialTheme.typography.labelLarge)
                            Spacer(Modifier.height(8.dp))
                            Text("Speech language")
                            Spacer(Modifier.height(6.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(onClick = { selectedLanguage = "ur-PK" }) { Text("Urdu") }
                                OutlinedButton(onClick = { selectedLanguage = "en-US" }) { Text("English") }
                            }
                            Spacer(Modifier.height(6.dp))
                            Text("Current: $selectedLanguage • Roman Urdu can be spoken using Urdu mode.", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    Text("Voice", style = MaterialTheme.typography.labelLarge)
                    Spacer(Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { voiceName = "Kore" }) { Text("Kore") }
                        OutlinedButton(onClick = { voiceName = "Puck" }) { Text("Puck") }
                        OutlinedButton(onClick = { voiceName = "Leda" }) { Text("Leda") }
                    }
                    Spacer(Modifier.height(12.dp))
                    Text("Question", style = MaterialTheme.typography.labelLarge)
                    Spacer(Modifier.height(6.dp))
                    OutlinedTextField(
                        value = prompt,
                        onValueChange = { prompt = it },
                        modifier = Modifier.fillMaxWidth().heightIn(min = 110.dp),
                        label = { Text("Ask Nova") }
                    )

                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(
                            enabled = !aiBusy,
                            onClick = { if (listening) stopListening() else startListening() }
                        ) { Text(if (listening) "Stop" else "Speak") }
                        Button(
                            enabled = !aiBusy,
                            onClick = { askGemini() }
                        ) { Text(if (aiBusy) "Thinking..." else "Ask Gemini") }
                    }

                    Spacer(Modifier.height(12.dp))
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp)) {
                            Text("Nova answer", style = MaterialTheme.typography.labelLarge)
                            Spacer(Modifier.height(8.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("Voice: $voiceName")
                                OutlinedButton(enabled = !speaking, onClick = {
                                    val key = apiKey.trim()
                                    if (key.isBlank()) errorMessage = "Enter the Gemini API key first."
                                    else if (answer.isBlank()) errorMessage = "There is no answer to speak yet."
                                    else speakGemini(answer, key)
                                }) { Text(if (speaking) "Speaking..." else "Speak Answer") }
                            }
                            Spacer(Modifier.height(8.dp))
                            Text(if (answer.isBlank()) "—" else answer)
                        }
                    }

                    Spacer(Modifier.height(12.dp))
                    errorMessage?.let {
                        Card(Modifier.fillMaxWidth()) {
                            Text(it, modifier = Modifier.padding(14.dp))
                        }
                    }

                    Spacer(Modifier.height(18.dp))
                    Text(
                        "Flow: Speak → Speech-to-Text → Android command or Gemini → Nova answer → Natural voice. " +
                            "Use New Conversation when you want a fresh context. " +
                            "Conversation context is kept by the Gemini Interactions API while this conversation continues. " +
                            "The API key is not included in the source or GitHub ZIP.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }
    }
}
