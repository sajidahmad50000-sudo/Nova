package com.nova.mobile

import android.content.Context
import android.content.Intent
import android.provider.Settings
import com.nova.mobile.control.NovaAccessibilityService
import java.util.Locale

object NovaAndroidCommandRouter {
    data class Result(val handled: Boolean, val success: Boolean, val message: String)

    fun isAccessibilityEnabled(context: Context): Boolean = NovaAccessibilityService.instance != null || try {
        val enabled = Settings.Secure.getString(context.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES).orEmpty()
        enabled.contains(context.packageName, ignoreCase = true)
    } catch (_: Exception) { false }

    fun openAccessibilitySettings(context: Context) {
        context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    fun execute(context: Context, raw: String): Result {
        val text = raw.trim()
        if (text.isBlank()) return Result(false, false, "")
        val lower = text.lowercase(Locale.ROOT)
        val svc = NovaAccessibilityService.instance

        fun control(ok: Boolean, successMessage: String): Result =
            Result(true, ok, if (ok) successMessage else needAccess())

        if (lower in listOf(
                "home", "go home", "open home", "home screen",
                "ghar", "home jao", "home kholo", "home khol do", "home par jao"
            )) return control(svc?.goHome() == true, "Home opened.")

        if (lower in listOf(
                "back", "go back", "press back", "wapas", "back jao", "peechay",
                "peeche jao", "wapas jao", "back karo"
            )) return control(svc?.goBack() == true, "Back command completed.")

        if (lower in listOf(
                "recent", "recents", "open recent apps", "show recent apps",
                "recent apps", "recent kholo", "recent apps kholo", "recent dikhao"
            )) return control(svc?.openRecents() == true, "Recent apps opened.")

        if (lower in listOf(
                "open notifications", "show notifications", "notifications",
                "notification kholo", "notifications kholo", "notifications dikhao"
            )) return control(svc?.openNotifications() == true, "Notifications opened.")

        if (lower in listOf("scroll down", "scroll down page", "neeche scroll", "neeche karo", "neeche jao")) {
            val ok = svc?.scroll("down") == true
            return Result(true, ok, if (ok) "Scrolled down." else needAccess())
        }
        if (lower in listOf("scroll up", "scroll up page", "upar scroll", "upar karo", "upar jao")) {
            val ok = svc?.scroll("up") == true
            return Result(true, ok, if (ok) "Scrolled up." else needAccess())
        }

        Regex("^(?:tap|click|press|dabao|dabaye)\\s+(.+)$", RegexOption.IGNORE_CASE).find(text)?.let {
            val target = it.groupValues[1].trim()
            val ok = svc?.clickText(target) == true
            return Result(true, ok, if (ok) "Tapped $target." else if (svc == null) needAccess() else "I could not find '$target' on the visible screen.")
        }

        Regex("^(?:type|enter|write|likho|likh do)\\s+(.+)$", RegexOption.IGNORE_CASE).find(text)?.let {
            val value = it.groupValues[1].trim()
            val ok = svc?.typeText(value) == true
            return Result(true, ok, if (ok) "Text entered." else if (svc == null) needAccess() else "I could not find an editable field on the visible screen.")
        }

        // English + common Roman Urdu open-app commands.
        Regex("^(?:open|launch|start|khol|kholo|open karo|open kar|khol do|kholo do)\\s+(.+)$", RegexOption.IGNORE_CASE).find(text)?.let {
            val appName = it.groupValues[1].trim()
                .replace(Regex("(?i)\\s+(?:app|application)$"), "")
                .trim()
            val ok = openApp(context, appName)
            return Result(true, ok, if (ok) "Opening $appName." else "I could not find an installed app named '$appName'.")
        }

        return Result(false, false, "")
    }

    private fun needAccess() = "Android Control is not enabled. Open Android Accessibility settings and enable Nova."

    private fun openApp(context: Context, name: String): Boolean {
        val pm = context.packageManager
        val needle = name.lowercase(Locale.ROOT)
        val apps = pm.getInstalledApplications(0)
        val match = apps.firstOrNull {
            val label = pm.getApplicationLabel(it).toString().lowercase(Locale.ROOT)
            label == needle || label.contains(needle)
        } ?: return false
        val launch = pm.getLaunchIntentForPackage(match.packageName) ?: return false
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(launch)
        return true
    }
}
