# Nova AI Mobile — Step 8.1 / v810

This build fixes the end-to-end voice/command pipeline.

## Fixed
- Speak button automatically sends recognized speech to the command router/Gemini.
- Saying “Nova” alone immediately starts command listening.
- Common English and Roman Urdu commands for Home, Back, Recent Apps, Notifications, scrolling, tap/type, and opening apps.
- Successful local Android commands speak a confirmation even without a Gemini API key.
- Gemini 3.8 Flash TTS uses the documented generateContent audio endpoint and requests 24 kHz L16 PCM.
- Added Settings for Urdu / English speech recognition.

## Required
- Gemini API key for general AI conversation.
- Accessibility enabled for Android-control commands.
- Microphone permission for voice input.
