# Nova AI Mobile — v74.0 Release Candidate

This release candidate consolidates the Nova mobile foundation: AI brain, voice/wake flow, Android control, screen vision, WhatsApp confirmation flow, memory/task agent, remote mobile control, Nova Doctor, and security controls.

## Release gate
The APK is considered release-ready only after GitHub Actions successfully completes `:app:assembleDebug` and the APK artifact is downloaded and tested on a real Android device.

## Safety
Sensitive actions remain confirmation-gated. Remote credentials are stored locally using the app security layer.

## Version
- Version name: 74.0-RC1
- Version code: 82

## v74.3 Clear Natural Voice
Natural voice uses Gemini 3.8 Flash TTS GenerateContent with the Achird prebuilt voice and conversational style controls. The API returns a complete WAV on unary TTS requests; Nova writes the returned audio directly to cache and plays it with MediaPlayer. Android TTS remains only as a fallback if Gemini/network/key is unavailable.


## v74.7 PRO
- Professional Siri-style conversation controls.
- Global cancel/stop command clears pending recipient/message confirmation state.
- Voice help/capability response.
- Voice status response reports listening mode and pending task.
- App-open commands are now retained as the last command for repeat/dobara.
- Version bumped to 74.7-PRO.

This release still requires Android permissions and any configured AI/network services for features that depend on them. Unsupported actions are not reported as completed.


## v74.8 — Calls + WhatsApp Professional
- “Nova, Sajid ko call karo” / “call Sajid” natural command.
- Contact lookup with permission and ambiguity handling.
- Call confirmation before opening Android dialer.
- WhatsApp message preview/confirmation workflow.
- Nova does not claim delivery when Android only opens a composer/chat.


## v74.9 WhatsApp & Messages Agent PRO
- Contacts permission is declared for contact resolution.
- WhatsApp draft opens the installed WhatsApp package when available, with web-intent fallback.
- Nova keeps confirmation before communication actions.
- Nova does not claim a message was sent unless the Android workflow actually reports the action; opening a draft is reported as a draft.
- User can say: “Nova, Sajid ko WhatsApp message bhejo: kal 8 baje aa jana.” Nova resolves the contact, prepares the draft, asks for confirmation, then opens WhatsApp for final review/send.

## v75.1 Smart Notification Intelligence
- User-commanded notification summaries.
- Latest/unread/important notification filtering.
- Query a specific sender/contact's latest notification.
- Requires Android Notification Access permission.
- Nova never claims a notification exists when the listener has no matching record.

## v75.2 — Calendar + Live Weather
- Added live weather through Open-Meteo geocoding/forecast APIs (no API key required).
- Added weather commands such as “Nova, Karachi ka weather batao” and “weather Lahore”.
- Calendar commands remain available; calendar permissions are declared for future/system-calendar integration.
- No fake weather values: if the network request fails, Nova reports that live weather is unavailable.


v75.4 deep QA: real CalendarProvider events, improved alarm notifications, corrected Gemini 3.8 TTS schema, youthful feminine-style voice request, source placeholder scan.
