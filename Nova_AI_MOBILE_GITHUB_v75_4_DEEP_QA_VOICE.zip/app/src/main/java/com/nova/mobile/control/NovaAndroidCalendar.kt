package com.nova.mobile.control

import android.Manifest
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.provider.CalendarContract
import androidx.core.content.ContextCompat
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

/** Real Android Calendar integration. No fake/local-only events. */
class NovaAndroidCalendar(private val context: Context) {
    private val fmt = DateTimeFormatter.ISO_LOCAL_DATE_TIME

    fun parseDateTime(text: String): LocalDateTime? {
        val now=LocalDateTime.now(); val s=text.lowercase(Locale.ROOT)
        val base=when { s.contains("day after tomorrow") || s.contains("parson") -> now.plusDays(2); s.contains("tomorrow") || s.contains("kal") -> now.plusDays(1); else -> now }
        val m=Regex("(\\d{1,2})(?::(\\d{2}))?\\s*(am|pm)?",RegexOption.IGNORE_CASE).find(s) ?: return null
        var h=m.groupValues[1].toInt(); val min=m.groupValues[2].ifBlank { "0" }.toInt(); val ap=m.groupValues[3].lowercase()
        if(ap=="pm"&&h!=12) h+=12; if(ap=="am"&&h==12) h=0
        if(h !in 0..23||min !in 0..59) return null
        return base.withHour(h).withMinute(min).withSecond(0).withNano(0)
    }

    private fun allowed(): Boolean = ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CALENDAR)==PackageManager.PERMISSION_GRANTED && ContextCompat.checkSelfPermission(context, Manifest.permission.WRITE_CALENDAR)==PackageManager.PERMISSION_GRANTED

    private fun calendarId(): Long? {
        if(!allowed()) return null
        val cur=context.contentResolver.query(CalendarContract.Calendars.CONTENT_URI,arrayOf(CalendarContract.Calendars._ID),"${CalendarContract.Calendars.VISIBLE}=1",null,"${CalendarContract.Calendars._ID} ASC") ?: return null
        cur.use { if(it.moveToFirst()) return it.getLong(0) }
        return null
    }

    fun create(title:String, whenText:String, confirmed:Boolean): AndroidControlResult {
        val dt=parseDateTime(whenText) ?: return AndroidControlResult(false,false,"Date/time samajh nahi aaya.")
        if(!allowed()) return AndroidControlResult(false,false,"Calendar permission allow karein, phir Nova event create kar sakti hai.",requiresUserAction=true)
        val cid=calendarId() ?: return AndroidControlResult(false,false,"Phone mein writable calendar nahi mila.")
        if(!confirmed) return AndroidControlResult(false,false,"${dt.format(DateTimeFormatter.ofPattern("dd MMM yyyy, hh:mm a"))} par '$title' event create karun? Confirm karein.",requiresUserAction=true)
        val start=dt.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli(); val end=start+60*60*1000L
        val values=ContentValues().apply { put(CalendarContract.Events.CALENDAR_ID,cid); put(CalendarContract.Events.TITLE,title.trim()); put(CalendarContract.Events.DTSTART,start); put(CalendarContract.Events.DTEND,end); put(CalendarContract.Events.EVENT_TIMEZONE,ZoneId.systemDefault().id); put(CalendarContract.Events.HAS_ALARM,1) }
        val uri=context.contentResolver.insert(CalendarContract.Events.CONTENT_URI,values) ?: return AndroidControlResult(false,false,"Calendar event create nahi ho saka.")
        val id=ContentUris.parseId(uri)
        context.contentResolver.insert(CalendarContract.Reminders.CONTENT_URI,ContentValues().apply { put(CalendarContract.Reminders.EVENT_ID,id); put(CalendarContract.Reminders.MINUTES,10); put(CalendarContract.Reminders.METHOD,CalendarContract.Reminders.METHOD_ALERT) })
        return AndroidControlResult(true,true,"'$title' event phone ke Calendar mein create ho gaya.",mapOf("id" to id,"start" to dt.format(fmt)))
    }

    fun list(): AndroidControlResult {
        if(!allowed()) return AndroidControlResult(false,false,"Calendar permission allow karein.",requiresUserAction=true)
        val now=System.currentTimeMillis(); val end=now+30L*24*60*60*1000
        val out=mutableListOf<Map<String,Any?>>()
        val cur=context.contentResolver.query(CalendarContract.Instances.CONTENT_URI.buildUpon().apply { appendPath(now.toString()); appendPath(end.toString()) }.build(),arrayOf(CalendarContract.Instances.EVENT_ID,CalendarContract.Instances.TITLE,CalendarContract.Instances.BEGIN,CalendarContract.Instances.END),null,null,"${CalendarContract.Instances.BEGIN} ASC") ?: return AndroidControlResult(true,true,"Calendar empty hai.",mapOf("events" to out))
        cur.use { while(it.moveToNext()) out.add(mapOf("id" to it.getLong(0),"title" to it.getString(1),"startMillis" to it.getLong(2),"endMillis" to it.getLong(3))) }
        return AndroidControlResult(true,true,"Calendar events ready.",mapOf("events" to out))
    }

    fun search(q:String): AndroidControlResult {
        if(!allowed()) return AndroidControlResult(false,false,"Calendar permission allow karein.",requiresUserAction=true)
        val all=list(); val rows=all.data?.get("events") as? List<*> ?: emptyList<Any?>(); val out=rows.filter { (it as? Map<*,*>)?.get("title")?.toString()?.contains(q,true)==true }
        return AndroidControlResult(true,true,"Calendar search complete.",mapOf("events" to out))
    }

    fun delete(id:String, confirmed:Boolean): AndroidControlResult {
        if(!allowed()) return AndroidControlResult(false,false,"Calendar permission allow karein.",requiresUserAction=true)
        val eventId=id.toLongOrNull() ?: return AndroidControlResult(false,false,"Calendar event ID invalid hai.")
        val title=findTitle(eventId) ?: return AndroidControlResult(false,false,"Event nahi mila.")
        if(!confirmed) return AndroidControlResult(false,false,"'$title' event delete karun? Confirm karein.",requiresUserAction=true)
        val deleted=context.contentResolver.delete(ContentUris.withAppendedId(CalendarContract.Events.CONTENT_URI,eventId),null,null)
        return if(deleted>0) AndroidControlResult(true,true,"Event delete ho gaya.") else AndroidControlResult(false,false,"Event delete nahi ho saka.")
    }

    private fun findTitle(id:Long):String? { val u=ContentUris.withAppendedId(CalendarContract.Events.CONTENT_URI,id); val c=context.contentResolver.query(u,arrayOf(CalendarContract.Events.TITLE),null,null,null) ?: return null; c.use { return if(it.moveToFirst()) it.getString(0) else null } }
}
