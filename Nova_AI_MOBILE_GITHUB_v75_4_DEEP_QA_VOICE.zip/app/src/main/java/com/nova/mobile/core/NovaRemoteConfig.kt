package com.nova.mobile.core

import android.content.Context

data class NovaRemoteConfig(
    val endpoint: String = "",
    val enabled: Boolean = false,
    val pollSeconds: Int = 15
)

object NovaRemoteConfigStore {
    private const val PREFS = "nova_remote"
    fun load(context: Context): NovaRemoteConfig {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return NovaRemoteConfig(
            endpoint = p.getString("endpoint", "") ?: "",
            enabled = p.getBoolean("enabled", false),
            pollSeconds = p.getInt("poll_seconds", 15).coerceIn(10, 120)
        )
    }
    fun save(context: Context, config: NovaRemoteConfig) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString("endpoint", config.endpoint.trim().trimEnd('/'))
            .putBoolean("enabled", config.enabled)
            .putInt("poll_seconds", config.pollSeconds.coerceIn(10, 120))
            .apply()
    }
}
