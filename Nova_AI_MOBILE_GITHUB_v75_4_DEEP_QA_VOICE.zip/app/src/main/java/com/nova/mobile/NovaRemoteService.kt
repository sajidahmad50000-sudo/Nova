package com.nova.mobile

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.nova.mobile.control.NovaAndroidCommandRouter
import com.nova.mobile.core.NovaRemoteConfigStore
import com.nova.mobile.core.NovaRemoteRelay
import com.nova.mobile.logging.NovaLogger
import java.util.concurrent.atomic.AtomicBoolean

class NovaRemoteService : Service() {
    private val running = AtomicBoolean(false)
    private lateinit var relay: NovaRemoteRelay
    private lateinit var router: NovaAndroidCommandRouter
    private val channelId = "nova_remote"

    override fun onCreate() {
        super.onCreate()
        relay = NovaRemoteRelay(this)
        router = NovaAndroidCommandRouter(this)
        createChannel()
        startForeground(4401, notification("Remote control ready"))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (running.compareAndSet(false, true)) {
            Thread { loop() }.start()
        }
        return START_STICKY
    }

    private fun loop() {
        while (running.get()) {
            val cfg = NovaRemoteConfigStore.load(this)
            if (!cfg.enabled || cfg.endpoint.isBlank()) {
                stopSelf(); break
            }
            try {
                val item = relay.poll()
                if (item != null) handle(item)
            } catch (e: Exception) {
                NovaLogger.error(this, "Remote relay poll failed", e)
            }
            try { Thread.sleep(cfg.pollSeconds * 1000L) } catch (_: InterruptedException) { break }
        }
    }

    private fun handle(item: org.json.JSONObject) {
        val requestId = item.optString("request_id", "")
        val command = item.optString("command", "").trim()
        if (command.isBlank()) return
        val result = router.execute(command, confirmed = false)
        val needsConfirmation = result.requiresUserAction
        relay.postResult(requestId, result.success, result.message, needsConfirmation)
        if (needsConfirmation) {
            showNotification("Confirmation required", result.message)
            val open = Intent(this, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                putExtra("nova_remote_command", command)
            }
            val pi = PendingIntent.getActivity(this, requestId.hashCode(), open, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            val manager = getSystemService(NotificationManager::class.java)
            manager.notify(4402, NotificationCompat.Builder(this, channelId)
                .setSmallIcon(android.R.drawable.ic_dialog_alert).setContentTitle("Nova confirmation required")
                .setContentText("Open Nova to review: $command").setContentIntent(pi).setAutoCancel(true).build())
        } else {
            showNotification("Nova remote task", result.message)
        }
    }

    private fun createChannel() {
        getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel(channelId, "Nova Remote Control", NotificationManager.IMPORTANCE_LOW)
        )
    }

    private fun notification(text: String): Notification = NotificationCompat.Builder(this, channelId)
        .setSmallIcon(android.R.drawable.ic_menu_send).setContentTitle("Nova Remote Control")
        .setContentText(text).setOngoing(true).build()

    private fun showNotification(title: String, text: String) {
        getSystemService(NotificationManager::class.java).notify((System.currentTimeMillis() and 0x7fffffff).toInt(),
            NotificationCompat.Builder(this, channelId).setSmallIcon(android.R.drawable.ic_menu_send)
                .setContentTitle(title).setContentText(text.take(180)).setAutoCancel(true).build())
    }

    override fun onDestroy() { running.set(false); super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null
}
