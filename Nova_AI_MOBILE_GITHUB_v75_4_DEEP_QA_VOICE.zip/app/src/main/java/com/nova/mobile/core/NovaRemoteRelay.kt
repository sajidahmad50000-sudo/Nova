package com.nova.mobile.core

import android.content.Context
import android.provider.Settings
import com.nova.mobile.security.NovaSecureStore
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.nio.charset.StandardCharsets
import java.security.SecureRandom
import android.util.Base64
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

class NovaRemoteRelay(private val context: Context) {
    private val app = context.applicationContext
    private val secure = NovaSecureStore(app)

    private fun b64(data: ByteArray) = Base64.encodeToString(data, Base64.NO_WRAP or Base64.URL_SAFE)
    private fun b64d(value: String) = Base64.decode(value, Base64.NO_WRAP or Base64.URL_SAFE)

    private fun encrypt(secretB64: String, payload: JSONObject): String {
        val nonce = ByteArray(12).also { SecureRandom().nextBytes(it) }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(b64d(secretB64), "AES"), GCMParameterSpec(128, nonce))
        val encrypted = cipher.doFinal(payload.toString().toByteArray(StandardCharsets.UTF_8))
        return JSONObject().put("nonce", b64(nonce)).put("ciphertext", b64(encrypted)).toString()
    }

    private fun decrypt(secretB64: String, body: String): JSONObject {
        val env = JSONObject(body)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(b64d(secretB64), "AES"), GCMParameterSpec(128, b64d(env.getString("nonce"))))
        return JSONObject(String(cipher.doFinal(b64d(env.getString("ciphertext"))), StandardCharsets.UTF_8))
    }

    fun poll(): JSONObject? {
        val cfg = NovaRemoteConfigStore.load(app)
        val token = secure.token ?: return null
        val secret = secure.secret ?: return null
        if (!cfg.enabled || cfg.endpoint.isBlank()) return null
        val deviceId = Settings.Secure.getString(app.contentResolver, Settings.Secure.ANDROID_ID) ?: "unknown-device"
        val url = URL("${cfg.endpoint.trimEnd('/')}/v1/device/poll?device_id=${java.net.URLEncoder.encode(deviceId, "UTF-8")}")
        val c = url.openConnection() as HttpURLConnection
        return try {
            c.requestMethod = "GET"
            c.connectTimeout = 10000
            c.readTimeout = 15000
            c.setRequestProperty("Accept", "application/json")
            c.setRequestProperty("X-Nova-Device", deviceId)
            c.setRequestProperty("X-Nova-Token", token)
            if (c.responseCode == 204) return null
            val body = (if (c.responseCode in 200..299) c.inputStream else c.errorStream).bufferedReader().use { it.readText() }
            if (c.responseCode !in 200..299 || body.isBlank()) return null
            decrypt(secret, body)
        } finally { c.disconnect() }
    }

    fun postResult(requestId: String, success: Boolean, message: String, requiresConfirmation: Boolean = false) {
        val cfg = NovaRemoteConfigStore.load(app)
        val token = secure.token ?: return
        val secret = secure.secret ?: return
        if (!cfg.enabled || cfg.endpoint.isBlank()) return
        val deviceId = Settings.Secure.getString(app.contentResolver, Settings.Secure.ANDROID_ID) ?: "unknown-device"
        val payload = JSONObject().put("request_id", requestId).put("success", success).put("message", message).put("requires_confirmation", requiresConfirmation)
        val c = URL("${cfg.endpoint.trimEnd('/')}/v1/device/result").openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 10000; c.readTimeout = 10000
            c.setRequestProperty("Content-Type", "application/json")
            c.setRequestProperty("X-Nova-Device", deviceId); c.setRequestProperty("X-Nova-Token", token)
            c.outputStream.use { it.write(encrypt(secret, payload).toByteArray(StandardCharsets.UTF_8)) }
            c.responseCode
        } finally { c.disconnect() }
    }
}
