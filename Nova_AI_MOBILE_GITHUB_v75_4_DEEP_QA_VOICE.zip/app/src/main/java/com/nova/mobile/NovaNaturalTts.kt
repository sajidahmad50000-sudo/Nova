package com.nova.mobile

import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Handler
import android.os.Looper
import android.util.Base64
import com.nova.mobile.core.NovaAiKeyStore
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.nio.charset.StandardCharsets
import java.util.concurrent.Executors

/** Cloud natural TTS using Gemini 3.8 Flash TTS. Falls back to Android TTS if unavailable. */
class NovaNaturalTts(private val activity: android.app.Activity) {
    private val executor = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    @Volatile private var stopped = false
    private var player: MediaPlayer? = null
    private var audioFile: File? = null

    fun speak(text: String, onStart: () -> Unit, onDone: () -> Unit, fallback: () -> Unit) {
        val key = NovaAiKeyStore.get(activity)
        if (key.isNullOrBlank() || text.isBlank()) { fallback(); return }
        stopped = false
        executor.execute {
            try {
                val clean = text.replace(Regex("\\s+"), " ").trim().take(1800)
                val body = JSONObject().apply {
                    put("contents", JSONArray().put(JSONObject().apply {
                        put("parts", JSONArray().put(JSONObject().apply {
                            put("text", clean)
                            put("speech_metadata", JSONObject().apply {
                                put("style", "warm, friendly, youthful feminine-style Pakistani conversational assistant; speak clear Roman Urdu/English naturally; use Saraiki-style pronunciation and vocabulary only when Saraiki is requested; DO NOT use Sindhi pronunciation, Sindhi vocabulary, or a Sindhi accent; natural human cadence; relaxed pace; crisp pronunciation; gentle short pauses; expressive but not dramatic; never sound robotic")
                            })
                        }))
                    }))
                    put("generationConfig", JSONObject().apply {
                        put("responseModalities", JSONArray().put("AUDIO"))
                        put("responseFormat", JSONObject().apply {
                            put("audio", JSONObject().apply {
                                put("mimeType", "AUDIO_WAV")
                                put("sampleRate", 24000)
                            })
                        })
                        put("speechConfig", JSONObject().apply {
                            put("voiceConfig", JSONObject().put("voice", "Leda"))
                        })
                    })
                }.toString()

                val url = URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-3.8-flash-tts:generateContent")
                val conn = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 12000
                    readTimeout = 30000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json")
                    setRequestProperty("x-goog-api-key", key)
                }
                conn.outputStream.use { it.write(body.toByteArray(StandardCharsets.UTF_8)) }
                val code = conn.responseCode
                if (code !in 200..299) {
                    val err = runCatching { conn.errorStream?.bufferedReader()?.use { it.readText() } }.getOrNull().orEmpty()
                    throw IllegalStateException("TTS HTTP $code ${err.take(300)}")
                }
                val response = conn.inputStream.bufferedReader().use { it.readText() }
                conn.disconnect()
                val root = JSONObject(response)
                val parts = root.getJSONArray("candidates").getJSONObject(0)
                    .getJSONObject("content").getJSONArray("parts")
                var data: String? = null
                for (i in 0 until parts.length()) {
                    val part = parts.getJSONObject(i)
                    if (part.has("inlineData")) {
                        data = part.getJSONObject("inlineData").getString("data")
                        break
                    }
                }
                val audioBase64 = data ?: throw IllegalStateException("No TTS audio returned")
                val wav = Base64.decode(audioBase64, Base64.DEFAULT)
                if (wav.size < 44 || wav[0].toInt().toChar() != 'R' || wav[1].toInt().toChar() != 'I') {
                    throw IllegalStateException("Invalid WAV audio returned")
                }
                val file = File(activity.cacheDir, "nova_tts_${System.currentTimeMillis()}.wav")
                file.writeBytes(wav)
                audioFile = file
                main.post {
                    if (stopped) { cleanupFile(); onDone(); return@post }
                    onStart()
                    val mp = MediaPlayer()
                    player = mp
                    mp.setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANCE_ACCESSIBILITY).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                    mp.setDataSource(file.absolutePath)
                    mp.setOnCompletionListener {
                        runCatching { it.release() }
                        player = null
                        cleanupFile()
                        onDone()
                    }
                    mp.setOnErrorListener { p, _, _ ->
                        runCatching { p.release() }
                        player = null
                        cleanupFile()
                        if (!stopped) fallback() else onDone()
                        true
                    }
                    mp.prepare()
                    mp.start()
                }
            } catch (_: Throwable) {
                main.post { if (!stopped) fallback() else onDone() }
            }
        }
    }

    private fun cleanupFile() {
        runCatching { audioFile?.delete() }
        audioFile = null
    }

    fun stop() {
        stopped = true
        main.post {
            runCatching { player?.stop() }
            runCatching { player?.release() }
            player = null
            cleanupFile()
        }
    }

    fun shutdown() {
        stop()
        executor.shutdownNow()
    }
}
