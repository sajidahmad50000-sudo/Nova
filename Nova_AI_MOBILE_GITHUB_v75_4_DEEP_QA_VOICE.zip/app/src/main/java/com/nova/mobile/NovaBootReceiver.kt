package com.nova.mobile

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import org.json.JSONArray
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.time.ZoneId

class NovaBootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action != Intent.ACTION_BOOT_COMPLETED) return
        val prefs=context.getSharedPreferences("nova_reminders",Context.MODE_PRIVATE)
        val a=try{JSONArray(prefs.getString("items","[]")?:"[]")}catch(_:Exception){JSONArray()}
        val am=context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val fmt=DateTimeFormatter.ISO_LOCAL_DATE_TIME
        for(i in 0 until a.length()){
            val o=a.optJSONObject(i)?:continue
            if(!o.optBoolean("enabled",true)) continue
            try{
                val dt=LocalDateTime.parse(o.optString("due"),fmt)
                if(dt.isBefore(LocalDateTime.now())) continue
                val id=o.optString("id"); val intent2=Intent(context,com.nova.mobile.control.NovaAlarmReceiver::class.java).putExtra("id",id).putExtra("title",o.optString("title")).putExtra("kind",o.optString("kind","reminder"))
                val pi=PendingIntent.getBroadcast(context,id.hashCode(),intent2,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                val millis=dt.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
                if(Build.VERSION.SDK_INT>=31 && !am.canScheduleExactAlarms()) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,millis,pi) else am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,millis,pi)
            }catch(_:Exception){}
        }
    }
}
