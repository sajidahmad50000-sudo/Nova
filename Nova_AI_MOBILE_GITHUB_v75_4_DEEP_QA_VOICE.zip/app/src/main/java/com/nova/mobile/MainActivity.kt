package com.nova.mobile

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import android.speech.RecognitionListener
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import android.speech.tts.UtteranceProgressListener
import androidx.activity.ComponentActivity
import androidx.fragment.app.FragmentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalContext
import com.nova.mobile.core.NovaConfigStore
import com.nova.mobile.core.NovaAiBrain
import com.nova.mobile.core.NovaAiConfig
import com.nova.mobile.core.NovaAiConfigStore
import com.nova.mobile.core.NovaAiKeyStore
import com.nova.mobile.core.NovaRemoteConfig
import com.nova.mobile.core.NovaRemoteConfigStore
import com.nova.mobile.data.NovaDatabase
import com.nova.mobile.health.NovaHealth
import com.nova.mobile.logging.NovaLogger
import org.json.JSONObject
import android.util.Base64
import com.nova.mobile.security.NovaSecureStore
import com.nova.mobile.security.NovaBiometricAuth
import com.nova.mobile.security.NovaQrPairing
import com.nova.mobile.control.NovaAccessibilityService
import com.nova.mobile.control.NovaAndroidCommandRouter
import com.nova.mobile.control.NovaNotificationListenerService
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec
import java.nio.charset.StandardCharsets
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

private fun b64(data: ByteArray): String = Base64.encodeToString(data, Base64.NO_WRAP or Base64.URL_SAFE)
private fun b64d(value: String): ByteArray = Base64.decode(value, Base64.NO_WRAP or Base64.URL_SAFE)
private fun secureEnvelope(secretB64: String, payload: JSONObject): JSONObject {
    val secret = b64d(secretB64)
    val nonce = ByteArray(12).also { SecureRandom().nextBytes(it) }
    val cipher = Cipher.getInstance("AES/GCM/NoPadding")
    cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(secret, "AES"), GCMParameterSpec(128, nonce))
    val encrypted = cipher.doFinal(payload.toString().toByteArray(StandardCharsets.UTF_8))
    return JSONObject().put("nonce", b64(nonce)).put("ciphertext", b64(encrypted))
}
private fun decryptEnvelope(secretB64: String, body: String): JSONObject {
    val env = JSONObject(body); val nonce = b64d(env.getString("nonce")); val encrypted = b64d(env.getString("ciphertext"))
    val cipher = Cipher.getInstance("AES/GCM/NoPadding")
    cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(b64d(secretB64), "AES"), GCMParameterSpec(128, nonce))
    return JSONObject(String(cipher.doFinal(encrypted), StandardCharsets.UTF_8))
}

private enum class NovaLang { ENGLISH, URDU, ROMAN }
private enum class NovaState { IDLE, APP_OPENED, WAITING_RECIPIENT, WAITING_MESSAGE, WAITING_LANGUAGE, WAITING_CONFIRMATION, WAITING_CALL_CONFIRMATION, WAITING_PHONE }

private data class NovaSession(
    var state: NovaState = NovaState.IDLE,
    var lang: NovaLang = NovaLang.ROMAN,
    var app: String = "",
    var recipient: String = "",
    var message: String = "",
    var callRecipient: String = "",
    var lastCommand: String = ""
)

class MainActivity : androidx.fragment.app.FragmentActivity() {
    private lateinit var tts: TextToSpeech
    private lateinit var naturalTts: NovaNaturalTts
    private lateinit var db: NovaDatabase
    private lateinit var androidRouter: NovaAndroidCommandRouter

    private var onVoiceResult: ((String) -> Unit)? = null
    private var speechRecognizer: SpeechRecognizer? = null
    private var speechFallbackTried = false
    private var novaFemaleVoice: Voice? = null
    private var continuousListening = false
    private var speakingNow = false
    private var lastSpokenText = ""
    private val voicePrefsName = "nova_voice_settings"
    private val session = NovaSession()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        naturalTts = NovaNaturalTts(this)
        db = NovaDatabase(applicationContext)
        androidRouter = NovaAndroidCommandRouter(applicationContext)
        // Prevent an old wake-service instance from competing with the manual Voice button.
        stopService(Intent(this, NovaWakeService::class.java))
        continuousListening = getSharedPreferences(voicePrefsName, MODE_PRIVATE).getBoolean("continuous_listening", false)
        NovaLogger.info(this, "Nova started; health=${NovaHealth.check(this).ok}")
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                configureNovaFemaleVoice()
                tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) { speakingNow = true }
                    override fun onDone(utteranceId: String?) {
                        speakingNow = false
                        if (continuousListening && !isFinishing && !isDestroyed) {
                            startWakeListeningService()
                        }
                    }
                    override fun onError(utteranceId: String?) {
                        speakingNow = false
                        if (continuousListening && !isFinishing && !isDestroyed) startWakeListeningService()
                    }
                })
            }
        }

        val permissions = mutableListOf<String>()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            permissions += Manifest.permission.RECORD_AUDIO
        }
        if (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            permissions += Manifest.permission.READ_CONTACTS
        }
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            permissions += Manifest.permission.CAMERA
        }
        if (android.os.Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            permissions += Manifest.permission.POST_NOTIFICATIONS
        }
        if (permissions.isNotEmpty()) {
            requestPermissions(permissions.toTypedArray(), 50)
        }

        val deviceId = Settings.Secure.getString(contentResolver, Settings.Secure.ANDROID_ID) ?: "unknown-device"
        setContent {
            NovaApp(
                deviceId = deviceId,
                startVoice = { callback -> startNovaListening(callback) },
                speak = { speakNova(it) },
                continuousListeningState = continuousListening,
                initialWakeCommand = intent.getStringExtra("nova_wake_command"),
                setContinuousListening = { enabled ->
                    continuousListening = enabled
                    getSharedPreferences(voicePrefsName, MODE_PRIVATE).edit()
                        .putBoolean("continuous_listening", enabled).apply()
                    if (enabled) startWakeListeningService()
                    else stopService(Intent(this, NovaWakeService::class.java))
                }
            )
        }

        // Siri-style cold start: if Nova was opened by the wake service with a command,
        // execute that command immediately instead of only showing the app.
        intent.getStringExtra("nova_wake_command")?.let { command ->
            window.decorView.postDelayed({ handleWakeCommand(command) }, 350L)
        }
    }

    private fun startNovaListening(callback: (String) -> Unit) {
        // Manual voice owns the microphone. Pause continuous wake listening first.
        stopService(Intent(this, NovaWakeService::class.java))
        speechRecognizer?.cancel()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 50)
            speakNova("Microphone permission allow karein.")
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            speakNova("Speech recognition service available nahi hai. Google Speech Services update karein.")
            return
        }

        onVoiceResult = callback
        speechFallbackTried = false
        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this).also { recognizer ->
            recognizer.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}

                override fun onResults(results: Bundle?) {
                    val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull()?.trim().orEmpty()
                    if (text.isBlank()) {
                        if (!speechFallbackTried) {
                            speechFallbackTried = true
                            startSpeechAttempt("en-US")
                        } else {
                            speakNova("Mujhe awaaz clear nahi mili. Dobara Voice dabakar bolain.")
                        }
                        return
                    }
                    callback(text)
                    speechRecognizer?.cancel()
                }

                override fun onError(error: Int) {
                    if (!speechFallbackTried && error in setOf(
                            SpeechRecognizer.ERROR_NO_MATCH,
                            SpeechRecognizer.ERROR_SPEECH_TIMEOUT,
                            SpeechRecognizer.ERROR_NETWORK,
                            SpeechRecognizer.ERROR_NETWORK_TIMEOUT
                        )) {
                        speechFallbackTried = true
                        startSpeechAttempt("en-US")
                    } else {
                        val msg = when (error) {
                            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission required hai."
                            SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Speech recognizer busy hai. Ek second baad dobara try karein."
                            else -> "Mujhe awaaz clear nahi mili. Dobara Voice dabakar bolain."
                        }
                        speakNova(msg)
                    }
                }
            })
        }
        startSpeechAttempt("ur-PK")
    }

    private fun startSpeechAttempt(language: String) {
        val recognizer = speechRecognizer ?: return
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, language)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, language)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        }
        recognizer.cancel()
        recognizer.startListening(intent)
    }

    private fun startWakeListeningService() {
        if (!continuousListening || speakingNow) return
        stopService(Intent(this, NovaWakeService::class.java))
        if (android.os.Build.VERSION.SDK_INT >= 26) {
            androidx.core.content.ContextCompat.startForegroundService(this, Intent(this, NovaWakeService::class.java))
        } else {
            startService(Intent(this, NovaWakeService::class.java))
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        // Voice is started only when the user taps Voice. The wake service is optional and
        // must not run at the same time as foreground voice recognition because both compete
        // for the microphone on many Android devices.
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        intent.getStringExtra("nova_remote_command")?.let { command ->
            handleRemoteCommand(command)
            return
        }
        intent.getStringExtra("nova_wake_command")?.let { command ->
            handleWakeCommand(command)
        }
    }

    private fun handleRemoteCommand(command: String) {
        val text = command.trim()
        if (text.isBlank()) return
        val result = androidRouter.execute(text, confirmed = false)
        speakNova(result.message)
    }

    /** Siri-style command pipeline: understand -> act -> speak result. */
    private fun handleWakeCommand(command: String) {
        val text = command.trim()
        if (text.isBlank()) {
            speakNova("Ji, main sun rahi hoon. Batayein kya karna hai.")
            return
        }

        // Siri-style follow-up context: short replies can continue the previous task.
        val lower = text.lowercase(Locale.ROOT)

        // Global conversation controls: these are handled before any app/action routing.
        if (containsAny(lower, listOf("cancel", "stop", "bas karo", "cancel kar do", "rehne do"))) {
            session.state = NovaState.IDLE
            session.recipient = ""
            session.message = ""
            speakNova("Theek hai, current kaam cancel kar diya.")
            return
        }
        if (containsAny(lower, listOf("what can you do", "kya kar sakti ho", "kya kya kar sakti ho", "help", "madad"))) {
            speakNova("Main apps open kar sakti hoon, messages aur WhatsApp ke drafts bana sakti hoon, reminders aur calendar mein madad kar sakti hoon, screen samajh sakti hoon, aur phone ke supported controls chala sakti hoon. Aap seedha bol sakte hain.")
            return
        }
        if (containsAny(lower, listOf("status", "state", "ready ho", "tayyar ho"))) {
            val mode = if (continuousListening) "continuous listening on" else "tap-to-talk mode"
            val task = when (session.state) {
                NovaState.WAITING_RECIPIENT -> "recipient ka intezar"
                NovaState.WAITING_MESSAGE -> "message ka intezar"
                NovaState.WAITING_CONFIRMATION -> "message confirmation ka intezar"
                NovaState.WAITING_CALL_CONFIRMATION -> "call confirmation ka intezar"
                else -> "koi pending task nahi"
            }
            speakNova("Nova ready hai. $mode. $task.")
            return
        }
        if (session.state == NovaState.WAITING_RECIPIENT) {
            val recipient = text.removePrefix("to ").removePrefix("ko ").trim()
            if (recipient.isNotBlank()) {
                session.recipient = recipient
                session.state = NovaState.WAITING_MESSAGE
                speakNova(askMessage(recipient, session.lang))
                return
            }
        }
        if (session.state == NovaState.WAITING_MESSAGE) {
            session.message = text
            session.state = NovaState.WAITING_CONFIRMATION
            speakNova("${session.recipient} ko ye message bhejun: ${session.message}? Haan bolain to bhej doon.")
            return
        }
        if (session.state == NovaState.WAITING_CALL_CONFIRMATION) {
            if (isYes(text)) {
                val result = androidRouter.execute("call contact ${session.callRecipient}", confirmed = true)
                session.state = NovaState.IDLE
                session.callRecipient = ""
                speakNova(result.message)
                return
            }
            if (isNo(text)) {
                session.state = NovaState.IDLE
                session.callRecipient = ""
                speakNova("Theek hai, call cancel kar di.")
                return
            }
        }

        if (session.state == NovaState.WAITING_CONFIRMATION) {
            if (isYes(text)) {
                val result = androidRouter.execute(
                    "whatsapp contact ${session.recipient} say ${session.message}",
                    confirmed = true
                )
                session.state = NovaState.IDLE
                speakNova(result.message)
                return
            }
            if (isNo(text)) {
                session.state = NovaState.IDLE
                speakNova("Theek hai, message cancel kar diya.")
                return
            }
        }

        if (containsAny(lower, listOf("repeat", "again", "dobara", "phir se")) && session.lastCommand.isNotBlank()) {
            val result = androidRouter.execute(session.lastCommand, confirmed = false)
            speakNova(result.message)
            return
        }

        val conversational = when {
            text.equals("hello", true) || text.equals("hi", true) || text.equals("salam", true) ->
                "Hello! Main Nova hoon. Batayein kya karna hai?"
            text.contains("how are you", true) || text.contains("kaisi ho", true) || text.contains("kese ho", true) ->
                "Main bilkul ready hoon aur aapki madad ke liye tayyar hoon."
            text.contains("who are you", true) || text.contains("tum kon ho", true) || text.contains("aap kon ho", true) ->
                "Main Nova hoon, aapki Android voice assistant."
            else -> null
        }
        if (conversational != null) {
            speakNova(conversational)
            return
        }

        session.lastCommand = text
        val target = appTarget(text)
        if (target != null && containsAny(text, listOf("open", "kholo", "khol", "launch", "start", target.name))) {
            openTarget(this, target)
            session.app = target.name
            session.state = if (target.name.equals("WhatsApp", true)) NovaState.WAITING_RECIPIENT else NovaState.APP_OPENED
            session.lang = langOf(text)
            if (target.name.equals("WhatsApp", true)) {
                speakNova("WhatsApp khol diya hai. Kis ko message bhejna hai?")
            } else {
                speakNova("${target.name} khol diya hai. Kya karna hai?")
            }
            return
        }

        // Natural call requests: “Sajid ko call karo” / “call Sajid”.
        val callRecipient = extractCallRecipient(text)
        if (callRecipient != null) {
            session.callRecipient = callRecipient
            session.state = NovaState.WAITING_CALL_CONFIRMATION
            speakNova("${callRecipient} ko call karoon? Haan bolain to call kar doon.")
            return
        }

        // Natural follow-up such as: “Sajid ko message karo”
        if (isMessageIntent(text) && extractRecipient(text) != null) {
            session.lang = langOf(text)
            session.recipient = extractRecipient(text)!!.trim()
            session.state = NovaState.WAITING_MESSAGE
            speakNova(askMessage(session.recipient, session.lang))
            return
        }

        session.lastCommand = text
        session.state = NovaState.IDLE
        val result = androidRouter.execute(text, confirmed = false)
        speakNova(result.message)
        if (continuousListening && !result.requiresUserAction) {
            // Wake service is restarted by TTS completion.
        }
    }

    private fun configureNovaFemaleVoice() {
        val voices = tts.voices ?: emptySet()
        novaFemaleVoice = voices
            .filter { it.locale.language in setOf("ur", "en") }
            .sortedWith(compareBy<Voice>({ if (it.name.contains("female", true) || it.name.contains("woman", true)) 0 else 1 }, { if (it.locale.language == "ur") 0 else 1 }, { it.quality }))
            .firstOrNull()
        novaFemaleVoice?.let { tts.voice = it }
        tts.setPitch(1.08f)
        tts.setSpeechRate(0.96f)
    }

    private fun speakNova(text: String) {
        val clean = text.trim()
        if (clean.isBlank()) return
        lastSpokenText = clean
        // TTS must never share the microphone with recognition.
        speechRecognizer?.cancel()
        stopService(Intent(this, NovaWakeService::class.java))

        naturalTts.speak(
            text = clean,
            onStart = { speakingNow = true },
            onDone = { speakingNow = false },
            fallback = {
                runCatching {
                    val urdu = clean.any { it in '\u0600'..'\u06FF' }
                    val locale = if (urdu) Locale("ur", "PK") else Locale.US
                    tts.language = locale
                    val matching = (tts.voices ?: emptySet())
                        .filter { it.locale.language == locale.language }
                        .sortedWith(compareBy<Voice>({ if (it.name.contains("female", true) || it.name.contains("woman", true) || it.name.contains("zira", true)) 0 else 1 }, { it.quality }))
                        .firstOrNull()
                    matching?.let { tts.voice = it }
                    tts.setPitch(1.04f)
                    tts.setSpeechRate(0.94f)
                    tts.speak(clean, TextToSpeech.QUEUE_FLUSH, null, "nova-response-fallback")
                }.onFailure { speakingNow = false }
            }
        )
    }

    override fun onDestroy() {
        runCatching { naturalTts.shutdown() }
        stopService(Intent(this, NovaWakeService::class.java))
        NovaLogger.info(this, "Nova UI stopped")
        speechRecognizer?.cancel()
        speechRecognizer?.destroy()
        speechRecognizer = null
        tts.stop()
        tts.shutdown()
        db.close()
        super.onDestroy()
    }
}

private data class AppTarget(val name: String, val packageName: String?, val fallbackUrl: String? = null)

private fun appTarget(text: String): AppTarget? {
    val t = text.lowercase()
    return when {
        listOf("whatsapp", "واٹس ایپ").any(t::contains) -> AppTarget("WhatsApp", "com.whatsapp", "https://wa.me/")
        listOf("youtube", "یوٹیوب").any(t::contains) -> AppTarget("YouTube", "com.google.android.youtube", "https://youtube.com")
        listOf("chrome", "browser", "کروم", "براؤزر").any(t::contains) -> AppTarget("Chrome", "com.android.chrome", "https://www.google.com")
        listOf("calculator", "calc", "کیلکولیٹر").any(t::contains) -> AppTarget("Calculator", null, "https://www.google.com/search?q=calculator")
        listOf("settings", "سیٹنگز").any(t::contains) -> AppTarget("Settings", null)
        listOf("camera", "کیمرہ").any(t::contains) -> AppTarget("Camera", null)
        else -> null
    }
}

private fun openTarget(activity: ComponentActivity, target: AppTarget) {
    try {
        when (target.name) {
            "Settings" -> activity.startActivity(Intent(Settings.ACTION_SETTINGS))
            "Camera" -> activity.startActivity(Intent("android.media.action.IMAGE_CAPTURE"))
            else -> {
                val launched = target.packageName?.let { pkg ->
                    activity.packageManager.getLaunchIntentForPackage(pkg)?.also(activity::startActivity)
                }
                if (launched == null) target.fallbackUrl?.let {
                    activity.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(it)))
                }
            }
        }
    } catch (e: Exception) {
        target.fallbackUrl?.let { activity.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(it))) }
    }
}

private fun langOf(text: String): NovaLang {
    if (Regex("[\\u0600-\\u06FF]").containsMatchIn(text)) return NovaLang.URDU
    val t = text.lowercase()
    if (listOf("what", "open", "send", "message", "english", "yes", "no", "how are you").any(t::contains)) return NovaLang.ENGLISH
    return NovaLang.ROMAN
}

private fun containsAny(text: String, words: List<String>) = words.any { text.contains(it, ignoreCase = true) }

private fun openingReply(app: String, l: NovaLang) = when (l) {
    NovaLang.ENGLISH -> "$app is open. What would you like me to do?"
    NovaLang.URDU -> "$app کھل گیا ہے۔ آپ کیا کرنا چاہتے ہیں؟"
    NovaLang.ROMAN -> "$app khul gaya hai. Kya karna hai?"
}

private fun askRecipient(l: NovaLang) = when (l) {
    NovaLang.ENGLISH -> "Who should I message?"
    NovaLang.URDU -> "کس کو پیغام بھیجنا ہے؟"
    NovaLang.ROMAN -> "Kis ko message bhejna hai?"
}

private fun askMessage(name: String, l: NovaLang) = when (l) {
    NovaLang.ENGLISH -> "What message should I send to $name?"
    NovaLang.URDU -> "$name کو کیا پیغام بھیجنا ہے؟"
    NovaLang.ROMAN -> "$name ko kya message bhejna hai?"
}

private fun askLanguage(l: NovaLang) = when (l) {
    NovaLang.ENGLISH -> "Should I write it in English, Urdu, or Roman Urdu?"
    NovaLang.URDU -> "پیغام English، اردو یا Roman Urdu میں لکھنا ہے؟"
    NovaLang.ROMAN -> "Message English, Urdu ya Roman Urdu mein likhna hai?"
}

private fun isYes(t: String) = containsAny(t, listOf("yes", "haan", "han", "جی", "ہاں", "ok", "okay", "bhej do", "send karo"))
private fun isNo(t: String) = containsAny(t, listOf("no", "nahi", "نہیں", "cancel", "mat bhejo"))
private fun isMessageIntent(t: String) = containsAny(t, listOf("message", "msg", "پیغام", "میسج"))

private fun extractCallRecipient(text: String): String? {
    val t = text.trim()
    val patterns = listOf(
        Regex("(?i)^(?:call|phone|dial)\\s+(.+)$"),
        Regex("(?i)^(.+?)\\s+(?:ko|ki)\\s+(?:call|phone|dial)\\s*(?:karo|kar do|milao|mila do)?$")
    )
    for (p in patterns) {
        p.matchEntire(t)?.let {
            val name = it.groupValues[1].trim().removeSuffix(".")
            if (name.isNotBlank() && !containsAny(name.lowercase(Locale.ROOT), listOf("me", "mujhe", "phone"))) return name
        }
    }
    return null
}

private fun extractRecipient(t: String): String? {
    val x = t.replace("\n", " ").trim()
    listOf(
        Regex("(?i)(?:to|ko)\\s+([A-Za-z][A-Za-z0-9_-]{1,30})"),
        Regex("([A-Za-z][A-Za-z0-9_-]{1,30})\\s+(?:ko|message)")
    ).forEach { p -> p.find(x)?.groupValues?.getOrNull(1)?.let { return it } }
    if (Regex("[\\u0600-\\u06FF]").containsMatchIn(x)) {
        Regex("(?:کو|کی طرف)\\s*([\\u0600-\\u06FF]{2,30})").find(x)?.groupValues?.getOrNull(1)?.let { return it }
    }
    return null
}

private fun normalizeUrdu(message: String): String = when (message.trim().lowercase()) {
    "kya haal hai", "kya hal hai" -> "کیا حال ہے؟"
    "kaise ho" -> "کیسے ہو؟"
    "kaisi ho" -> "کیسی ہو؟"
    "theek ho" -> "ٹھیک ہو؟"
    "shukriya" -> "شکریہ"
    "salam", "assalam o alaikum" -> "السلام علیکم"
    else -> message
}

private fun normalizeEnglish(message: String): String = when (message.trim().lowercase()) {
    "kya haal hai", "kya hal hai", "kaise ho" -> "How are you?"
    "shukriya" -> "Thank you"
    "salam" -> "Hello"
    else -> message
}

private fun toFinalMessage(message: String, l: NovaLang) = when (l) {
    NovaLang.URDU -> normalizeUrdu(message)
    NovaLang.ENGLISH -> normalizeEnglish(message)
    NovaLang.ROMAN -> message.trim()
}

private fun openWhatsAppWithText(activity: ComponentActivity, message: String, phone: String? = null) {
    val target = if (!phone.isNullOrBlank()) {
        "https://wa.me/${phone.filter(Char::isDigit)}?text=${Uri.encode(message)}"
    } else "https://wa.me/?text=${Uri.encode(message)}"
    activity.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(target)))
}

@Composable
fun NovaApp(
    deviceId: String,
    startVoice: (((String) -> Unit)) -> Unit,
    speak: (String) -> Unit,
    continuousListeningState: Boolean,
    initialWakeCommand: String?,
    setContinuousListening: (Boolean) -> Unit
) {
    val activity = LocalContext.current as FragmentActivity
    val context = LocalContext.current
    val db = remember { NovaDatabase(context.applicationContext) }
    val androidRouter = remember { NovaAndroidCommandRouter(context.applicationContext) }
    val aiBrain = remember { NovaAiBrain(context.applicationContext) }
    val config = remember { NovaConfigStore.load(context) }
    var aiConfig by remember { mutableStateOf(NovaAiConfigStore.load(context)) }
    var aiKey by remember { mutableStateOf(NovaAiKeyStore.get(context).orEmpty()) }
    var aiModel by remember { mutableStateOf(aiConfig.model) }
    var pcIp by remember { mutableStateOf("") }
    var pcPort by remember { mutableStateOf(config.pcPort.toString()) }
    var remoteConfig by remember { mutableStateOf(NovaRemoteConfigStore.load(context)) }
    var remoteEndpoint by remember { mutableStateOf(remoteConfig.endpoint) }
    var remotePollSeconds by remember { mutableStateOf(remoteConfig.pollSeconds.toString()) }
    val secureStore = remember { NovaSecureStore(context) }
    var code by remember { mutableStateOf("") }
    var command by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("Ready") }
    var answer by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var pendingPcCommand by remember { mutableStateOf("") }
    var pendingPcChallenge by remember { mutableStateOf("") }
    var pendingAndroidCommand by remember { mutableStateOf("") }
    var session by remember { mutableStateOf(NovaSession()) }

    fun respond(text: String) {
        answer = "Nova: $text"
        db.saveConversation(session.lang.name, command, text)
        NovaLogger.info(context, "Response generated: ${text.take(100)}")
        speak(text)
    }

    fun sendToPc(input: String, confirmation: String = "") {
        if (pcIp.isBlank() || input.isBlank()) return
        val token = secureStore.token; val secret = secureStore.secret
        if (token.isNullOrBlank() || secret.isNullOrBlank()) { status = "Pair this device first"; return }
        busy = true; status = "Secure connection..."
        Thread {
            try {
                val c = URL("http://${pcIp.trim()}:${pcPort.toIntOrNull() ?: config.pcPort}/nova/command").openConnection() as HttpURLConnection
                c.requestMethod = "POST"; c.doOutput = true
                c.connectTimeout = config.requestTimeoutMs; c.readTimeout = config.requestTimeoutMs
                c.setRequestProperty("Content-Type", "application/json")
                c.setRequestProperty("X-Nova-Device", deviceId)
                c.setRequestProperty("X-Nova-Token", token)
                val request = JSONObject().put("action", "command").put("command", input)
                if (confirmation.isNotBlank()) request.put("confirmation", confirmation)
                c.outputStream.use { it.write(secureEnvelope(secret, request).toString().toByteArray()) }
                val body = c.inputStream.bufferedReader().readText(); c.disconnect()
                val msgJson = decryptEnvelope(secret, body)
                if (msgJson.optBoolean("confirmation_required")) {
                    val challenge = msgJson.optString("challenge")
                    activity.runOnUiThread { pendingPcCommand = input; pendingPcChallenge = challenge; answer = "Confirmation required. Say YES to allow this action or NO to cancel."; status = "Waiting for confirmation"; busy = false }
                    return@Thread
                }
                val msg = msgJson.optString("message", msgJson.toString())
                activity.runOnUiThread { answer = "Nova: $msg"; status = "Command accepted"; busy = false; speak(msg) }
            } catch (e: Exception) {
                NovaLogger.error(context, "Secure PC command failed", e)
                activity.runOnUiThread { answer = "Nova se secure connection nahi ho saka."; status = "Secure connection failed"; busy = false }
            }
        }.start()
    }

    fun localConversation(text: String): String? {
        val t = text.trim().lowercase(Locale.ROOT)
        val l = langOf(text)

        // Smart notification intelligence. This reads only notifications that the
        // user explicitly granted Nova access to; it never invents notification text.
        if (containsAny(t, listOf("latest notifications", "latest notification", "new notifications", "new notification", "recent notifications", "notifications batao", "notification batao", "notification sunao", "notifications sunao", "unread notifications", "unread notification", "important notifications", "important notification", "نئی notifications", "نوٹیفکیشن بتاؤ"))) {
            val service = NovaNotificationListenerService.instance
            if (service == null) return "Notification access enabled nahi hai. Settings mein Nova Notification Access on karein."
            val important = containsAny(t, listOf("important", "اہم"))
            val unread = containsAny(t, listOf("unread", "unread notifications", "نہیں پڑھے"))
            val rows = service.list(unread = unread, important = important)
            if (rows.length() == 0) return if (important) "Koi important notification nahi mili." else "Koi matching notification nahi mili."
            val limit = minOf(rows.length(), 6)
            val parts = ArrayList<String>()
            for (i in 0 until limit) {
                val o = rows.optJSONObject(i) ?: continue
                val title = o.optString("title").trim()
                val body = o.optString("text").trim()
                val line = listOf(title, body).filter { it.isNotBlank() }.joinToString(": ")
                if (line.isNotBlank()) parts.add("${i + 1}. ${line.take(220)}")
            }
            if (parts.isEmpty()) return "Notifications mili hain lekin unka text available nahi hai."
            return when (l) {
                NovaLang.ENGLISH -> "I found ${parts.size} notifications.\n" + parts.joinToString("\n")
                NovaLang.URDU -> "مجھے ${parts.size} نوٹیفکیشن ملی ہیں۔\n" + parts.joinToString("\n")
                NovaLang.ROMAN -> "Mujhe ${parts.size} notifications mili hain.\n" + parts.joinToString("\n")
            }
        }

        val appNotification = Regex("(?i)(?:notification|message)\s+(?:from|ka|ki|se)\s+(.+)$").find(text.trim())
        if (appNotification != null || containsAny(t, listOf("ka message kya hai", "ki notification kya hai", "ka notification batao", "ka message batao"))) {
            val query = appNotification?.groupValues?.getOrNull(1)?.trim()?.ifBlank { null }
                ?: Regex("(?i)^(.+?)\s+(?:ka|ki)\s+(?:message|notification)").find(text.trim())?.groupValues?.getOrNull(1)?.trim()
            if (!query.isNullOrBlank()) {
                val service = NovaNotificationListenerService.instance
                    ?: return "Notification Access on karein, phir main ${query} ki notification dekh sakti hoon."
                val rows = service.list(query = query)
                if (rows.length() == 0) return "${query} ki recent notification nahi mili."
                val o = rows.optJSONObject(0)
                val title = o?.optString("title").orEmpty()
                val body = o?.optString("text").orEmpty()
                val message = listOf(title, body).filter { it.isNotBlank() }.joinToString(": ")
                return if (message.isBlank()) "${query} ki notification mili hai lekin text available nahi hai." else "${query} ki latest notification: $message"
            }
        }

        // User-controlled long-term memory commands. Memory is never silently inferred
        // into a profile: Nova only saves explicit "remember" requests.
        val rememberMatch = Regex("(?i)^(?:nova[, ]*)?(?:remember|yaad rakho|yaad rakhna|یاد رکھو|یاد رکھنا)\\s*[:,-]?\\s*(.+)$").find(text.trim())
        if (rememberMatch != null) {
            val value = rememberMatch.groupValues[1].trim()
            db.remember("preference", value)
            db.saveTask(text, "saved", "Memory added")
            return "Theek hai, main is baat ko yaad rakhungi."
        }
        if (containsAny(t, listOf("what do you remember", "meri memory", "memory dikhao", "yaad kya hai", "what you remember", "میری میموری"))) {
            val memories = db.listMemories()
            return if (memories.isEmpty()) {
                "Abhi koi saved memory nahi hai."
            } else {
                memories.joinToString("\n") { "• ${it.second}" }
            }
        }
        if (containsAny(t, listOf("forget everything", "clear memory", "memory clear", "sab yaad bhool jao", "ساری میموری صاف"))) {
            val count = db.clearMemories()
            db.saveTask(text, "completed", "Cleared $count memories")
            return "$count saved memories clear kar di hain."
        }
        return when {
            containsAny(t, listOf("hello", "hi", "hey", "assalam", "salam", "السلام")) -> when (l) {
                NovaLang.ENGLISH -> "Hello! I am Nova. How can I help you?"
                NovaLang.URDU -> "وعلیکم السلام! میں Nova ہوں۔ میں آپ کی کیا مدد کروں؟"
                NovaLang.ROMAN -> "Assalam o Alaikum! Main Nova hoon. Batayein kya karna hai?"
            }
            containsAny(t, listOf("how are you", "kaisi ho", "kese ho", "kaise ho", "کیسی ہو", "کیسے ہو")) -> when (l) {
                NovaLang.ENGLISH -> "I am ready and working."
                NovaLang.URDU -> "میں بالکل تیار ہوں اور کام کر رہی ہوں۔"
                NovaLang.ROMAN -> "Main bilkul ready hoon aur kaam kar rahi hoon."
            }
            containsAny(t, listOf("who are you", "tum kon ho", "aap kon ho", "کون ہو")) -> when (l) {
                NovaLang.ENGLISH -> "I am Nova, your Android assistant."
                NovaLang.URDU -> "میں Nova ہوں، آپ کی Android assistant۔"
                NovaLang.ROMAN -> "Main Nova hoon, aap ki Android assistant."
            }
            containsAny(t, listOf("what can you do", "kya kar sakti ho", "kya kya kar sakti ho", "کیا کر سکتی ہو")) -> when (l) {
                NovaLang.ENGLISH -> "I can open apps, control supported phone functions, read the screen when accessibility is enabled, manage reminders and help with WhatsApp drafts."
                NovaLang.URDU -> "میں apps کھول سکتی ہوں، supported phone controls چلا سکتی ہوں، Accessibility کے بعد screen پڑھ سکتی ہوں، reminders اور WhatsApp drafts میں مدد کر سکتی ہوں۔"
                NovaLang.ROMAN -> "Main apps khol sakti hoon, supported phone controls chala sakti hoon, Accessibility ke baad screen read kar sakti hoon, reminders aur WhatsApp drafts mein help kar sakti hoon."
            }
            containsAny(t, listOf("help", "madad", "madad chahiye", "مدد")) -> when (l) {
                NovaLang.ENGLISH -> "Try: Nova open WhatsApp, Nova open YouTube, Nova battery, Nova screenshot, Nova volume up, or Nova screen read."
                NovaLang.URDU -> "Aap keh sakte hain: Nova WhatsApp kholo، YouTube kholo، battery batao، screenshot lo، volume barhao، ya screen read karo۔"
                NovaLang.ROMAN -> "Aap keh sakte hain: Nova WhatsApp kholo, YouTube kholo, battery batao, screenshot lo, volume barhao, ya screen read karo."
            }
            containsAny(t, listOf("thank you", "thanks", "shukriya", "شکریہ")) -> when (l) {
                NovaLang.ENGLISH -> "You're welcome."
                NovaLang.URDU -> "خوش آمدید۔"
                NovaLang.ROMAN -> "Khushi se."
            }
            else -> null
        }
    }

    fun handleLocal(input: String): Boolean {
        val text = input.trim()
        if (text.isBlank()) return true
        command = text
        localConversation(text)?.let {
            respond(it)
            return true
        }
        if (pendingAndroidCommand.isNotBlank()) {
            if (isYes(text)) {
                val pending = pendingAndroidCommand
                pendingAndroidCommand = ""
                val result = androidRouter.execute(pending, confirmed = true)
                respond(result.message)
                return true
            }
            if (isNo(text)) {
                pendingAndroidCommand = ""
                respond("Okay, Android action cancelled.")
                return true
            }
            respond("Please say YES to confirm or NO to cancel.")
            return true
        }
        if (pendingPcChallenge.isNotBlank()) {
            if (isYes(text)) {
                val pcCommand = pendingPcCommand; val challenge = pendingPcChallenge
                NovaBiometricAuth.confirm(activity, "Confirm this protected Nova action") { approved ->
                    if (approved) {
                        pendingPcCommand = ""; pendingPcChallenge = ""
                        sendToPc(pcCommand, challenge)
                    } else {
                        pendingPcCommand = ""; pendingPcChallenge = ""
                        activity.runOnUiThread { respond("Biometric confirmation nahi mili. Action cancel kar diya.") }
                    }
                }
                return true
            }
            if (isNo(text)) {
                pendingPcCommand = ""; pendingPcChallenge = ""
                respond("Okay, action cancelled."); return true
            }
            respond("Please say YES to confirm or NO to cancel."); return true
        }
        val detected = langOf(text)
        session = session.copy(lang = detected)

        when (session.state) {
            NovaState.APP_OPENED -> if (isMessageIntent(text)) {
                val name = extractRecipient(text)
                session = if (name != null) session.copy(state = NovaState.WAITING_MESSAGE, recipient = name)
                else session.copy(state = NovaState.WAITING_RECIPIENT)
                respond(if (name != null) askMessage(name, session.lang) else askRecipient(session.lang))
                return true
            }
            NovaState.WAITING_RECIPIENT -> {
                session = session.copy(state = NovaState.WAITING_MESSAGE, recipient = text)
                respond(askMessage(text, session.lang)); return true
            }
            NovaState.WAITING_MESSAGE -> {
                session = session.copy(state = NovaState.WAITING_LANGUAGE, message = text)
                respond(askLanguage(session.lang)); return true
            }
            NovaState.WAITING_PHONE -> {
                val phone = text.filter(Char::isDigit)
                if (phone.length >= 10) {
                    openWhatsAppWithText(activity, session.message, phone)
                    respond("WhatsApp mein message tayyar hai. Check karke Send dabayein.")
                    session = NovaSession(lang = session.lang)
                } else respond("Please valid WhatsApp number batayein.")
                return true
            }
            NovaState.WAITING_LANGUAGE -> {
                val chosen = when {
                    containsAny(text, listOf("english", "انگلش")) -> NovaLang.ENGLISH
                    containsAny(text, listOf("urdu", "اردو")) -> NovaLang.URDU
                    containsAny(text, listOf("roman", "roman urdu")) -> NovaLang.ROMAN
                    else -> session.lang
                }
                val final = toFinalMessage(session.message, chosen)
                session = session.copy(state = NovaState.WAITING_CONFIRMATION, lang = chosen, message = final)
                respond(when (chosen) {
                    NovaLang.ENGLISH -> "Your message is ready: \"$final\". Shall I open WhatsApp with it?"
                    NovaLang.URDU -> "آپ کا پیغام تیار ہے: \"$final\"۔ کیا میں اسے WhatsApp میں تیار کر دوں؟"
                    NovaLang.ROMAN -> "Message tayyar hai: \"$final\". Kya WhatsApp mein tayyar kar doon?"
                }); return true
            }
            NovaState.WAITING_CONFIRMATION -> {
                if (isYes(text)) {
                    val phone = db.getContact(session.recipient) ?: ""
                    if (phone.isBlank()) {
                        session = session.copy(state = NovaState.WAITING_PHONE)
                        respond("${session.recipient} ka number save nahi hai. WhatsApp number batayein.")
                    } else {
                        openWhatsAppWithText(activity, session.message, phone)
                        respond("WhatsApp mein message tayyar hai. Check karke Send dabayein.")
                        session = NovaSession(lang = session.lang)
                    }
                    return true
                }
                if (isNo(text)) {
                    val l = session.lang
                    session = NovaSession(lang = l)
                    respond(if (l == NovaLang.URDU) "Theek hai, cancel kar diya." else "Okay, cancelled.")
                    return true
                }
            }
            else -> Unit
        }

        // Natural WhatsApp navigation example: "Ali ki chat kholo".
        val chat = Regex("(?i)^(.+?)\\s+(?:ki|ka)\\s+chat\\s+(?:kholo|khol|open)").find(text)
        if (chat != null && containsAny(text, listOf("chat", "whatsapp", "ki chat", "ka chat"))) {
            val name = chat.groupValues[1].trim()
            val accessChat = NovaAccessibilityService.instance
            if (accessChat == null) {
                respond("WhatsApp ki visible UI control ke liye Nova Accessibility Service enable karein.")
            } else {
                val ok = accessChat.clickText(name)
                if (ok) {
                    session = session.copy(state = NovaState.WAITING_MESSAGE, recipient = name)
                    respond("$name ki chat khol di. Kya message tayyar karna hai?")
                } else respond("$name ki visible WhatsApp chat nahi mili.")
            }
            return true
        }

        // Unified Android device/app/UI control. Protected actions are confirmed once.
        val androidResult = androidRouter.execute(text, confirmed = false)
        if (androidResult.success || androidResult.requiresUserAction || androidResult.message.startsWith("Yeh Android action")) {
            if (androidRouter.isHighImpact(text) && !androidResult.success) {
                pendingAndroidCommand = text
                respond(androidResult.message)
            } else {
                respond(androidResult.message)
            }
            return true
        }

        // Explicit Android UI control. Requires the user to enable Nova Accessibility Service.
        val access = NovaAccessibilityService.instance
        if (access != null) {
            if (containsAny(text, listOf("back", "go back", "peeche jao", "wapas jao", "پیچھے جاؤ"))) {
                val ok = access.back(); respond(if (ok) "Back ho gaya hai." else "Back action nahi ho saka."); return true
            }
            if (containsAny(text, listOf("home", "home screen", "ghar jao", "home par jao", "ہوم"))) {
                val ok = access.home(); respond(if (ok) "Home screen open kar di." else "Home action nahi ho saka."); return true
            }
            val click = Regex("(?i)^(?:click|press|tap|dabao|click karo|press karo)\\s+(.+)$").find(text)
            if (click != null) {
                val targetText = click.groupValues[1].trim()
                val ok = access.clickText(targetText)
                respond(if (ok) "'$targetText' par click kar diya." else "'$targetText' ka visible control nahi mila."); return true
            }
            val fillTarget = Regex("(?i)^(?:type|enter|likho|fill)\\s+(.+?)\\s+(?:in|into|mein|me)\\s+(.+)$").find(text)
            if (fillTarget != null) {
                val value = fillTarget.groupValues[1].trim()
                val target = fillTarget.groupValues[2].trim()
                val ok = access.setTextOn(target, value)
                respond(if (ok) "'$target' field fill kar di." else "'$target' ki visible field nahi mili."); return true
            }
            val fill = Regex("(?i)^(?:type|enter|likho|fill)\\s+(.+)$").find(text)
            if (fill != null) {
                val ok = access.setText(fill.groupValues[1].trim())
                respond(if (ok) "Text field fill kar di." else "Visible text field nahi mili."); return true
            }
            if (containsAny(text, listOf("recent apps", "recents", "recent kholo", "recent apps kholo"))) {
                val ok = access.recents(); respond(if (ok) "Recent apps open kar di." else "Recent apps open nahi ho sakin."); return true
            }
            if (containsAny(text, listOf("notifications", "notification kholo", "notifications kholo"))) {
                val ok = access.notifications(); respond(if (ok) "Notifications open kar di." else "Notifications open nahi ho sakin."); return true
            }
            if (containsAny(text, listOf("scroll down", "neeche scroll", "neeche karo", "scroll neeche"))) {
                val ok = access.scrollForward(); respond(if (ok) "Neeche scroll kar diya." else "Scroll nahi ho saka."); return true
            }
            if (containsAny(text, listOf("scroll up", "upar scroll", "upar karo", "scroll upar"))) {
                val ok = access.scrollBackward(); respond(if (ok) "Upar scroll kar diya." else "Scroll nahi ho saka."); return true
            }
            if (containsAny(text, listOf("screen read", "screen dekho", "screen par kya hai", "visible ui", "screen samjho"))) {
                val nodes = access.visibleUi(80)
                respond(if (nodes.isEmpty()) "Visible UI read nahi ho saki." else nodes.take(20).joinToString("\n"))
                return true
            }
        }
        if (containsAny(text, listOf("accessibility on", "accessibility enable", "nova accessibility", "accessibility service"))) {
            activity.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            respond("Android Accessibility Settings open kar di hain. Wahan Nova Accessibility Service enable karein.")
            return true
        }

        val target = appTarget(text)
        if (target != null && containsAny(text, listOf("open", "kholo", "khol", "کھولو", "کھول", "launch", "start", target.name))) {
            openTarget(activity, target)
            session = NovaSession(state = NovaState.APP_OPENED, lang = detected, app = target.name)
            respond(openingReply(target.name, detected))
            return true
        }
        val pcIntent = containsAny(text.lowercase(Locale.ROOT), listOf("pc ", "computer", "laptop", "desktop", "computer par", "pc par"))
        if (pcIp.isNotBlank() && pcIntent) {
            sendToPc(text)
            status = "Sending to PC..."
        } else if (aiBrain.isConfigured()) {
            status = "Nova AI thinking..."
            aiBrain.interpret(text) { result ->
                activity.runOnUiThread {
                    result.onSuccess { intent ->
                        when (intent.type) {
                            "PLAN" -> {
                                val steps = intent.steps
                                if (steps.isEmpty()) {
                                    respond(intent.text.ifBlank { "Plan empty hai." })
                                } else {
                                    status = "AI Agent: ${steps.size} steps"
                                    speak(intent.text.ifBlank { "Main requested steps execute kar rahi hoon." })
                                    var stopped = false
                                    for ((index, step) in steps.withIndex()) {
                                        if (stopped) break
                                        when (step.type) {
                                            "OPEN_APP" -> {
                                                val target = appTarget(step.app)
                                                if (target != null) {
                                                    openTarget(activity, target)
                                                } else {
                                                    stopped = true
                                                    respond("Step ${index + 1}: app supported nahi hai.")
                                                }
                                            }
                                            "ANDROID" -> {
                                                val normalized = step.command
                                                val r = androidRouter.execute(normalized, confirmed = false)
                                                if (r.success) {
                                                    answer = "Nova: Step ${index + 1}/${steps.size} — ${r.message}"
                                                } else if (r.requiresUserAction) {
                                                    pendingAndroidCommand = normalized
                                                    stopped = true
                                                    respond("Step ${index + 1} ke liye confirmation/permission chahiye. ${r.message}")
                                                } else {
                                                    stopped = true
                                                    respond("Step ${index + 1} nahi ho saka: ${r.message}")
                                                }
                                            }
                                            "PC" -> {
                                                if (pcIp.isBlank()) {
                                                    stopped = true
                                                    respond("Step ${index + 1}: PC paired nahi hai.")
                                                } else {
                                                    sendToPc(step.command)
                                                    stopped = true
                                                }
                                            }
                                            else -> {
                                                stopped = true
                                                respond("Step ${index + 1}: unsupported action.")
                                            }
                                        }
                                    }
                                    if (!stopped) {
                                        status = "AI Agent complete"
                                        answer = "Nova: ${intent.text.ifBlank { "All requested steps complete." }}"
                                        db.saveConversation(session.lang.name, text, answer.removePrefix("Nova: "))
                                    }
                                }
                            }
                            "ANDROID" -> {
                                val normalized = intent.command.ifBlank { text }
                                val r = androidRouter.execute(normalized, confirmed = false)
                                if (r.success) respond(r.message)
                                else if (r.requiresUserAction) {
                                    pendingAndroidCommand = normalized
                                    respond(r.message)
                                } else respond(r.message)
                            }
                            "PC" -> {
                                if (pcIp.isBlank()) respond("PC paired nahi hai. Pehle PC IP ya QR pairing complete karein.")
                                else sendToPc(intent.command.ifBlank { text })
                            }
                            "OPEN_APP" -> {
                                val target = appTarget(intent.app)
                                if (target != null) {
                                    openTarget(activity, target)
                                    respond(openingReply(target.name, langOf(text)))
                                } else {
                                    respond("Ye app abhi Nova ke quick-open list mein nahi hai.")
                                }
                            }
                            else -> {
                                val reply = intent.text.ifBlank { "Mujhe samajh aa gaya, lekin jawab empty mila." }
                                answer = "Nova: $reply"
                                status = "AI ready"
                                db.saveConversation(session.lang.name, text, reply)
                                NovaLogger.info(context, "AI response generated: ${reply.take(100)}")
                                speak(reply)
                            }
                        }
                    }.onFailure { error ->
                        status = "AI error"
                        respond("AI se connection nahi ho saka: ${error.message ?: "unknown error"}")
                    }
                }
            }
        } else {
            respond(when (langOf(text)) {
                NovaLang.ENGLISH -> "I heard you. For normal AI conversation, open AI Setup and add your Gemini API key. Local commands are still available."
                NovaLang.URDU -> "میں نے آپ کی بات سن لی۔ عام AI گفتگو کے لیے AI Setup میں Gemini API key شامل کریں۔ Local commands ابھی بھی available ہیں۔"
                NovaLang.ROMAN -> "Main ne aap ki baat sun li. Normal AI conversation ke liye AI Setup mein Gemini API key add karein. Local commands abhi bhi available hain."
            })
        }
        return true
    }

    LaunchedEffect(initialWakeCommand) {
        val wakeCommand = initialWakeCommand?.trim().orEmpty()
        if (wakeCommand.isNotBlank()) {
            handleLocal(wakeCommand)
        }
    }

    fun rotatePcToken() {
        val token = secureStore.token; val secret = secureStore.secret
        if (pcIp.isBlank() || token.isNullOrBlank() || secret.isNullOrBlank()) { status = "Pair this device first"; return }
        busy = true; status = "Rotating secure session..."
        Thread {
            try {
                val c = URL("http://${pcIp.trim()}:${pcPort.toIntOrNull() ?: config.pcPort}/nova/command").openConnection() as HttpURLConnection
                c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = config.requestTimeoutMs; c.readTimeout = config.requestTimeoutMs
                c.setRequestProperty("Content-Type", "application/json"); c.setRequestProperty("X-Nova-Device", deviceId); c.setRequestProperty("X-Nova-Token", token)
                c.outputStream.use { it.write(secureEnvelope(secret, JSONObject().put("action", "rotate_token")).toString().toByteArray()) }
                val body = c.inputStream.bufferedReader().readText(); c.disconnect(); val rotated = decryptEnvelope(secret, body)
                if (!rotated.optBoolean("ok")) throw IllegalStateException(rotated.optString("error", "Token rotation failed"))
                secureStore.token = rotated.getString("token"); secureStore.secret = rotated.getString("secret"); secureStore.role = rotated.optString("role", secureStore.role); secureStore.tokenExpiresAt = rotated.optLong("token_expires_at", 0L)
                activity.runOnUiThread { status = "Secure session rotated"; busy = false; speak("Secure session rotated") }
            } catch (e: Exception) { activity.runOnUiThread { status = "Token rotation failed"; busy = false; answer = e.message ?: "Rotation failed" } }
        }.start()
    }

    MaterialTheme {
        Surface(Modifier.fillMaxSize()) {
            Column(
                Modifier.padding(20.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("Nova AI", style = MaterialTheme.typography.headlineMedium)
                Text("Urdu • Roman Urdu • English", style = MaterialTheme.typography.titleMedium)
                Text("State: ${session.state}", style = MaterialTheme.typography.bodySmall)
                OutlinedTextField(pcIp, { pcIp = it }, label = { Text("PC IP address") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                OutlinedTextField(code, { code = it }, label = { Text("6-digit pairing code") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                Button(enabled = !busy && pcIp.isNotBlank() && code.length == 6, onClick = {
                    busy = true; status = "Pairing..."
                    Thread {
                        try {
                            val c = URL("http://${pcIp.trim()}:${pcPort.toIntOrNull() ?: config.pcPort}/nova/pair").openConnection() as HttpURLConnection
                            c.requestMethod = "POST"; c.doOutput = true
                            c.connectTimeout = config.requestTimeoutMs; c.readTimeout = config.requestTimeoutMs
                            c.setRequestProperty("Content-Type", "application/json")
                            c.outputStream.use {
                                it.write(JSONObject(mapOf("code" to code, "device_id" to deviceId, "device_name" to "Nova Android")).toString().toByteArray())
                            }
                            val body = c.inputStream.bufferedReader().readText(); c.disconnect()
                            val paired = JSONObject(body)
                            if (!paired.optBoolean("ok")) throw IllegalStateException(paired.optString("error", "Pairing failed"))
                            secureStore.token = paired.getString("token")
                            secureStore.secret = paired.getString("secret")
                            secureStore.role = paired.optString("role", "operator")
                            secureStore.tokenExpiresAt = paired.optLong("token_expires_at", 0L)
                            activity.runOnUiThread { status = "Securely paired (${secureStore.role})"; busy = false; speak("Mobile securely paired with Nova") }
                        } catch (e: Exception) {
                            NovaLogger.error(context, "Pairing failed", e)
                            activity.runOnUiThread { status = "Pairing failed"; answer = e.message ?: "Pairing error"; busy = false }
                        }
                    }.start()
                }, modifier = Modifier.fillMaxWidth()) { Text("Pair Mobile") }
                Button(enabled = !busy, onClick = {
                    NovaQrPairing.scan(context) { info ->
                        activity.runOnUiThread {
                            if (info == null) { status = "QR invalid or expired"; return@runOnUiThread }
                            pcIp = info.host; pcPort = info.port.toString(); code = info.code
                            status = "QR scanned — press Pair Mobile"
                        }
                    }
                }, modifier = Modifier.fillMaxWidth()) { Text("Scan Pairing QR") }

                HorizontalDivider()
                Text("Device ID: $deviceId")
                Text("Status: $status")
                Text("Role: ${secureStore.role} • Token: ${if (secureStore.tokenExpired()) "expired" else "active"}", style = MaterialTheme.typography.bodySmall)

                Text("AI Brain", style = MaterialTheme.typography.titleLarge)
                Text(
                    if (aiConfig.enabled && aiKey.isNotBlank()) "Gemini AI: CONFIGURED" else "Gemini AI: NOT CONFIGURED",
                    style = MaterialTheme.typography.bodySmall
                )
                OutlinedTextField(
                    value = aiModel,
                    onValueChange = { aiModel = it },
                    label = { Text("Gemini model") },
                    supportingText = { Text("Example: gemini-3.8-flash") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                OutlinedTextField(
                    value = aiKey,
                    onValueChange = { aiKey = it },
                    label = { Text("Gemini API key") },
                    visualTransformation = PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = {
                        aiConfig = NovaAiConfig(provider = "GEMINI", model = aiModel.trim().ifBlank { "gemini-3.8-flash" }, enabled = aiKey.isNotBlank())
                        NovaAiConfigStore.save(context, aiConfig)
                        NovaAiKeyStore.set(context, aiKey)
                        status = if (aiKey.isBlank()) "AI key cleared" else "AI setup saved"
                        speak(if (aiKey.isBlank()) "AI key clear kar di." else "AI setup save ho gaya.")
                    }, modifier = Modifier.weight(1f)) { Text("Save AI") }
                    OutlinedButton(onClick = {
                        NovaAiKeyStore.clear(context)
                        aiKey = ""
                        aiConfig = aiConfig.copy(enabled = false)
                        NovaAiConfigStore.save(context, aiConfig)
                        status = "AI disabled"
                    }, modifier = Modifier.weight(1f)) { Text("Disable AI") }
                }
                Text(
                    "API key device ke encrypted storage mein save hoti hai. Public GitHub repo mein key nahi jayegi.",
                    style = MaterialTheme.typography.bodySmall
                )
                Text("Memory + Task Agent", style = MaterialTheme.typography.titleLarge)
                val memories = db.listMemories()
                Text(if (memories.isEmpty()) "Memory: empty" else "Memory: ${memories.size} saved item(s)", style = MaterialTheme.typography.bodySmall)
                if (memories.take(8).isNotEmpty()) {
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            memories.take(8).forEach { (id, value) ->
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text(value, Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                                    TextButton(onClick = { db.forgetMemory(id); status = "Memory deleted" }) { Text("Delete") }
                                }
                            }
                        }
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { db.clearMemories(); status = "All memory cleared" }, modifier = Modifier.weight(1f)) { Text("Clear Memory") }
                    OutlinedButton(onClick = {
                        val tasks = db.recentTasks()
                        answer = if (tasks.isEmpty()) "Nova: No task history yet." else "Nova Task History:\n" + tasks.joinToString("\n")
                    }, modifier = Modifier.weight(1f)) { Text("Task History") }
                }
                OutlinedTextField(
                    value = command,
                    onValueChange = { command = it },
                    label = { Text("Nova command") },
                    supportingText = { Text("Enter a command or use Voice") },
                    modifier = Modifier.fillMaxWidth().height(120.dp)
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(enabled = !busy && secureStore.token != null, onClick = { rotatePcToken() }, modifier = Modifier.weight(1f)) { Text("Rotate Token") }
                    Button(enabled = !busy, onClick = {
                        status = "Listening..."
                        startVoice { spoken ->
                            command = spoken
                            status = "Heard: $spoken"
                            handleLocal(spoken)
                        }
                    }, modifier = Modifier.weight(1f)) { Text("Voice") }
                    Button(enabled = !busy && command.isNotBlank(), onClick = {
                        handleLocal(command)
                    }, modifier = Modifier.weight(1f)) { Text("Send") }
                }
                var wakeEnabled by remember { mutableStateOf(continuousListeningState) }
                Text("🎤 Nova Voice", style = MaterialTheme.typography.titleLarge)
                Text("Wake word: Nova • Urdu + Roman Urdu + English • Voice → Text → Nova Voice", style = MaterialTheme.typography.bodySmall)
                OutlinedButton(onClick = {
                    wakeEnabled = !wakeEnabled
                    setContinuousListening(wakeEnabled)
                    context.getSharedPreferences("nova_voice_settings", android.content.Context.MODE_PRIVATE)
                        .edit().putBoolean("continuous_listening", wakeEnabled).apply()
                    val intent = Intent(context, NovaWakeService::class.java)
                    if (wakeEnabled) {
                        if (android.os.Build.VERSION.SDK_INT >= 26) androidx.core.content.ContextCompat.startForegroundService(context, intent) else context.startService(intent)
                        status = "Continuous listening ON — say Nova"
                    } else {
                        context.stopService(intent)
                        status = "Continuous listening OFF"
                    }
                }, modifier = Modifier.fillMaxWidth()) {
                    Text(if (wakeEnabled) "Wake: ON — say Nova" else "Continuous Listening: OFF")
                }
                Text("Mic conflict protection: manual Voice pauses wake listening; Nova voice pauses the microphone while speaking.", style = MaterialTheme.typography.bodySmall)
                Text("Remote Mobile Control", style = MaterialTheme.typography.titleLarge)
                Text(
                    "Phone door ho to secure relay ke zariye queued commands receive ho sakti hain. Relay HTTPS hona chahiye. Secret/token encrypted device storage mein rehte hain.",
                    style = MaterialTheme.typography.bodySmall
                )
                OutlinedTextField(
                    value = remoteEndpoint,
                    onValueChange = { remoteEndpoint = it },
                    label = { Text("Nova Relay HTTPS endpoint") },
                    supportingText = { Text("Example: https://your-relay.example.com") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                OutlinedTextField(
                    value = remotePollSeconds,
                    onValueChange = { remotePollSeconds = it.filter(Char::isDigit).take(3) },
                    label = { Text("Poll interval (seconds)") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = {
                        val endpoint = remoteEndpoint.trim().trimEnd('/')
                        val enabled = endpoint.startsWith("https://") && secureStore.token != null && secureStore.secret != null
                        remoteConfig = NovaRemoteConfig(endpoint, enabled, remotePollSeconds.toIntOrNull()?.coerceIn(10, 120) ?: 15)
                        NovaRemoteConfigStore.save(context, remoteConfig)
                        val service = Intent(context, NovaRemoteService::class.java)
                        if (enabled) {
                            if (android.os.Build.VERSION.SDK_INT >= 26) androidx.core.content.ContextCompat.startForegroundService(context, service) else context.startService(service)
                            status = "Remote control ON"
                            speak("Remote control on kar diya.")
                        } else {
                            context.stopService(service)
                            status = "Remote setup incomplete"
                            speak("HTTPS relay aur secure pairing required hai.")
                        }
                    }, modifier = Modifier.weight(1f)) { Text("Enable Remote") }
                    OutlinedButton(onClick = {
                        remoteConfig = remoteConfig.copy(enabled = false)
                        NovaRemoteConfigStore.save(context, remoteConfig)
                        context.stopService(Intent(context, NovaRemoteService::class.java))
                        status = "Remote control OFF"
                    }, modifier = Modifier.weight(1f)) { Text("Disable") }
                }
                Text(
                    if (remoteConfig.enabled) "Remote status: ENABLED" else "Remote status: OFF",
                    style = MaterialTheme.typography.bodySmall
                )

                OutlinedButton(onClick = {
                    context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                }, modifier = Modifier.fillMaxWidth()) { Text("Enable Android Accessibility") }
                OutlinedButton(onClick = {
                    context.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                }, modifier = Modifier.fillMaxWidth()) { Text("Enable Notification Access") }

                if (answer.isNotBlank()) Card(Modifier.fillMaxWidth()) {
                    Text(answer, Modifier.padding(16.dp))
                }
                HorizontalDivider()
                val health = NovaHealth.check(context)
                Text("Nova Health", style = MaterialTheme.typography.titleLarge)
                Text(if (health.ok) "Overall: HEALTHY" else "Overall: CHECK REQUIRED", style = MaterialTheme.typography.bodyMedium)
                val healthLabels = listOf(
                    "microphone" to "Microphone", "speech" to "Speech", "speaker" to "Speaker",
                    "ai_connection" to "AI Connection", "accessibility" to "Accessibility",
                    "notifications" to "Notifications", "notification_access" to "Notification Access",
                    "remote_control" to "Remote Connection", "storage" to "Storage",
                    "security" to "Security"
                )
                healthLabels.forEach { (key, label) ->
                    val ok = health.checks[key] == true
                    Text("$label   ${if (ok) "✅ OK" else "⚠️ CHECK"}", style = MaterialTheme.typography.bodySmall)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = {
                        val latest = NovaHealth.check(context)
                        status = if (latest.ok) "Nova Health: all checks OK" else "Nova Health: one or more checks need attention"
                        speak(status)
                    }, modifier = Modifier.weight(1f)) { Text("Run Health Check") }
                    OutlinedButton(onClick = {
                        secureStore.token = null
                        secureStore.secret = null
                        secureStore.tokenExpiresAt = 0L
                        remoteConfig = remoteConfig.copy(enabled = false)
                        NovaRemoteConfigStore.save(context, remoteConfig)
                        context.stopService(Intent(context, NovaRemoteService::class.java))
                        status = "Local remote credentials revoked"
                        speak("Remote device credentials revoke kar diye.")
                    }, modifier = Modifier.weight(1f)) { Text("Revoke Remote") }
                }
                Text("Security: remote credentials are encrypted locally. Sensitive actions require user confirmation.", style = MaterialTheme.typography.bodySmall)
                Text("Final WhatsApp Send user ke control mein rahega.", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}
