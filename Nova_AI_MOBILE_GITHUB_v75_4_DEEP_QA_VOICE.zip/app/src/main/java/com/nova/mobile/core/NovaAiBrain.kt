package com.nova.mobile.core

import android.content.Context
import com.nova.mobile.data.NovaDatabase
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.File
import java.util.Base64
import java.net.HttpURLConnection
import java.net.URL
import java.nio.charset.StandardCharsets
import java.util.Locale

/**
 * Nova's optional cloud AI layer. It is deliberately separate from the local command router:
 * local commands keep working offline, while AI adds natural conversation and interpretation.
 */
class NovaAiBrain(private val context: Context) {
    private val appContext = context.applicationContext

    fun isConfigured(): Boolean = NovaAiConfigStore.load(appContext).enabled && !NovaAiKeyStore.get(appContext).isNullOrBlank()

    fun ask(userText: String, callback: (Result<String>) -> Unit) {
        Thread { callback(runCatching { requestGemini(userText, forceJson = false) }) }.start()
    }

    fun askWithImage(imageFile: File, userText: String, callback: (Result<String>) -> Unit) {
        Thread { callback(runCatching { requestGeminiWithImage(imageFile, userText) }) }.start()
    }

    private fun requestGeminiWithImage(imageFile: File, userText: String): String {
        val config = NovaAiConfigStore.load(appContext)
        val key = NovaAiKeyStore.get(appContext).orEmpty()
        if (config.provider.uppercase(Locale.ROOT) != "GEMINI" || !config.enabled || key.isBlank()) {
            throw IllegalStateException("AI setup incomplete. Gemini API key enter karein.")
        }
        if (!imageFile.exists() || imageFile.length() <= 0L) throw IllegalStateException("Screenshot file missing hai.")
        val image64 = Base64.getEncoder().encodeToString(imageFile.readBytes())
        val parts = JSONArray()
            .put(JSONObject().put("text", userText))
            .put(JSONObject().put("inlineData", JSONObject().put("mimeType", "image/png").put("data", image64)))
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", "You are Nova's screen vision assistant. Understand English, Urdu, and Roman Urdu. Describe only what is visibly supported by the screenshot. Do not claim hidden state. Never expose passwords or secrets; if sensitive information appears, summarize it as [hidden]. Keep the answer practical and concise."))))
            .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", parts)))
            .put("generationConfig", JSONObject().put("temperature", 0.2).put("maxOutputTokens", 900))
        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/${config.model}:generateContent")
        val connection = url.openConnection() as HttpURLConnection
        try {
            connection.requestMethod = "POST"
            connection.doOutput = true
            connection.connectTimeout = 15000
            connection.readTimeout = 30000
            connection.setRequestProperty("Content-Type", "application/json; charset=UTF-8")
            connection.setRequestProperty("x-goog-api-key", key)
            connection.outputStream.use { it.write(body.toString().toByteArray(StandardCharsets.UTF_8)) }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val response = BufferedReader(InputStreamReader(stream, StandardCharsets.UTF_8)).use { it.readText() }
            if (code !in 200..299) throw IllegalStateException("Gemini HTTP $code: ${extractError(response)}")
            val json = JSONObject(response)
            val partsOut = json.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
                ?: throw IllegalStateException("AI response text missing hai.")
            val answer = buildString { for (i in 0 until partsOut.length()) append(partsOut.optJSONObject(i)?.optString("text").orEmpty()) }.trim()
            if (answer.isBlank()) throw IllegalStateException("AI response blank hai.")
            return answer
        } finally { connection.disconnect() }
    }

    fun interpret(userText: String, callback: (Result<AiIntent>) -> Unit) {
        Thread {
            callback(runCatching {
                val raw = requestGemini(userText, forceJson = true)
                parseIntent(raw)
            })
        }.start()
    }

    private fun requestGemini(userText: String, forceJson: Boolean): String {
        val config = NovaAiConfigStore.load(appContext)
        if (config.provider.uppercase(Locale.ROOT) != "GEMINI") {
            throw IllegalStateException("Unsupported AI provider: ${config.provider}")
        }
        val key = NovaAiKeyStore.get(appContext).orEmpty()
        if (!config.enabled || key.isBlank()) {
            throw IllegalStateException("AI setup incomplete. Gemini API key enter karein.")
        }

        val db = NovaDatabase(appContext)
        val history = db.recentConversations(8)
        val contents = JSONArray()
        history.forEach { item ->
            val role = if (item.first == "USER") "user" else "model"
            contents.put(JSONObject().put("role", role).put("parts", JSONArray().put(JSONObject().put("text", item.second))))
        }
        contents.put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", userText))))

        val system = if (forceJson) {
            """
            You are Nova's command planner. Understand English, Urdu, and Roman Urdu.
            Return ONLY one compact JSON object and no markdown.
            Allowed types: CHAT, ANDROID, PC, OPEN_APP, PLAN.
            For CHAT use: {"type":"CHAT","text":"reply"}.
            For ANDROID use: {"type":"ANDROID","command":"a normalized command"}.
            For PC use: {"type":"PC","command":"a normalized PC command"}.
            For OPEN_APP use: {"type":"OPEN_APP","app":"WhatsApp|YouTube|Chrome|Settings|Camera|Calculator"}.
            For PLAN use: {"type":"PLAN","text":"short summary","steps":[{"type":"ANDROID|PC|OPEN_APP","command":"...","app":"..."}]}.
            Use PLAN only when the user clearly requests two or more related actions. Keep the plan to at most 5 steps. Preserve the user's requested order. Never put CHAT inside a PLAN.
            Only choose ANDROID when the user clearly asks the phone to do something.
            Only choose PC when the user clearly mentions PC, laptop, computer, or desktop.
            Never invent that an action has already happened.
            """.trimIndent()
        } else {
            """
            You are Nova, a practical Android and PC assistant.
            Reply naturally and briefly unless the user asks for detail.
            Understand English, Urdu, and Roman Urdu. Reply in the user's language/style when possible.
            Never claim you performed an action unless the app actually performed it.
            If an Android or PC action needs a permission, pairing, or confirmation, clearly say so.
            Do not ask for passwords, API keys, or private secrets in normal conversation.
            """.trimIndent()
        }

        val generation = JSONObject().put("temperature", if (forceJson) 0.1 else 0.4).put("maxOutputTokens", 700)
        if (forceJson) generation.put("responseMimeType", "application/json")
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
            .put("contents", contents)
            .put("generationConfig", generation)

        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/${config.model}:generateContent")
        val connection = url.openConnection() as HttpURLConnection
        try {
            connection.requestMethod = "POST"
            connection.doOutput = true
            connection.connectTimeout = 15000
            connection.readTimeout = 30000
            connection.setRequestProperty("Content-Type", "application/json; charset=UTF-8")
            connection.setRequestProperty("x-goog-api-key", key)
            connection.outputStream.use { it.write(body.toString().toByteArray(StandardCharsets.UTF_8)) }

            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val response = BufferedReader(InputStreamReader(stream, StandardCharsets.UTF_8)).use { it.readText() }
            if (code !in 200..299) throw IllegalStateException("Gemini HTTP $code: ${extractError(response)}")
            val json = JSONObject(response)
            val candidates = json.optJSONArray("candidates") ?: throw IllegalStateException("AI ne koi response nahi diya.")
            val first = candidates.optJSONObject(0) ?: throw IllegalStateException("AI response empty hai.")
            val parts = first.optJSONObject("content")?.optJSONArray("parts") ?: throw IllegalStateException("AI response text missing hai.")
            val text = buildString {
                for (i in 0 until parts.length()) append(parts.optJSONObject(i)?.optString("text").orEmpty())
            }.trim()
            if (text.isBlank()) throw IllegalStateException("AI response blank hai.")
            return text
        } finally {
            connection.disconnect()
        }
    }

    private fun parseIntent(raw: String): AiIntent {
        val cleaned = raw.trim().removePrefix("```").removeSuffix("```").trim()
        val json = JSONObject(cleaned)
        val steps = mutableListOf<AiStep>()
        json.optJSONArray("steps")?.let { arr ->
            for (i in 0 until minOf(arr.length(), 5)) {
                val item = arr.optJSONObject(i) ?: continue
                steps += AiStep(
                    type = item.optString("type", "ANDROID").uppercase(Locale.ROOT),
                    command = item.optString("command"),
                    app = item.optString("app")
                )
            }
        }
        return AiIntent(
            type = json.optString("type", "CHAT").uppercase(Locale.ROOT),
            text = json.optString("text"),
            command = json.optString("command"),
            app = json.optString("app"),
            steps = steps
        )
    }

    private fun extractError(response: String): String = runCatching {
        JSONObject(response).optJSONObject("error")?.optString("message").orEmpty().ifBlank { response.take(300) }
    }.getOrDefault(response.take(300))
}

data class AiIntent(
    val type: String,
    val text: String = "",
    val command: String = "",
    val app: String = "",
    val steps: List<AiStep> = emptyList()
)

data class AiStep(
    val type: String,
    val command: String = "",
    val app: String = ""
)
