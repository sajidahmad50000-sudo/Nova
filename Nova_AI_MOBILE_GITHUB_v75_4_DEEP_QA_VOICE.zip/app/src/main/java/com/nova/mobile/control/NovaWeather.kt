package com.nova.mobile.control

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URL
import java.util.Locale
import java.util.concurrent.Executors

/** Live weather using Open-Meteo: no API key required. */
class NovaWeather(private val context: Context) {
    private val executor = Executors.newSingleThreadExecutor()

    fun current(city: String): AndroidControlResult {
        val clean = city.trim().ifBlank { return AndroidControlResult(false, false, "Weather ke liye city ka naam batayein, misal: Karachi ka weather.") }
        return try {
            val geoUrl = URL("https://geocoding-api.open-meteo.com/v1/search?name=${URLEncoder.encode(clean, "UTF-8")}&count=1&language=en&format=json")
            val geo = httpGet(geoUrl)
            val results = geo.optJSONArray("results")
            if (results == null || results.length() == 0) return AndroidControlResult(false, false, "$clean ka location nahi mila.")
            val place = results.getJSONObject(0)
            val lat = place.getDouble("latitude")
            val lon = place.getDouble("longitude")
            val name = place.optString("name", clean)
            val country = place.optString("country", "")
            val weatherUrl = URL("https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current=temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,wind_speed_10m&timezone=auto")
            val weather = httpGet(weatherUrl).getJSONObject("current")
            val temp = weather.optDouble("temperature_2m")
            val feels = weather.optDouble("apparent_temperature")
            val humidity = weather.optInt("relative_humidity_2m")
            val wind = weather.optDouble("wind_speed_10m")
            val code = weather.optInt("weather_code")
            val desc = description(code)
            val spoken = String.format(Locale.US, "%s%s: %.0f degree Celsius, feels like %.0f, %s. Humidity %d percent aur wind %.0f kilometer per hour.", name, if (country.isNotBlank()) ", $country" else "", temp, feels, desc, humidity, wind)
            AndroidControlResult(true, true, spoken, mapOf("city" to name, "country" to country, "temperatureC" to temp, "feelsLikeC" to feels, "humidity" to humidity, "windKph" to wind, "weatherCode" to code, "description" to desc))
        } catch (e: Exception) {
            AndroidControlResult(false, false, "Live weather abhi nahi mil saka. Internet connection check karein.")
        }
    }

    private fun httpGet(url: URL): JSONObject {
        val c = url.openConnection() as HttpURLConnection
        c.requestMethod = "GET"
        c.connectTimeout = 8000
        c.readTimeout = 10000
        c.setRequestProperty("User-Agent", "Nova-Android-Assistant/75.2")
        val code = c.responseCode
        if (code !in 200..299) throw IllegalStateException("HTTP $code")
        return c.inputStream.bufferedReader().use { JSONObject(it.readText()) }
    }

    private fun description(code: Int): String = when (code) {
        0 -> "clear sky"
        1, 2 -> "partly cloudy"
        3 -> "overcast"
        45, 48 -> "foggy"
        51, 53, 55, 56, 57 -> "drizzle"
        61, 63, 65, 66, 67 -> "rain"
        71, 73, 75, 77 -> "snow"
        80, 81, 82 -> "rain showers"
        85, 86 -> "snow showers"
        95, 96, 99 -> "thunderstorm"
        else -> "mixed conditions"
    }
}
