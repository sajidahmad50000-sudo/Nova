package com.nova.mobile.core

import android.content.Context
import com.nova.mobile.security.NovaSecureStore

data class NovaAiConfig(
    val provider: String = "GEMINI",
    val model: String = "gemini-3.8-flash",
    val enabled: Boolean = false
)

object NovaAiConfigStore {
    private const val PREFS = "nova_ai_config"

    fun load(context: Context): NovaAiConfig {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return NovaAiConfig(
            provider = p.getString("provider", "GEMINI") ?: "GEMINI",
            model = p.getString("model", "gemini-3.8-flash") ?: "gemini-3.8-flash",
            enabled = p.getBoolean("enabled", false)
        )
    }

    fun save(context: Context, config: NovaAiConfig) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString("provider", config.provider)
            .putString("model", config.model)
            .putBoolean("enabled", config.enabled)
            .apply()
    }
}

object NovaAiKeyStore {
    fun get(context: Context): String? = NovaSecureStore(context).aiApiKey
    fun set(context: Context, value: String) { NovaSecureStore(context).aiApiKey = value.trim().ifBlank { null } }
    fun clear(context: Context) { NovaSecureStore(context).aiApiKey = null }
}
