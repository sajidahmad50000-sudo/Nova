package com.nova.mobile.health

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.provider.Settings
import android.speech.RecognitionService
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import com.nova.mobile.core.NovaAiConfigStore
import com.nova.mobile.core.NovaRemoteConfigStore
import com.nova.mobile.data.NovaDatabase
import com.nova.mobile.security.NovaSecureStore
import java.io.File

/** Lightweight on-device diagnostics. No secrets are returned by this class. */
data class HealthResult(
    val ok: Boolean,
    val checks: Map<String, Boolean>
)

object NovaHealth {
    private fun accessibilityEnabled(context: Context): Boolean = runCatching {
        val enabled = Settings.Secure.getString(context.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return@runCatching false
        enabled.split(':').any { it.contains("com.nova.mobile/.control.NovaAccessibilityService", ignoreCase = true) }
    }.getOrDefault(false)

    private fun notificationsEnabled(context: Context): Boolean =
        if (android.os.Build.VERSION.SDK_INT < 33) true
        else context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    private fun notificationListenerEnabled(context: Context): Boolean = runCatching {
        val enabled = Settings.Secure.getString(context.contentResolver, "enabled_notification_listeners") ?: return@runCatching false
        enabled.split(':').any { it.contains("com.nova.mobile/.control.NovaNotificationListenerService", ignoreCase = true) }
    }.getOrDefault(false)

    fun check(context: Context): HealthResult {
        val dbOk = runCatching {
            NovaDatabase(context).readableDatabase.rawQuery("SELECT 1", null).use { it.moveToFirst() }
        }.getOrDefault(false)
        val storageOk = runCatching {
            File(context.filesDir, "logs").mkdirs()
            File(context.filesDir, "logs").canWrite()
        }.getOrDefault(false)
        val micOk = context.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        val speechOk = SpeechRecognizer.isRecognitionAvailable(context)
        val speakerOk = runCatching { TextToSpeech(context) { } ; true }.getOrDefault(false)
        val ai = NovaAiConfigStore.load(context)
        val aiOk = ai.enabled
        val secure = NovaSecureStore(context)
        val securityOk = !secure.tokenExpired() && (!secure.token.isNullOrBlank() || !secure.secret.isNullOrBlank())
        val remote = NovaRemoteConfigStore.load(context)
        val remoteOk = !remote.enabled || (remote.endpoint.startsWith("https://") && securityOk)
        val checks = linkedMapOf(
            "database" to dbOk,
            "storage" to storageOk,
            "microphone" to micOk,
            "speech" to speechOk,
            "speaker" to speakerOk,
            "ai_connection" to aiOk,
            "accessibility" to accessibilityEnabled(context),
            "notifications" to notificationsEnabled(context),
            "notification_access" to notificationListenerEnabled(context),
            "remote_control" to remoteOk,
            "security" to securityOk
        )
        return HealthResult(checks.values.all { it }, checks)
    }
}
