package com.nova.mobile.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class NovaDatabase(context: Context) :
    SQLiteOpenHelper(context, "nova.db", null, 2) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""
            CREATE TABLE conversation_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                created_at INTEGER NOT NULL,
                language TEXT NOT NULL,
                user_text TEXT NOT NULL,
                nova_text TEXT NOT NULL
            )
        """.trimIndent())
        db.execSQL("""
            CREATE TABLE memories (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                kind TEXT NOT NULL,
                value TEXT NOT NULL,
                created_at INTEGER NOT NULL,
                updated_at INTEGER NOT NULL
            )
        """.trimIndent())
        db.execSQL("""
            CREATE TABLE task_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                goal TEXT NOT NULL,
                status TEXT NOT NULL,
                details TEXT NOT NULL,
                created_at INTEGER NOT NULL,
                updated_at INTEGER NOT NULL
            )
        """.trimIndent())
        db.execSQL("""
            CREATE TABLE contacts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL UNIQUE,
                phone TEXT NOT NULL,
                created_at INTEGER NOT NULL,
                updated_at INTEGER NOT NULL
            )
        """.trimIndent())
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            db.execSQL("""CREATE TABLE IF NOT EXISTS memories (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                kind TEXT NOT NULL,
                value TEXT NOT NULL,
                created_at INTEGER NOT NULL,
                updated_at INTEGER NOT NULL
            )""")
            db.execSQL("""CREATE TABLE IF NOT EXISTS task_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                goal TEXT NOT NULL,
                status TEXT NOT NULL,
                details TEXT NOT NULL,
                created_at INTEGER NOT NULL,
                updated_at INTEGER NOT NULL
            )""")
        }
    }

    fun saveConversation(language: String, userText: String, novaText: String) {
        writableDatabase.insert("conversation_log", null, ContentValues().apply {
            put("created_at", System.currentTimeMillis())
            put("language", language)
            put("user_text", userText)
            put("nova_text", novaText)
        })
    }

    fun recentConversations(limit: Int = 8): List<Pair<String, String>> {
        val out = mutableListOf<Pair<String, String>>()
        readableDatabase.query(
            "conversation_log", arrayOf("user_text", "nova_text"), null, null,
            null, null, "created_at DESC", limit.toString()
        ).use { cursor ->
            while (cursor.moveToNext()) {
                out += "USER" to cursor.getString(0)
                out += "MODEL" to cursor.getString(1)
            }
        }
        return out.asReversed()
    }

    fun remember(kind: String = "memory", value: String) {
        val now = System.currentTimeMillis()
        writableDatabase.insert("memories", null, ContentValues().apply {
            put("kind", kind.trim().ifBlank { "memory" })
            put("value", value.trim())
            put("created_at", now)
            put("updated_at", now)
        })
    }

    fun listMemories(limit: Int = 50): List<Pair<Long, String>> {
        val out = mutableListOf<Pair<Long, String>>()
        readableDatabase.query("memories", arrayOf("id", "kind", "value"), null, null,
            null, null, "updated_at DESC", limit.toString()).use { c ->
            while (c.moveToNext()) out += c.getLong(0) to "${c.getString(1)}: ${c.getString(2)}"
        }
        return out
    }

    fun forgetMemory(id: Long): Boolean = writableDatabase.delete("memories", "id = ?", arrayOf(id.toString())) > 0

    fun clearMemories(): Int = writableDatabase.delete("memories", null, null)

    fun saveTask(goal: String, status: String, details: String) {
        val now = System.currentTimeMillis()
        writableDatabase.insert("task_history", null, ContentValues().apply {
            put("goal", goal); put("status", status); put("details", details)
            put("created_at", now); put("updated_at", now)
        })
    }

    fun recentTasks(limit: Int = 10): List<String> {
        val out = mutableListOf<String>()
        readableDatabase.query("task_history", arrayOf("goal", "status", "details"), null, null,
            null, null, "updated_at DESC", limit.toString()).use { c ->
            while (c.moveToNext()) out += "${c.getString(1)} — ${c.getString(0)}${if (c.getString(2).isNotBlank()) " (${c.getString(2)})" else ""}"
        }
        return out
    }

    fun saveContact(name: String, phone: String) {
        val now = System.currentTimeMillis()
        writableDatabase.insertWithOnConflict("contacts", null, ContentValues().apply {
            put("name", name)
            put("phone", phone)
            put("created_at", now)
            put("updated_at", now)
        }, SQLiteDatabase.CONFLICT_REPLACE)
    }

    fun getContact(name: String): String? =
        readableDatabase.query(
            "contacts", arrayOf("phone"), "name = ?", arrayOf(name),
            null, null, null
        ).use { cursor -> if (cursor.moveToFirst()) cursor.getString(0) else null }
}
