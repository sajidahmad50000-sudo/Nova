package com.nova.mobile.control

import android.content.Context
import java.util.Locale

/** Natural-language Android control adapter. High-impact actions are confirmation-gated by the caller. */


private object NovaNaturalLanguageV71 {
    fun normalize(raw: String): String {
        var t = raw.trim().replace(Regex("^\\s*(?:nova|hey nova|ok nova)[,:]?\\s*", RegexOption.IGNORE_CASE), "")
        t = t.replace(Regex("\\s+"), " ").trim().trimEnd('.')
        Regex("(?i)^(?:open|launch|start|kholo|chalao|chala|khol do|open kar do)\\s+(.+)$").matchEntire(t)?.let { return "open ${it.groupValues[1]}" }
        Regex("(?i)^(?:file|document)\\s+(?:dhoondo|find|search)\\s+(.+)$").matchEntire(t)?.let { return "find file ${it.groupValues[1]}" }
        Regex("(?i)^(?:folder|directory)\\s+(?:banao|create|make)\\s+(.+)$").matchEntire(t)?.let { return "create folder ${it.groupValues[1]}" }
        Regex("(?i)^(.+?)\s+ko\s+(?:call|phone|dial)\s*(?:karo|kar do|milao|mila do)?$").matchEntire(t)?.let { return "call contact ${it.groupValues[1]}" }
        Regex("(?i)^(.+?)\\s+ko\\s+(?:bolo|keh do|message karo|msg karo|text karo)\\s*[:,-]?\\s*(.+)$").matchEntire(t)?.let { return "whatsapp contact ${it.groupValues[1]} say ${it.groupValues[2]}" }
        if (t.contains("notifications", true) && t.matches(Regex("(?i).*(dikhao|show|list).*"))) return "notifications"
        return t
    }
}

class NovaAndroidCommandRouter(context: Context) {
    private val control = NovaAndroidControl(context)
    private val files = NovaAndroidFileManager(context)
    private val smartFiles = NovaAndroidSmartFileIntelligence(context)
    private val calendar = NovaAndroidCalendar(context)
    private val weather = NovaWeather(context)
    private val reminders = NovaAndroidReminders(context)
    private val contacts = NovaAndroidContacts(context)
    private val communication = NovaAndroidCommunication(context)
    private val notifications = NovaAndroidNotifications(context)
    private val crossApp = NovaUniversalCrossAppEngine(context, this)
    private val visualGoal: NovaAndroidVisualGoalAgent? get() = NovaAccessibilityService.instance?.let { NovaAndroidVisualGoalAgent(it) }
    private lateinit var taskAgent: NovaAndroidTaskAgent

    init {
        taskAgent = NovaAndroidTaskAgent(context, this)
    }

    private fun uiAgent(): NovaAndroidUiAgent? = NovaAccessibilityService.instance?.let { NovaAndroidUiAgent(it) }

    fun execute(command: String, confirmed: Boolean = false): AndroidControlResult {
        val raw = command.trim()
        val t = raw.lowercase(Locale.ROOT)
        if (t.isBlank()) return AndroidControlResult(false, false, "Android command empty hai.")

        visualGoal?.let { vg ->
            if (vg.isVisualGoal(raw)) {
                val r = vg.execute(raw, confirmed)
                return AndroidControlResult(r.success, r.verified, r.message, r.data, r.requiresUserAction)
            }
        }

        if (crossApp.isCrossAppGoal(raw)) {
            val task = crossApp.execute(raw, confirmed)
            return AndroidControlResult(task.success, task.verified, task.message, mapOf("completed" to task.completed, "total" to task.total, "failedStep" to task.failedStep), task.requiresUserAction)
        }

        if (taskAgent.isTaskGoal(raw)) {
            val task = taskAgent.execute(raw, confirmed)
            return AndroidControlResult(task.success, task.verified, task.message, mapOf("completed" to task.completed, "total" to task.total, "failedStep" to task.failedStep), task.requiresUserAction)
        }

        fun protected(result: AndroidControlResult): AndroidControlResult = if (confirmed) result
        else AndroidControlResult(false, false, "Yeh Android action execute karne se pehle confirmation chahiye: $raw", requiresUserAction = true)

        return when {
            t.startsWith("call contact ") -> {
                val q=raw.substringAfter("call contact ").trim(); val found=contacts.search(q)
                if(found.data?.get("contacts") is List<*> && (found.data?.get("contacts") as List<*>).size==1) {
                    val row=((found.data?.get("contacts") as List<*>)[0] as? Map<*,*>)
                    communication.call(row?.get("phone")?.toString().orEmpty(),confirmed)
                } else AndroidControlResult(false,false,"Contact not uniquely found: $q")
            }
            t.startsWith("sms contact ") || t.startsWith("text contact ") -> {
                val m=Regex("(?i)^(?:sms|text) contact (.+?) (?:say|message|likho|keho) (.+)$").find(raw)
                if(m==null) AndroidControlResult(false,false,"Example: sms contact Ali say Hello") else {
                    val found=contacts.search(m.groupValues[1]); val rows=found.data?.get("contacts") as? List<*>
                    if(rows?.size==1) communication.sms((rows[0] as? Map<*,*>)?.get("phone")?.toString().orEmpty(),m.groupValues[2],confirmed) else AndroidControlResult(false,false,"Contact not uniquely found: ${m.groupValues[1]}")
                }
            }
            t.startsWith("email contact ") -> {
                val m=Regex("(?i)^email contact (.+?) subject (.+?) body (.+)$").find(raw)
                if(m==null) AndroidControlResult(false,false,"Example: email contact Ali subject Meeting body Confirmed") else {
                    val found=contacts.search(m.groupValues[1]); val rows=found.data?.get("contacts") as? List<*>
                    if(rows?.size==1) { val row=rows[0] as? Map<*,*>; communication.email(row?.get("email")?.toString().orEmpty(),m.groupValues[2],m.groupValues[3],confirmed) } else AndroidControlResult(false,false,"Contact not uniquely found: ${m.groupValues[1]}")
                }
            }
            t.startsWith("whatsapp contact ") -> {
                val m=Regex("(?i)^whatsapp contact (.+?) (?:say|message|likho|keho) (.+)$").find(raw)
                if(m==null) AndroidControlResult(false,false,"Example: whatsapp contact Ali say Hello") else {
                    val found=contacts.search(m.groupValues[1]); val rows=found.data?.get("contacts") as? List<*>
                    if(rows?.size==1) communication.whatsapp((rows[0] as? Map<*,*>)?.get("phone")?.toString().orEmpty(),m.groupValues[2],confirmed) else AndroidControlResult(false,false,"Contact not uniquely found: ${m.groupValues[1]}")
                }
            }
            t == "notifications" || t == "notification inbox" || t == "notifications dikhao" -> notifications.list()
            t == "unread notifications" || t == "unread alerts" -> notifications.list(unread = true)
            t == "important notifications" || t == "important alerts" -> notifications.list(important = true)
            t == "notification status" || t == "notifications status" -> notifications.status()
            t == "notification access settings" || t == "enable notification access" -> notifications.openSettings()
            t.startsWith("search notifications ") || t.startsWith("find notifications ") -> notifications.list(raw.substringAfterLast(' ').trim())
            t == "contacts" || t == "contact list" || t == "contacts dikhao" || t == "people" -> contacts.search("")
            t.startsWith("search contact ") || t.startsWith("find contact ") || t.startsWith("contact search ") -> contacts.search(raw.substringAfterLast(' ').trim())
            t.startsWith("open contact ") -> contacts.openContact(raw.substringAfter("open contact ").trim())
            t == "weather" || t == "weather dikhao" || t == "mausam" || t == "mausam dikhao" -> weather.current("Karachi")
            t.startsWith("weather ") -> weather.current(raw.substringAfter("weather ").trim())
            t.startsWith("mausam ") -> weather.current(raw.substringAfter("mausam ").trim().replace(Regex("(?i)\\bka\\b|\\bki\\b|\\bbatao\\b|\\bdikhao\\b"), "").trim())
            t == "calendar" || t == "show calendar" || t == "calendar dikhao" || t == "events dikhao" -> calendar.list()
            t == "reminders" || t == "reminder" || t == "reminders dikhao" || t == "upcoming reminders" -> reminders.list()
            t.startsWith("set alarm") || t.startsWith("alarm") || t.startsWith("wake me") || t.startsWith("alarm laga") || t.startsWith("alarm lagao") -> {
                val explicit=Regex("(?i)^(?:set alarm|alarm laga(?: do|o)?|alarm)\\s+(?:for\\s+)?(.+?)\\s+(?:at|on|ko|par)\\s+(.+)$").find(raw)
                val wake=Regex("(?i)^wake me(?: up)?\\s+(?:at|on|ko|par)\\s+(.+)$").find(raw)
                when {
                    explicit!=null -> reminders.alarm(explicit.groupValues[1],explicit.groupValues[2],confirmed)
                    wake!=null -> reminders.alarm("Wake up",wake.groupValues[1],confirmed)
                    else -> AndroidControlResult(false,false,"Example: Nova set alarm for meeting at kal 8 baje")
                }
            }
            t == "due reminders" || t == "pending reminders" -> AndroidControlResult(true,true,"Due reminders ready.",mapOf("reminders" to reminders.list().data))
            t.startsWith("search reminder ") || t.startsWith("find reminder ") -> reminders.search(raw.substringAfter(' ').substringAfter(' ').trim())
            t.startsWith("remind me to ") || t.startsWith("remind mujhe ") || t.startsWith("set reminder ") -> {
                val m=Regex("(?i)^(?:remind me to|remind mujhe|set reminder) (.+?) (?:at|on|ko|par) (.+)$").find(raw)
                if(m==null) AndroidControlResult(false,false,"Example: remind me to call Ali at kal 8 baje") else reminders.create(m.groupValues[1],m.groupValues[2],confirmed)
            }
            t.startsWith("snooze reminder ") -> {
                val m=Regex("(?i)^snooze reminder ([-a-f0-9]{8,}) (?:for|by) (\\d+) ?(?:minutes?|mins?)$").find(raw)
                if(m==null) AndroidControlResult(false,false,"Snooze format: snooze reminder ID for 10 minutes") else reminders.snooze(m.groupValues[1],m.groupValues[2].toInt(),confirmed)
            }
            t.startsWith("cancel reminder ") || t.startsWith("delete reminder ") -> reminders.cancel(raw.substringAfter(' ').substringAfter(' ').trim(),confirmed)

            t.startsWith("search event ") || t.startsWith("find event ") || t.startsWith("event search ") -> calendar.search(raw.substringAfter(' ').substringAfter(' ').trim())
            t.startsWith("create event ") || t.startsWith("create meeting ") || t.startsWith("meeting banao ") -> {
                val m=Regex("(?i)^(?:create event|create meeting|meeting banao) (.+?) (?:at|on|ko|par) (.+)$").find(raw)
                if(m==null) AndroidControlResult(false,false,"Example: create event Meeting at kal 10 baje") else calendar.create(m.groupValues[1],m.groupValues[2],confirmed)
            }
            t.startsWith("delete event ") -> calendar.delete(raw.substringAfter("delete event ").trim(),confirmed)
            t == "file access" || t == "folder access" || t == "grant folder access" || t == "storage access" -> files.requestFolderAccess()
            t == "file analyze" || t == "file analysis" || t == "analyze files" -> smartFiles.analyze()
            t == "find duplicates" || t == "file duplicates" || t == "duplicate files" -> smartFiles.duplicates()
            t == "plan organize" || t == "preview organize" || t == "organize preview" -> smartFiles.planOrganize()
            t == "organize files" || t == "sort files" || t == "arrange files" -> smartFiles.organize(confirmed)
            t.startsWith("file search ") || t.startsWith("find file ") || t.startsWith("folder search ") -> files.search(raw.substringAfter(' ').substringAfter(' ').trim())
            t == "file list" || t == "list files" || t == "list folder" -> files.list()
            t.startsWith("file info ") || t.startsWith("file metadata ") -> AndroidControlResult(true, true, "File metadata ready.", files.metadata(raw.substringAfter(' ').substringAfter(' ').trim()))
            t.startsWith("create folder ") || t.startsWith("folder banao ") -> files.createFolder(raw.substringAfter(' ').substringAfter(' ').trim())
            t.startsWith("open file ") || t.startsWith("open folder ") -> files.open(raw.substringAfter(' ').substringAfter(' ').trim())
            t.startsWith("rename file ") -> { val m=Regex("(?i)^rename file (.+?) to (.+)$").find(raw); if(m==null) AndroidControlResult(false,false,"Rename format: rename file OLD to NEW") else files.rename(m.groupValues[1],m.groupValues[2],confirmed) }
            t.startsWith("delete file ") || t.startsWith("delete folder ") -> files.delete(raw.substringAfter(' ').substringAfter(' ').trim(),confirmed)
            t.startsWith("copy file ") -> { val m=Regex("(?i)^copy file (.+?) to (.+)$").find(raw); if(m==null) AndroidControlResult(false,false,"Copy format: copy file SOURCE to DEST") else files.copy(m.groupValues[1],m.groupValues[2],confirmed) }
            t.startsWith("move file ") -> { val m=Regex("(?i)^move file (.+?) to (.+)$").find(raw); if(m==null) AndroidControlResult(false,false,"Move format: move file SOURCE to DEST") else files.move(m.groupValues[1],m.groupValues[2],confirmed) }
            t.startsWith("zip ") -> { val m=Regex("(?i)^zip (.+?) to (.+\\.zip)$").find(raw); if(m==null) AndroidControlResult(false,false,"ZIP format: zip SOURCE to OUTPUT.zip") else files.zip(m.groupValues[1],m.groupValues[2]) }
            t.startsWith("extract zip ") -> { val m=Regex("(?i)^extract zip (.+?) to (.+)$").find(raw); if(m==null) AndroidControlResult(false,false,"Extract format: extract zip ARCHIVE.zip to FOLDER") else files.extract(m.groupValues[1],m.groupValues[2],confirmed) }
            Regex("^(home|go home|ghar)").containsMatchIn(t) -> control.home()
            Regex("^(back|go back|wapas)").containsMatchIn(t) -> control.back()
            Regex("^(recent|recents|recent apps)").containsMatchIn(t) -> control.recents()
            Regex("^(notifications?|notification panel)").containsMatchIn(t) -> control.notifications()
            Regex("^(quick settings|quick panel)").containsMatchIn(t) -> control.quickSettings()
            Regex("^(lock|lock phone|phone lock)").containsMatchIn(t) -> protected(control.lock())
            Regex("^(torch|flashlight)\\s+(on|off)").containsMatchIn(t) -> protected(control.torch(t.endsWith("on")))
            Regex("^(wifi|wi-fi)").containsMatchIn(t) -> control.wifi()
            Regex("^(bluetooth|blue tooth)").containsMatchIn(t) -> control.bluetooth()
            Regex("^(mobile data|data)").containsMatchIn(t) -> control.mobileData()
            Regex("^(dnd|do not disturb)(\\s+(on|off))?").containsMatchIn(t) -> {
                val m = Regex("^(?:dnd|do not disturb)(?:\\s+(on|off))?").find(t)
                val enabled = m?.groupValues?.getOrNull(1)?.takeIf { it.isNotBlank() }?.let { it == "on" }
                if (enabled == null) control.dnd() else protected(control.dnd(enabled))
            }
            Regex("^(rotation|auto rotation|auto-rotation)\\s+(on|off)").containsMatchIn(t) -> protected(control.rotation(t.endsWith("on")))
            Regex("^(brightness|roshni)\\s+(\\d{1,3})%?").containsMatchIn(t) -> protected(control.brightness(Regex("(\\d{1,3})").find(t)!!.groupValues[1].toInt()))
            Regex("^(volume|awaz)\\s+(up|down|increase|decrease|mute|barhao|kam)").containsMatchIn(t) -> protected(control.volume(Regex("(up|down|increase|decrease|mute|barhao|kam)").find(t)!!.groupValues[1]))
            t in setOf("screenshot", "screen shot", "screen capture") -> protected(control.screenshot())
            t in setOf("screen info", "screen information") -> control.screenInfo()
            t in setOf("battery", "battery info", "battery information") -> control.batteryInfo()
            t in setOf("storage", "storage info", "storage information") -> control.storageInfo()
            t in setOf("device info", "phone info", "device information") -> control.deviceInfo()
            t.startsWith("find app ") || t.startsWith("app search ") -> control.appSearch(raw.substringAfter(' '))
            t.startsWith("open app ") || t.startsWith("app kholo ") || t.startsWith("app khol ") -> control.openAppByName(raw.substringAfter(Regex("(?i)open app |app kholo |app khol ").find(raw)?.value ?: "open app ").trim())
            Regex("(?i)^(?:open|khol|kholo|select|choose)\\s+(?:the\\s+)?(?:chat|conversation)\\s+(.+)$").matches(raw) -> uiClick(Regex("(?i)^(?:open|khol|kholo|select|choose)\\s+(?:the\\s+)?(?:chat|conversation)\\s+(.+)$").find(raw)!!.groupValues[1], confirmed)
            t.startsWith("click ") || t.startsWith("tap ") || t.startsWith("press ") || t.startsWith("dabao ") -> uiClick(raw.substringAfter(' ').trim(), confirmed)
            t.startsWith("fill ") || t.startsWith("type ") || t.startsWith("enter ") -> {
                val m = Regex("(?i)^(?:fill|type|enter)\\s+(.+?)\\s+(?:in|into|mein|me)\\s+(.+)$").find(raw)
                if (m != null) uiFill(m.groupValues[2], m.groupValues[1], confirmed) else uiFill("", raw.substringAfter(' '), confirmed)
            }
            t in setOf("screen read", "screen dekho", "screen par kya hai", "visible ui", "screen samjho") -> uiRead()
            t in setOf("visual screen", "screen visual", "visual dekho", "screen ko samjho", "ui map") -> visualScreen()
            t in setOf("ocr", "screen ocr", "ocr screen", "screen text", "screen ka text") -> multimodalVision()
            t in setOf("vision", "visual analysis", "screen analyze", "screen analyse", "screen ko analyze karo", "screen ko analyse karo") -> multimodalVision()
            t in setOf("unified vision", "unified screen", "unified analyze", "screen unified", "screen ko fully analyze karo") -> unifiedVision()
            t.startsWith("unified find ") || t.startsWith("vision find ") -> unifiedFind(raw.substringAfter(' ').substringAfter(' ').trim())
            t.startsWith("unified click ") || t.startsWith("vision click ") -> protected(unifiedClick(raw.substringAfter(' ').substringAfter(' ').trim()))
            t.startsWith("find visual ") || t.startsWith("visual find ") -> visualFind(raw.substringAfter(' ').substringAfter(' ').trim())
            t.startsWith("scroll ") -> scroll(raw.substringAfter(' ').trim())
            else -> AndroidControlResult(false, false, "Android command samajh nahi aayi: $raw")
        }
    }

    fun isHighImpact(command: String): Boolean {
        val t = command.lowercase(Locale.ROOT)
        return listOf("call contact", "sms contact", "text contact", "email contact", "whatsapp contact", "message contact", "delete contact", "create contact", "edit contact", "lock", "torch on", "torch off", "flashlight on", "flashlight off", "brightness", "rotation", "volume", "dnd", "do not disturb", "click ", "tap ", "press ", "fill ", "type ", "enter ").any { t.contains(it) }
    }

    fun uiRead(): AndroidControlResult {
        val service = NovaAccessibilityService.instance ?: return AndroidControlResult(false, false, "Nova Accessibility Service enable karein.", requiresUserAction = true)
        return AndroidControlResult(true, true, "Visible Android UI read ho gayi.", mapOf("elements" to service.visibleUi()))
    }

    fun uiClick(target: String, confirmed: Boolean = false): AndroidControlResult {
        if (!confirmed) return AndroidControlResult(false, false, "UI click ke liye confirmation chahiye: $target", requiresUserAction = true)
        val service = NovaAccessibilityService.instance ?: return AndroidControlResult(false, false, "Nova Accessibility Service enable karein.", requiresUserAction = true)
        val agent = NovaAndroidUiAgent(service)
        val (ok, message) = agent.click(target)
        return AndroidControlResult(ok, ok, message, mapOf("target" to target))
    }

    fun uiFill(target: String, text: String, confirmed: Boolean = false): AndroidControlResult {
        if (!confirmed) return AndroidControlResult(false, false, "Text field fill karne ke liye confirmation chahiye.", requiresUserAction = true)
        val service = NovaAccessibilityService.instance ?: return AndroidControlResult(false, false, "Nova Accessibility Service enable karein.", requiresUserAction = true)
        val agent = NovaAndroidUiAgent(service)
        val (ok, message) = agent.fill(target, text)
        return AndroidControlResult(ok, ok, message, mapOf("target" to target))
    }

    fun visualScreen(): AndroidControlResult {
        val service = NovaAccessibilityService.instance ?: return AndroidControlResult(false, false, "Nova Accessibility Service enable karein.", requiresUserAction = true)
        val vision = NovaAndroidVisualIntelligence(service)
        return AndroidControlResult(true, true, vision.describe(), vision.screen())
    }

    fun multimodalVision(): AndroidControlResult {
        val service = NovaAccessibilityService.instance ?: return AndroidControlResult(false, false, "Nova Accessibility Service enable karein.", requiresUserAction = true)
        val result = NovaAndroidMultimodalVision(service).captureAndRead()
        return AndroidControlResult(result.success, result.verified, result.message, result.data)
    }

    fun unifiedVision(): AndroidControlResult {
        val service = NovaAccessibilityService.instance ?: return AndroidControlResult(false, false, "Nova Accessibility Service enable karein.", requiresUserAction = true)
        val result = NovaAndroidUnifiedVisionAgent(service).analyze()
        val data = result.targets.map { mapOf("label" to it.label, "source" to it.source, "score" to it.score, "left" to it.bounds.left, "top" to it.bounds.top, "right" to it.bounds.right, "bottom" to it.bounds.bottom, "clickable" to it.clickable, "editable" to it.editable) }
        return AndroidControlResult(result.success, result.verified, result.message, mapOf("targets" to data, "ocrCount" to result.ocrCount))
    }

    fun unifiedFind(target: String): AndroidControlResult {
        val service = NovaAccessibilityService.instance ?: return AndroidControlResult(false, false, "Nova Accessibility Service enable karein.", requiresUserAction = true)
        val result = NovaAndroidUnifiedVisionAgent(service).analyze(target)
        val data = result.targets.map { mapOf("label" to it.label, "source" to it.source, "score" to it.score, "left" to it.bounds.left, "top" to it.bounds.top, "right" to it.bounds.right, "bottom" to it.bounds.bottom, "clickable" to it.clickable, "editable" to it.editable) }
        return AndroidControlResult(result.success, result.verified, result.message, mapOf("targets" to data, "ocrCount" to result.ocrCount))
    }

    fun unifiedClick(target: String): AndroidControlResult {
        val service = NovaAccessibilityService.instance ?: return AndroidControlResult(false, false, "Nova Accessibility Service enable karein.", requiresUserAction = true)
        val (ok, message) = NovaAndroidUnifiedVisionAgent(service).click(target)
        return AndroidControlResult(ok, ok, message, mapOf("target" to target, "mode" to "unified-vision"))
    }

    fun visualFind(target: String): AndroidControlResult {
        val service = NovaAccessibilityService.instance ?: return AndroidControlResult(false, false, "Nova Accessibility Service enable karein.", requiresUserAction = true)
        val results = NovaAndroidVisualIntelligence(service).find(target)
        if (results.isEmpty()) return AndroidControlResult(false, true, "Visual UI target '$target' nahi mila.")
        val data = results.map { mapOf("label" to it.label, "role" to it.role, "score" to it.score, "left" to it.bounds.left, "top" to it.bounds.top, "right" to it.bounds.right, "bottom" to it.bounds.bottom, "clickable" to it.clickable, "editable" to it.editable) }
        return AndroidControlResult(true, true, "Visual target candidates mil gaye: ${results.joinToString { it.label }}", mapOf("targets" to data))
    }

    fun scroll(direction: String, target: String? = null): AndroidControlResult {
        val service = NovaAccessibilityService.instance ?: return AndroidControlResult(false, false, "Nova Accessibility Service enable karein.", requiresUserAction = true)
        val ok = if (direction.lowercase() in setOf("up", "back", "upar")) service.scrollBackward(target) else service.scrollForward(target)
        return AndroidControlResult(ok, ok, if (ok) "Scroll complete." else "Scrollable UI target nahi mila.")
    }
}
