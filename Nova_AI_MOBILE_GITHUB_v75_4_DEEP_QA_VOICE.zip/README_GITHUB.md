# Nova Mobile — GitHub Ready

This folder is the Android/mobile portion of Nova. It is prepared for GitHub Actions APK builds.

Build workflow: `.github/workflows/build-apk.yml`

Output: `app/build/outputs/apk/debug/app-debug.apk`


## IMPORTANT: GitHub ZIP upload
The ZIP itself is a package, not an Android-installable APK. GitHub Actions builds the APK from the extracted repository files.

### Easiest method
1. Download this ZIP.
2. Extract it.
3. Create an empty GitHub repository.
4. Upload the **contents of this extracted folder** to the repository root (including `.github/workflows/build-apk.yml`).
5. Open **Actions → Build Nova Android APK → Run workflow**.
6. Download the `nova-mobile-debug-apk` artifact and install the generated APK on Android.

### Why not upload the ZIP as one file?
A ZIP uploaded as `Nova.zip` is only a file in GitHub; GitHub Actions does not automatically treat its contents as the repository source, and the workflow inside that ZIP cannot start until a workflow exists in the repository.


## Fixed build configuration
- GitHub Actions uses JDK 17 and Gradle 8.11.1.
- Android Java and Kotlin JVM targets are both 17.
- Compose build features are enabled.
- Accessibility-service description is stored as an Android string resource.
- Fragment KTX is included because Nova uses FragmentActivity for biometric confirmation.

After uploading this project to GitHub, open **Actions → Build Nova Android APK → Run workflow**.
The generated APK is uploaded as the `nova-mobile-debug-apk` artifact.


## v73.4 Screen Vision
- Nova can capture the current visible Android screen after Accessibility is explicitly enabled.
- The screenshot is sent to the configured Gemini model for visual explanation.
- Password-like UI is not described by the vision system; keep sensitive screens closed when using cloud vision.
- Voice/text commands include: `screen samjho`, `screen explain`, `what is on my screen`.

## v73.5 Female Voice
Nova now prefers an available female/woman TTS voice for English and Urdu, with a slightly warm pitch and natural speech rate. Exact voice availability depends on the Android device/TTS engine and installed language packs.


### Voice v73.8
Enable Continuous Listening from the Nova Voice section. Say “Nova” or “نوا”; the wake recognizer alternates `en-US` and `ur-PK`. Manual Voice pauses wake listening to avoid microphone contention. Nova speech output pauses microphone recognition and resumes continuous listening after the reply.

## v74.0-RC1 — Nova Doctor + Security Center
Run the normal GitHub Actions `Build Nova APK` workflow. The APK version is 74.0-RC1 / build 81.


## v74.2 Natural Voice
Nova prefers Gemini 3.8 Flash TTS (`gemini-3.8-flash-tts`) for natural voice and falls back to Android TTS if AI TTS is unavailable. Configure the existing encrypted Gemini API key in Nova. Internet access is required for natural cloud voice.


## v74.4 Saraiki Voice
Natural TTS style is configured for clear Pakistani conversational delivery with Saraiki-style pronunciation when requested and an explicit instruction not to use Sindhi pronunciation/style.

## v74.5 Siri-style command flow
- Cold-start wake commands are now executed immediately instead of only opening the UI.
- Nova can answer greetings/identity questions by voice.
- Continuous listening preference is persisted and the wake service starts/stops with the toggle.
- Flow: hear “Nova” -> capture command -> understand/act -> natural voice response -> resume listening when enabled.
- Existing Android control/security confirmation gates remain in place for high-impact actions.


## v74.6 Continuous Conversation
- Siri-style follow-up context for multi-turn voice commands.
- Example: “Nova, WhatsApp kholo” → “Sajid ko message bhejo” → message text → “haan”.
- Keeps the last command for “dobara/again/repeat”.
- Sensitive message sending remains confirmation-gated.


### v74.7 PRO
Upload only this ZIP to the repository before running the Build Nova APK workflow. It adds Siri-style global cancel/help/status handling and preserves app-open commands for repeat.


## v74.8 — Calls + WhatsApp Professional
- “Nova, Sajid ko call karo” / “call Sajid” natural command.
- Contact lookup with permission and ambiguity handling.
- Call confirmation before opening Android dialer.
- WhatsApp message preview/confirmation workflow.
- Nova does not claim delivery when Android only opens a composer/chat.


## v74.9 WhatsApp & Messages Agent PRO
- Contacts permission is declared for contact resolution.
- WhatsApp draft opens the installed WhatsApp package when available, with web-intent fallback.
- Nova keeps confirmation before communication actions.
- Nova does not claim a message was sent unless the Android workflow actually reports the action; opening a draft is reported as a draft.
- User can say: “Nova, Sajid ko WhatsApp message bhejo: kal 8 baje aa jana.” Nova resolves the contact, prepares the draft, asks for confirmation, then opens WhatsApp for final review/send.

## v75.1 — Smart Notification Intelligence
Upload only this ZIP to the Nova GitHub repository. Build with the existing **Build Nova APK** workflow.

Test commands after enabling Notification Access:
- "Nova, latest notifications batao"
- "Nova, important notifications batao"
- "Nova, unread notifications sunao"
- "Nova, Sajid ka message kya hai?"

This feature reads only notifications available through Android's user-granted Notification Access service. It does not fabricate notification contents.

## v75.2 — Calendar + Live Weather
Upload only `Nova_AI_MOBILE_GITHUB_v75_2_CALENDAR_WEATHER.zip` and run **Build Nova APK**.
Test: “Nova, Karachi ka weather batao”, “Nova, Lahore ka mausam batao”, and “Nova, calendar dikhao”.

## v75.3 Alarm + Reminders
- Real Android AlarmManager scheduling for Nova reminders and alarms.
- High-priority Nova notification when the scheduled time arrives.
- Commands: "Nova, remind me to call Ali at kal 8 baje", "Nova, set alarm for meeting at 8 pm", "Nova, wake me up at 7 am".
- Confirmation is required before scheduling.
- Reminders/alarms are persisted and rescheduled after device boot when still in the future.
- Exact alarm permission is declared; if Android does not grant exact scheduling, Nova falls back to an allowed inexact idle alarm rather than claiming exact timing.


## v75.4 Deep QA + Natural Female-Style Voice
- Fixed Gemini 3.8 TTS request schema to use responseFormat.audio and complete WAV output.
- Uses Google Gemini 3.8 Flash TTS with the Leda youthful voice; exact gender is not guaranteed by Google's catalog, but the app requests a youthful feminine-style conversational delivery.
- Real Android CalendarProvider integration instead of app-only fake/local events.
- Alarm notifications use Android alarm category, alarm sound and timeout.
- No placeholder/dummy/Coming Soon feature markers found in source scan.
- Duplicate source basenames checked; only expected Gradle filename duplication across project levels exists.
