# Nova (Android voice assistant)

"Nova" kahein, wo jawab de: "Ji, main yahan hoon. Bataiye Boss, kya karna hai?" Phir hukm dein, jaise "Sajid ko message karo main late aaunga". Nova message parh kar poochta hai, "haan" par WhatsApp mein bhej deta hai.

## Chalane ke qadam

1. Android Studio (Koala ya naya) install karein. File > Open se `nova-android` folder kholein, Gradle sync khud ho jata hai.
2. Phone par Developer options > USB debugging on karein, USB se jorain, Run dabayein.
3. Nova kholein. Settings mein ye ijazatein dein (ek baar ka kaam):
   - "Background mein apps kholne ki ijazat dein": list mein Nova on karein.
   - "WhatsApp auto-send on karein": Accessibility mein Nova on karein.
   - "Battery ki pabandi hatayein": Nova ko Unrestricted karein.
4. "Nova shuru karein" dabayein, microphone, contacts, call aur notification ki ijazat dein.
5. Kahein: "Nova". Rokne ke liye notification mein "Rokein".

Phone par Google app aur internet chahiye (sunne ka kaam Google ki speech service karti hai), jab tak Picovoice wake word on na karein.

## Hukm (Roman Urdu / English / Urdu)

| Kahein | Nova kya karega |
| --- | --- |
| Nova | "Ji, main yahan hoon. Bataiye Boss, kya karna hai?" phir 18 second tak hukm bina dobara "Nova" kahe |
| Nova WhatsApp on karo | WhatsApp khol dega |
| Nova Sajid ko message karo main late aaunga | Message parh kar poochega, "haan" par bhej dega |
| Nova Sajid ko call karo | Contacts se number nikal kar call |
| Nova camera kholo / settings kholo | Koi bhi installed app |
| Nova torch on karo / band karo | Torch |
| Nova alarm laga do 7 baje subah | Alarm (waqt na bataein to poochega) |
| Nova 10 minute ka timer laga do | Timer |
| Nova awaaz barhao / kam karo / full karo / mute karo | Media volume |
| Nova YouTube par X search karo | YouTube search |
| Nova Google par X search karo | Google search |
| Nova map par X dhoondo | Google Maps |
| Nova time kya hai / aaj ki date | Waqt aur tareekh |
| Nova latifa sunao | Latifa |

## Settings ke hisse

- **Nova aap ko kya kehe:** "Boss" ki jagah koi aur naam.
- **Sunna:** "Sirf headphones lage hon to sunein" (shuru se band, headphones ke baghair bhi chalta hai), "Sirf Nova kehne par hukm manein", aur "Urdu mein sunein" (Urdu script).
- **Asli wake word (Picovoice):** neeche dekhein.
- **Smart mode:** Claude AI se roz ke aam jumle samajhna. Apni API key, ya (behtar) apne server ka URL aur token.
- **Awaaz:** phone ki awaaz chunna, raftar (default thori tez), sur, buland bolna, cloud awaaz.
- **Masla bhejein:** baat cheet ka record aur aakhri crash kisi app (email, WhatsApp) ke zariye share karna.

## Asli wake word (Picovoice Porcupine)

Isse "Nova" sunne ka kaam phone par hi hota hai, battery bohat kam lagti hai aur baat cheet Google ko nahi jati.

1. console.picovoice.ai par muft account banayein, AccessKey copy karein.
2. Wahin "Porcupine" mein custom wake word "Nova" train karein. Platform: Android. Language: English. Download se `.ppn` file milegi.
3. File phone mein copy karein (Downloads mein).
4. Nova > Settings: AccessKey likhein, "Nova wake word file (.ppn) chunein" dabayein aur file chunein.
5. Nova band karke dobara shuru karein. Log mein "Wake word mode on hai" aana chahiye.

Kuch na ho to Nova khud purane Google speech wale tareeqe par chalta rehta hai. Ye hissa phone par abhi chala kar nahi dekha gaya.

## Natural cloud awaaz

1. Google Cloud Console mein project banayein, "Cloud Text-to-Speech API" on karein, API key banayein (key ko sirf is API tak mehdood karein).
2. Nova > Settings: "Natural cloud awaaz" tick karein, key likhein, "Awaaz suna kar dekhein" dabayein.
3. Urdu ke liye `ur-IN-Wavenet-A`, English ke liye `en-IN-Wavenet-A` (dono larki ki awaaz) istemal hoti hain (`NovaApp.kt` ke upar badal sakte hain). Google ki awaaz ki list mein naam badal sakte hain.
4. Cloud na chale (internet, key, kota) to Nova khud phone ki awaaz par wapas aa jata hai.
5. Google Cloud TTS ka muft kota hota hai, us ke baad paise lagte hain. Qeemat Google ki site par dekhein.

## Sirf headphones lage hon to

Ye setting ikhtiyari hai aur shuru se band hai, yani Nova headphones ke baghair bhi sunta hai. Is ka tick lagane par headphones (wired, USB ya Bluetooth) nahi lage to Nova sunna band kar ke so jata hai (screen par "Headphones nahi lage, Nova so raha hai"), aur headphones lagte hi khud jaag kar sunna shuru kar deta hai. Nikalne par phir so jata hai. Setting badalne par chalta hua Nova foran badal jata hai. Har waqt sunna chahiye to tick hata dein.

Dhyan rahe: Android Bluetooth speaker ya gaari ke audio ko bhi headphones ki tarah dikhata hai, un mein farq nahi kar sakta.

## Phone restart ke baad

Android microphone wali service ko restart par khud shuru nahi hone deta, isliye restart ke baad "Nova taiyar hai" notification aata hai. Usay ek baar dabayein, phir Nova sunna shuru kar deta hai.

## Apna server (Play Store ya doosron ke liye)

`server/nova-proxy.js`: chhota Node server jo Claude API key apne paas rakhta hai. App sirf token bhejti hai.

    ANTHROPIC_API_KEY=sk-ant-... NOVA_TOKENS=token1,token2 node server/nova-proxy.js

Nova > Settings: Server URL `https://aap-ka-server/v1/messages`, key wali jagah `token1`. Server sirf Haiku model, chhota jawab aur har token ke liye 30 sawal fi minute mante hain (`NOVA_RATE_PER_MINUTE`). HTTPS ke liye server ko Caddy, nginx ya Cloud Run ke peeche rakhein.

## Tests

`CommandParserTest.kt`: hukm samajhne wale hisse ke 18 test. Android Studio mein us file par right-click > Run, ya `./gradlew test`.

## Play Store

`PLAY_STORE.md` (qadam, accessibility ka bayan, data safety), `PRIVACY.md` (privacy policy ka dhancha), `keystore.properties.example` (signed build). Icon app mein vector hai, store ke liye 512x512 PNG alag se banani hogi.

## Files

- `NovaService.kt`: foreground service, Nova ko background mein zinda rakhti hai.
- `NovaEngine.kt`: sunna, bolna, haan/nahi ki tasdeeq, har hukm ka kaam.
- `NovaWake.kt`: Picovoice wake word.
- `NovaBrain.kt`: Claude AI (seedha ya apne server se).
- `CommandParser.kt`: seedhe hukm (bina AI ke). Naya hukm yahan se shuru karein.
- `NovaActions.kt`: contacts, WhatsApp, call, app, torch, alarm, timer, volume.
- `NovaAccessibilityService.kt`: WhatsApp ka Send button dabata hai, phir wapas aata hai.
- `NovaApp.kt`: awaaz (phone aur cloud), crash log.
- `BootReceiver.kt`: restart ke baad notification.
- `NovaBus.kt`, `MainActivity.kt`: screen aur settings.

## Hadood

- Pura code abhi tak Android Studio mein build karke phone par chala kar nahi dekha gaya. Hukm samajhne wala hissa alag se parakh liya gaya hai (test cases), aur proxy server chala kar dekha gaya hai.
- Kuch phones (Xiaomi, Oppo, Vivo, Samsung) background apps band kar dete hain. Battery ki pabandi hatana zaroori hai.
- Sunne ke har chakkar par kuch phones halki beep bajate hain (Google speech mode mein).
- Doosri app microphone istemal kar rahi ho (call, voice note) to Nova nahi sun sakta.
- WhatsApp update ke baad Send button ki pehchan badal sakti hai. Code description se bhi dhoondta hai.
- "Sirf headphones" mein Bluetooth speaker aur gaari ka audio bhi headphones ginay jate hain.
- Wi-Fi, Bluetooth ya brightness jaise system switch Android apps ko seedha badalne nahi deta.
- Number 03 se shuru ho to +92 lagta hai (`NovaActions.DEFAULT_COUNTRY_CODE`).
