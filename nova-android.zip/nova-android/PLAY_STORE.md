# Play Store par daalne ki tayyari

Ye file qadam batati hai. Play Console ke asli fields aur policy samay ke saath badalti rehti hain, isliye har form khud parh kar bharein.

## 1. Pehle ye zaroori hai

1. **API key app se nikaal dein.** Smart mode ke liye `server/nova-proxy.js` apne server par chalayein (README dekhein). App mein "Server URL" aur token dein, Anthropic key kabhi nahi.
2. **Apna Google Cloud TTS key** bhi server ke peeche rakhein, ya cloud awaaz ko release se hata dein. App mein key likhwana sirf zaati istemal ke liye theek hai.
3. **Picovoice** ka free plan zaati istemal ke liye hai. Sab ko dene ke liye unki commercial shartein dekhein, aur har user ki AccessKey khud app mein na dalwayein.
4. **`PRIVACY.md`** mein [ ] wali jagahein bharein aur ise kisi public web page par rakhein (GitHub Pages theek hai). Is ka link Play Console mein dena hoga.
5. **Package naam** `com.nova.assistant` badal kar apna rakhein (`app/build.gradle.kts` ke `namespace` aur `applicationId`, aur Kotlin ki files ka package).

## 2. Signed release build

1. Keystore banayein: `keytool -genkey -v -keystore nova-release.jks -keyalg RSA -keysize 2048 -validity 10000 -alias nova`
2. `keystore.properties.example` ko `keystore.properties` naam se copy karke bharein.
3. Android Studio: Build > Generate Signed Bundle / APK > Android App Bundle (.aab).
4. Keystore aur uska password mehfooz jagah rakhein. Ye kho gaya to app update nahi ho sakti.

## 3. Accessibility service ka bayan (sab se sakht hissa)

Google accessibility API ko sirf tab manta hai jab wo app ka asli kaam ho aur saaf bataya gaya ho. Play Console mein "Accessibility API declaration" bharte waqt:

- **Maqsad:** Awaaz se bheje gaye WhatsApp message ka Send button dabana, un logon ke liye jinke haath masroof hain ya jo screen nahi dekh sakte.
- **Kab chalti hai:** Sirf us waqt jab user ne awaaz se message bhejne ko kaha aur "haan" se tasdeeq ki. Baqi waqt wo kuch nahi karti.
- **Kya dekhti hai:** Sirf WhatsApp ki window (`accessibility_config.xml` mein `packageNames` sirf `com.whatsapp` aur `com.whatsapp.w4b`).
- **Data:** Kuch save ya bheja nahi jata.
- Ek chhoti video (30-60 second) banayein: awaaz se message, tasdeeq, Send khud dabna, aur Settings mein accessibility on karne ka manzar.

Dhyan rahe: Google kabhi is qism ki app ko manzoor nahi karta. Agar mana ho jaye to doosra raasta ye hai ke accessibility ke baghair message WhatsApp mein khul jaye aur user Send khud dabaye (Nova ye pehle se karta hai jab accessibility off ho).

## 4. Doosre foreground aur permission ke bayan

- **Foreground service type "microphone":** Nova "Nova" sunne ke liye background mein chalta hai. Notification mein hamesha dikhta hai aur "Rokein" ka button hai.
- **SYSTEM_ALERT_WINDOW:** Background se WhatsApp ya doosri app kholne ke liye. Is ke liye user ko Settings mein ijazat deni hoti hai.
- **READ_CONTACTS, CALL_PHONE:** "Sajid ko message / call karo" ke liye. `PRIVACY.md` mein likha hai.
- Google Play ki taraf se in permissions par sawal aa sakte hain. Har permission ka jawab apne asli istemal se dein.

## 5. Data safety form (muqarrar jawab nahi, apne asli tareeqe se bharein)

Is app ke hisaab se aam taur par:

- **Awaaz:** Sunne ke liye istemal hoti hai, Google ki speech service ko jati hai.
- **Contacts:** Phone par hi istemal hota hai; Smart mode on ho to sirf naam bheje jate hain.
- **Baat cheet ke jumle:** Smart mode on ho to Anthropic ko bheje jate hain.
- **Koi advertising ya tracking nahi.**
- **Data delete karne ka tareeqa:** App delete karna.

## 6. Store listing (nafri)

- **Naam:** Nova: Awaaz Assistant
- **Mukhtasar:** "Nova" kahein aur WhatsApp message, call, alarm, app aur bohat kuch awaaz se karein. Roman Urdu, Urdu aur English.
- **Tafseel:** Nova aap ka bolne wala dost hai. "Nova" kahein, wo jawab de "Ji Boss, kya karna hai?", phir kahein "Sajid ko message karo main late aaunga". Nova message parh kar poochega, aur aap ke "haan" par bhej dega. Call, alarm, timer, torch, awaaz, YouTube, Google aur map bhi.
- **Screenshots:** Kam az kam 2 phone ke screenshots. Settings ke sab hisse dikhayein.
- **Icon:** 512x512 PNG alag se chahiye (app ke andar wala icon vector hai).

## 7. Test aur rollout

1. Pehle "Internal testing" mein apne doston ke phones par chalayein.
2. Alag alag phones par dekhein (Samsung, Xiaomi, Oppo): background mein band hone ka masla, WhatsApp ka Send button.
3. Phir "Closed testing", aur Play ki shart ke mutabiq naye personal account ke liye kam az kam 12 testers 14 din tak.
4. Is ke baad hi production.
