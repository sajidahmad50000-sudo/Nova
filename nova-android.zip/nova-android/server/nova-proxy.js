// Nova ka chhota proxy server (Node 18+, koi package nahi chahiye).
//
// Kyun: Play Store par ya doosron ko app dete waqt Claude API key app ke andar nahi honi chahiye.
// Key is server par rehti hai. App sirf apna token (x-nova-token) bhejti hai.
//
// Chalane ke liye:
//   ANTHROPIC_API_KEY=sk-ant-... NOVA_TOKENS=token1,token2 node nova-proxy.js
// Phir Nova ki Settings mein: Server URL = https://aap-ka-server/v1/messages, key wali jagah token1.
// HTTPS ke liye server ko Caddy / nginx / Cloud Run jaisi cheez ke peeche rakhein.

const http = require('http');
const https = require('https');

const PORT = process.env.PORT || 8787;
const API_KEY = process.env.ANTHROPIC_API_KEY;
const TOKENS = new Set((process.env.NOVA_TOKENS || '').split(',').map(s => s.trim()).filter(Boolean));
const ALLOWED_MODELS = new Set((process.env.NOVA_MODELS || 'claude-haiku-5-5').split(','));
const MAX_TOKENS_CAP = 500;
const MAX_BODY_BYTES = 64 * 1024;
const PER_MINUTE = Number(process.env.NOVA_RATE_PER_MINUTE || 30);

const hits = new Map(); // token -> [timestamps]

function limited(token) {
  const now = Date.now();
  const list = (hits.get(token) || []).filter(t => now - t < 60000);
  list.push(now);
  hits.set(token, list);
  return list.length > PER_MINUTE;
}

function send(res, code, obj) {
  res.writeHead(code, { 'content-type': 'application/json' });
  res.end(JSON.stringify(obj));
}

function handler(req, res) {
  if (req.method === 'GET' && req.url === '/health') return send(res, 200, { ok: true });
  if (req.method !== 'POST' || req.url !== '/v1/messages') return send(res, 404, { error: 'not found' });

  const token = req.headers['x-nova-token'];
  if (!token || !TOKENS.has(token)) return send(res, 401, { error: 'bad token' });
  if (limited(token)) return send(res, 429, { error: 'too many requests' });

  let size = 0;
  const chunks = [];
  req.on('data', c => {
    size += c.length;
    if (size > MAX_BODY_BYTES) { send(res, 413, { error: 'too large' }); req.destroy(); return; }
    chunks.push(c);
  });
  req.on('end', () => {
    let body;
    try { body = JSON.parse(Buffer.concat(chunks).toString('utf8')); }
    catch (e) { return send(res, 400, { error: 'bad json' }); }

    // Sirf wohi model aur chhota jawab, taake koi token se mehnga kaam na karwa sake.
    if (!ALLOWED_MODELS.has(body.model)) return send(res, 400, { error: 'model not allowed' });
    body.max_tokens = Math.min(Number(body.max_tokens) || MAX_TOKENS_CAP, MAX_TOKENS_CAP);
    body.stream = false;

    const payload = JSON.stringify(body);
    const up = https.request({
      hostname: 'api.anthropic.com',
      path: '/v1/messages',
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        'content-length': Buffer.byteLength(payload),
        'x-api-key': API_KEY,
        'anthropic-version': '2023-06-01',
      },
    }, upRes => {
      res.writeHead(upRes.statusCode || 502, { 'content-type': 'application/json' });
      upRes.pipe(res);
    });
    up.on('error', () => send(res, 502, { error: 'upstream error' }));
    up.setTimeout(20000, () => up.destroy());
    up.end(payload);
  });
}

if (require.main === module) {
  if (!API_KEY) { console.error('ANTHROPIC_API_KEY set karein.'); process.exit(1); }
  if (TOKENS.size === 0) { console.error('NOVA_TOKENS set karein (comma se alag).'); process.exit(1); }
  http.createServer(handler).listen(PORT, () => console.log('Nova proxy chal raha hai, port ' + PORT));
}

module.exports = { handler };
