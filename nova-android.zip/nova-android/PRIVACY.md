# Nova: Privacy Policy

Aakhri tabdeeli: [TAREEKH LIKHEIN]
App banane wala: [AAP KA NAAM / ADARA]
Rabta: [AAP KA EMAIL]

Nova ek awaaz se chalne wala assistant hai. Ye policy batati hai ke Nova kaun sa data istemal karta hai aur kahan bhejta hai. (Is file mein [ ] wali jagahein apne naam se bhar kar hi publish karein.)

## Nova kya istemal karta hai aur kyun

| Cheez | Kyun chahiye | Kahan jati hai |
| --- | --- | --- |
| Microphone | Aap ke hukm sunne ke liye | Phone ki speech service (Google) ko, sunne ke dauran. Wake word mode (Picovoice) mein "Nova" sunne ka kaam phone par hi hota hai. |
| Contacts (naam aur number) | "Sajid ko message karo" jaise hukm mein sahi shakhs ka number dhoondne ke liye | Number phone se bahar nahi jata. Smart mode on ho to sirf naam (number nahi) AI ko jate hain. |
| Phone / call ki ijazat | "Sajid ko call karo" ke liye | Phone se bahar nahi jata. |
| Accessibility service | WhatsApp mein aap ke tasdeeq kiye hue message ka Send button dabane ke liye | Phone se bahar nahi jata. Ye sirf WhatsApp ki window dekhti hai, aur sirf tab jab Nova ne message bhejna shuru kiya ho. |
| Notifications | Nova chal raha hai ye dikhane ke liye | Phone se bahar nahi jata. |
| Doosri apps ke upar dikhna | Background mein WhatsApp ya doosri app kholne ke liye | Phone se bahar nahi jata. |

## Smart mode (ikhtiyari)

Smart mode on karne par, sirf wo jumle jo "Nova" se shuru hon (jaise "Nova, Sajid ko bata do main late aaunga") aur contacts ke naam Anthropic (Claude AI) ko bheje jate hain, taake hukm samjha ja sake. Anthropic ki policy: https://www.anthropic.com/legal/privacy. Baqi baat chit bheji nahi jati. Agar aap apna server istemal karein to ye data pehle us server par jata hai.

## Cloud awaaz (ikhtiyari)

Cloud awaaz on karne par Nova jo jumla bolne wala hota hai wo Google Cloud Text-to-Speech ko bheja jata hai taake awaaz banai ja sake. Aap ki awaaz ya contacts nahi bheje jate.

## Hum kya save karte hain

- Settings, API keys aur contacts ka koi record sirf aap ke phone ke private storage mein hai. Hum apne servers par kuch save nahi karte.
- Baat cheet ka record sirf app ke chalne tak yaad mein rehta hai.
- App crash ho to aakhri crash ka matan phone par save hota hai. Wo tab hi kahin jata hai jab aap khud "Masla bhejein" dabayein.
- Kisi qism ki advertising ya tracking nahi hai.

## Aap ke ikhtiyar

- Kisi bhi ijazat ko phone ki Settings se kabhi bhi wapas le sakte hain.
- Smart mode aur cloud awaaz band karne par koi data bahar nahi jata.
- Nova ko "Rokein" se foran rok sakte hain.
- App delete karne par is ka saara data phone se mit jata hai.

## Bachon ke liye

Nova 13 saal se kam umar ke bachon ke liye nahi hai.

## Tabdeeli

Is policy mein tabdeeli ho to ye file aur Play Store ka page update kiya jayega.
