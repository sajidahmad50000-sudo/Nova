package com.nova.assistant

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class CommandParserTest {

    private fun p(text: String, wake: Boolean = false) = CommandParser.parse(text, wake)

    @Test fun wakeWordAloneGivesWake() {
        assertEquals(Command.Wake, p("Nova", wake = true))
        assertEquals(Command.Wake, p("hey nova", wake = true))
    }

    @Test fun sentencesWithoutWakeWordAreIgnoredWhenRequired() {
        assertNull(p("Sajid ko message karo main late aaunga", wake = true))
        assertNull(p("time kya hai", wake = true))
    }

    @Test fun romanUrduMessage() {
        val c = p("Nova Sajid ko msg karo main late aoo ga", wake = true)
        assertEquals(Command.Message("Sajid", "main late aoo ga"), c)
    }

    @Test fun messageWithoutBody() {
        assertEquals(Command.Message("Ali", ""), p("Ali ko message karo"))
    }

    @Test fun englishMessage() {
        assertEquals(Command.Message("Sajid", "I will be late"), p("message Sajid I will be late"))
    }

    @Test fun urduScriptMessage() {
        assertEquals(Command.Message("ساجد", "میں لیٹ آؤں گا"), p("ساجد کو میسج کرو میں لیٹ آؤں گا"))
    }

    @Test fun call() {
        assertEquals(Command.Call("Sajid"), p("Sajid ko call karo"))
        assertEquals(Command.Call("Ali"), p("call Ali"))
    }

    @Test fun whatsappOpen() {
        assertEquals(Command.OpenWhatsApp, p("WhatsApp on karo"))
    }

    @Test fun torch() {
        assertEquals(Command.Torch(true), p("torch on karo"))
        assertEquals(Command.Torch(false), p("torch band karo"))
    }

    @Test fun alarmAndClock() {
        assertEquals(Command.Alarm(7, 0), p("alarm laga do 7 baje subah"))
        assertEquals(Command.Alarm(18, 30), p("alarm 6:30 shaam"))
        assertEquals(Command.Alarm(-1, -1), p("alarm laga do"))
    }

    @Test fun timer() {
        assertEquals(Command.Timer(600), p("10 minute ka timer laga do"))
        assertEquals(Command.Timer(3900), p("timer 1 ghanta 5 minute"))
        assertEquals(Command.Timer(0), p("timer laga do"))
    }

    @Test fun volume() {
        assertEquals(Command.Volume("up"), p("awaaz barhao"))
        assertEquals(Command.Volume("down"), p("awaaz kam karo"))
        assertEquals(Command.Volume("max"), p("volume full karo"))
        assertEquals(Command.Volume("mute"), p("awaaz mute karo"))
    }

    @Test fun webSearches() {
        assertEquals(Command.Web("google", "mausam"), p("Google par mausam search karo"))
        assertEquals(Command.Web("youtube", "cricket highlights"), p("YouTube par cricket highlights search karo"))
        assertEquals(Command.Web("maps", "karachi airport"), p("map par Karachi airport dhoondo"))
        assertEquals(Command.OpenApp("youtube"), p("YouTube kholo"))
    }

    @Test fun timeDateJoke() {
        assertEquals(Command.TimeCmd, p("time kya hai"))
        assertEquals(Command.DateCmd, p("aaj ki date kya hai"))
        assertEquals(Command.Joke, p("latifa sunao"))
    }

    @Test fun openAnyApp() {
        assertEquals(Command.OpenApp("camera"), p("camera kholo"))
        assertEquals(Command.OpenApp("settings"), p("open settings"))
    }

    @Test fun urduWakeWord() {
        assertEquals(Command.Wake, p("نووا", wake = true))
    }

    @Test fun yesNo() {
        assertTrue(CommandParser.yes.containsMatchIn("haan bhejo"))
        assertTrue(CommandParser.no.containsMatchIn("nahi rehne do"))
        assertTrue(!CommandParser.yes.containsMatchIn("nahi"))
    }

    @Test fun unknownFallsThrough() {
        assertTrue(p("kuch bhi random baat") is Command.Unknown)
    }
}
