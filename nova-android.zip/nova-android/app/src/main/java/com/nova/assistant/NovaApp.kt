package com.nova.assistant

import android.app.Application
import android.content.Context
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import android.util.Base64
import android.util.Log
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.Date
import java.util.Locale
import java.util.UUID

/**
 * Nova ki awaaz. Do raaste:
 *  1. Cloud awaaz (Google Cloud Text-to-Speech): sab se natural, key chahiye, internet chahiye.
 *  2. Phone ki awaaz (TextToSpeech): muft, offline. Cloud na chale to khud yahi istemal hoti hai.
 * Is ke ilawa: crash log (masla hone par "Masla bhejein" button ke liye).
 */
class NovaApp : Application(), TextToSpeech.OnInitListener {

    companion object {
        lateinit var instance: NovaApp
            private set
        const val DEFAULT_RATE = 115   // 100 = aam raftar. 115 thori tez, saaf.
        const val DEFAULT_PITCH = 110  // 110 thora unchi, naram sur.
        private const val CLOUD_URDU_VOICE = "ur-IN-Wavenet-A"   // larki
        private const val CLOUD_ENGLISH_VOICE = "en-IN-Wavenet-A" // larki
    }

    private var tts: TextToSpeech? = null
    private var ready = false
    private var player: MediaPlayer? = null
    private val main = Handler(Looper.getMainLooper())
    private val callbacks = HashMap<String, () -> Unit>()

    override fun onCreate() {
        super.onCreate()
        instance = this
        installCrashLog()
        tts = TextToSpeech(this, this)
    }

    private fun installCrashLog() {
        val old = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                File(filesDir, "crash.log").writeText("${Date()}\n${Log.getStackTraceString(e)}")
            } catch (ignored: Exception) {
            }
            old?.uncaughtException(t, e)
        }
    }

    /** Aakhri crash ka matan, ya null. */
    fun lastCrash(): String? = try {
        File(filesDir, "crash.log").takeIf { it.exists() }?.readText()
    } catch (e: Exception) {
        null
    }

    override fun onInit(status: Int) {
        if (status != TextToSpeech.SUCCESS) return
        tts?.setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANT)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()
        )
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) = finish(utteranceId)
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) = finish(utteranceId)
        })
        ready = true
    }

    private fun prefs() = getSharedPreferences("nova", Context.MODE_PRIVATE)

    private fun finish(id: String?) {
        val cb = synchronized(callbacks) { callbacks.remove(id) } ?: return
        main.post { cb() }
    }

    // ---------- phone ki awaaz ki list ----------

    /** Phone mein maujood Urdu, English aur Hindi awaazein. Pehle Urdu, phir behtar quality. */
    fun voiceList(): List<Voice> {
        val all = try { tts?.voices } catch (e: Exception) { null } ?: return emptyList()
        return all
            .filter { it.locale.language in setOf("ur", "en", "hi") && !it.features.contains("notInstalled") }
            .sortedWith(
                compareBy<Voice>(
                    { it.locale.language != "ur" },
                    { it.locale.language != "en" },
                    { it.locale.country != "IN" && it.locale.country != "PK" },
                    { -it.quality },
                    { it.name }
                )
            )
    }

    /** Chuni hui awaaz, ya khud chunne par: Urdu awaaz agar ho, warna English (India). */
    fun currentVoice(): Voice? {
        val list = voiceList()
        val chosen = prefs().getString("voice", "").orEmpty()
        if (chosen.isNotEmpty()) list.firstOrNull { it.name == chosen }?.let { return it }
        return list.firstOrNull { it.locale.language == "ur" }
            ?: list.firstOrNull { it.locale.toLanguageTag() == "en-IN" }
            ?: list.firstOrNull { it.locale.language == "en" }
    }

    private fun cloudOn(): Boolean =
        prefs().getBoolean("cloud", false) && !prefs().getString("cloudkey", "").isNullOrBlank()

    /** Cloud awaaz ya Urdu awaaz ho to Nova Urdu script mein bolta hai. */
    fun speaksUrdu(): Boolean = cloudOn() || currentVoice()?.locale?.language == "ur"

    // ---------- bolna ----------

    fun say(text: String, then: (() -> Unit)? = null) {
        boostVolume()
        if (cloudOn()) sayCloud(text, then) else sayLocal(text, then)
    }

    private fun applyVoice() {
        val p = prefs()
        tts?.setSpeechRate(p.getInt("rate", DEFAULT_RATE) / 100f)
        tts?.setPitch(p.getInt("pitch", DEFAULT_PITCH) / 100f)
        val v = currentVoice()
        if (v != null) tts?.voice = v else tts?.language = Locale("en", "IN")
    }

    /** "Nova buland bole" on ho to media volume kam az kam 85% rakhta hai. */
    private fun boostVolume() {
        if (!prefs().getBoolean("loud", true)) return
        try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            val target = (max * 0.85).toInt()
            if (am.getStreamVolume(AudioManager.STREAM_MUSIC) < target) {
                am.setStreamVolume(AudioManager.STREAM_MUSIC, target, 0)
            }
        } catch (e: Exception) {
            // Do Not Disturb jaisi wajah se volume badalne ki ijazat na ho to chhor dein.
        }
    }

    private fun sayLocal(text: String, then: (() -> Unit)?) {
        val id = UUID.randomUUID().toString()
        if (!ready) { then?.let { main.post(it) }; return }
        if (then != null) synchronized(callbacks) { callbacks[id] = then }
        applyVoice()
        val params = Bundle().apply { putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, 1.0f) }
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, params, id)
    }

    // ---------- cloud awaaz ----------

    private fun sayCloud(text: String, then: (() -> Unit)?) {
        val key = prefs().getString("cloudkey", "").orEmpty().trim()
        val rate = prefs().getInt("rate", DEFAULT_RATE) / 100.0
        val pitchSemis = (prefs().getInt("pitch", DEFAULT_PITCH) - 100) / 10.0
        Thread {
            val file = try { fetchCloudAudio(key, text, rate, pitchSemis) } catch (e: Exception) { null }
            main.post {
                if (file == null) sayLocal(text, then) else playFile(file, then)
            }
        }.start()
    }

    private fun fetchCloudAudio(key: String, text: String, rate: Double, pitch: Double): File? {
        val urdu = text.any { it.code in 0x0600..0x06FF }
        val body = JSONObject()
            .put("input", JSONObject().put("text", text))
            .put(
                "voice", JSONObject()
                    .put("languageCode", if (urdu) "ur-IN" else "en-IN")
                    .put("name", if (urdu) CLOUD_URDU_VOICE else CLOUD_ENGLISH_VOICE)
            )
            .put(
                "audioConfig", JSONObject()
                    .put("audioEncoding", "MP3")
                    .put("speakingRate", rate.coerceIn(0.25, 2.0))
                    .put("pitch", pitch.coerceIn(-10.0, 10.0))
                    .put("volumeGainDb", 6.0)
            )
        val conn = URL("https://texttospeech.googleapis.com/v1/text:synthesize?key=$key").openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 6000
            conn.readTimeout = 12000
            conn.doOutput = true
            conn.setRequestProperty("content-type", "application/json")
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            if (conn.responseCode !in 200..299) return null
            val resp = conn.inputStream.bufferedReader().use { it.readText() }
            val bytes = Base64.decode(JSONObject(resp).getString("audioContent"), Base64.DEFAULT)
            val out = File(cacheDir, "nova_tts_${System.nanoTime()}.mp3")
            out.writeBytes(bytes)
            return out
        } finally {
            conn.disconnect()
        }
    }

    private fun playFile(file: File, then: (() -> Unit)?) {
        releasePlayer()
        try {
            val mp = MediaPlayer()
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANT)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            mp.setDataSource(file.absolutePath)
            mp.setOnCompletionListener { releasePlayer(); file.delete(); then?.invoke() }
            mp.setOnErrorListener { _, _, _ -> releasePlayer(); file.delete(); then?.invoke(); true }
            mp.prepare()
            mp.start()
            player = mp
        } catch (e: Exception) {
            file.delete()
            then?.invoke()
        }
    }

    private fun releasePlayer() {
        try { player?.release() } catch (e: Exception) { }
        player = null
    }

    /** Settings mein "awaaz suna kar dekhein" ke liye. */
    fun sample() {
        if (speaksUrdu()) say("السلام علیکم! میں نووا ہوں۔ بتائیے، میں آپ کی کیا مدد کروں؟")
        else say("Assalam o alaikum! Main Nova hoon. Bataiye, main aap ki kya madad karun?")
    }

    fun stop() {
        tts?.stop()
        releasePlayer()
    }
}
