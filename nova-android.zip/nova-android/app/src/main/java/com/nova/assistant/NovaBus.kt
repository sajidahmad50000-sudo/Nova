package com.nova.assistant

/**
 * Service aur screen ke beech chhota sa rabta. Sab kuch main thread par hota hai.
 */
object NovaBus {
    val lines = ArrayList<String>()
    @Volatile
    var running = false
    var statusText = "Nova band hai"
    var listener: (() -> Unit)? = null

    fun add(line: String) {
        lines.add(line)
        if (lines.size > 200) lines.removeAt(0)
        listener?.invoke()
    }

    fun status(text: String) {
        statusText = text
        listener?.invoke()
    }

    fun notifyChanged() {
        listener?.invoke()
    }
}
