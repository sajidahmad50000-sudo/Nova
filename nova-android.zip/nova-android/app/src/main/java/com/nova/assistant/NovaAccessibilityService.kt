package com.nova.assistant

import android.accessibilityservice.AccessibilityService
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Jab Nova ne message tayyar karke WhatsApp khola ho (arm() ke baad 20 second tak),
 * yeh WhatsApp ka Send button dhoondh kar dabata hai, phir wapas Nova par aa jata hai.
 * Is ke ilawa yeh kuch nahi karta aur sirf WhatsApp ki window dekhta hai (accessibility_config.xml).
 */
class NovaAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        private var armedUntil = 0L
        @Volatile
        var pendingName: String = ""

        fun arm(name: String) {
            pendingName = name
            armedUntil = System.currentTimeMillis() + 20_000
        }
    }

    private val main = Handler(Looper.getMainLooper())

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (System.currentTimeMillis() > armedUntil) return
        val pkg = event?.packageName?.toString() ?: return
        if (!pkg.startsWith("com.whatsapp")) return
        val root = rootInActiveWindow ?: return

        val send = root.findAccessibilityNodeInfosByViewId("$pkg:id/send").firstOrNull()
            ?: findByDescription(root, listOf("send", "بھیجیں"))
            ?: return

        if (clickNode(send)) {
            armedUntil = 0L
            val name = pendingName
            main.postDelayed({
                performGlobalAction(GLOBAL_ACTION_BACK)
                val urdu = NovaApp.instance.speaksUrdu()
                NovaApp.instance.say(
                    if (urdu) (if (name.isNotEmpty()) "$name کو پیغام بھیج دیا ہے۔" else "پیغام بھیج دیا ہے۔")
                    else (if (name.isNotEmpty()) "$name ko message bhej diya hai." else "Message bhej diya hai.")
                )
            }, 900)
        }
    }

    private fun clickNode(node: AccessibilityNodeInfo): Boolean {
        var n: AccessibilityNodeInfo? = node
        while (n != null) {
            if (n.isClickable && n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            n = n.parent
        }
        return false
    }

    private fun findByDescription(node: AccessibilityNodeInfo, words: List<String>): AccessibilityNodeInfo? {
        val d = node.contentDescription?.toString()?.lowercase()
        if (d != null && words.any { d == it }) return node
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            findByDescription(child, words)?.let { return it }
        }
        return null
    }

    override fun onInterrupt() {}
}
