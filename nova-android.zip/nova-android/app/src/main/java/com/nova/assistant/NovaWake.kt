package com.nova.assistant

import ai.picovoice.porcupine.PorcupineException
import ai.picovoice.porcupine.PorcupineManager
import ai.picovoice.porcupine.PorcupineManagerCallback
import android.content.Context
import android.os.Handler
import android.os.Looper
import java.io.File

/**
 * Asli wake word (Picovoice Porcupine): sirf "Nova" sunne ke liye halka model jo phone par hi chalta hai.
 * Baqi baat chit na sunta hai na kahin bhejta hai, aur battery bhi bohat kam khata hai.
 *
 * Chahiye: Picovoice AccessKey (muft, console.picovoice.ai) aur "Nova" ka custom wake word file (.ppn, Android).
 * Dono Nova ki Settings mein dete hain. Na hon to Nova purane tareeqe (Google speech) par chalta hai.
 */
class NovaWake(private val ctx: Context, private val onWake: () -> Unit) {

    companion object {
        fun keywordFile(ctx: Context) = File(ctx.filesDir, "nova.ppn")

        fun configured(ctx: Context): Boolean {
            val key = ctx.getSharedPreferences("nova", Context.MODE_PRIVATE).getString("pvkey", "").orEmpty().trim()
            return key.isNotEmpty() && keywordFile(ctx).exists()
        }
    }

    private var manager: PorcupineManager? = null
    private val main = Handler(Looper.getMainLooper())

    /** true agar sunna shuru ho gaya. */
    fun start(): Boolean {
        if (manager != null) return true
        val key = ctx.getSharedPreferences("nova", Context.MODE_PRIVATE).getString("pvkey", "").orEmpty().trim()
        if (key.isEmpty() || !keywordFile(ctx).exists()) return false
        return try {
            val m = PorcupineManager.Builder()
                .setAccessKey(key)
                .setKeywordPath(keywordFile(ctx).absolutePath)
                .setSensitivity(0.7f)
                .build(ctx, PorcupineManagerCallback { main.post { onWake() } })
            m.start()
            manager = m
            true
        } catch (e: PorcupineException) {
            NovaBus.add("Nova: Wake word shuru nahi hua (${e.message}). Purane tareeqe par chal raha hoon.")
            false
        } catch (e: Exception) {
            false
        }
    }

    /** Microphone chhorne ke liye (jab Google speech ya Nova ki awaaz chale). */
    fun stop() {
        try {
            manager?.stop()
            manager?.delete()
        } catch (e: Exception) {
            // koi baat nahi
        }
        manager = null
    }
}
