package com.nova.assistant

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.provider.AlarmClock
import android.provider.ContactsContract

/** Phone par asli kaam yahan hote hain. */
object NovaActions {

    /** Number 03xx se shuru ho to Pakistan (+92) lagta hai. Doosre mulk ke liye yeh badal dein. */
    private const val DEFAULT_COUNTRY_CODE = "92"

    fun normalize(raw: String): String {
        var d = raw.filter { it.isDigit() }
        if (d.startsWith("00")) d = d.substring(2)
        else if (d.startsWith("0")) d = DEFAULT_COUNTRY_CODE + d.substring(1)
        return d
    }

    /** Contacts mein naam dhoondta hai. (asli naam, number) lautata hai. */
    fun findNumber(ctx: Context, name: String): Pair<String, String>? {
        return try {
            val cursor = ctx.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER
                ),
                "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
                arrayOf("%$name%"),
                null
            )
            cursor?.use {
                if (it.moveToFirst()) Pair(it.getString(0), normalize(it.getString(1))) else null
            }
        } catch (e: SecurityException) {
            null
        }
    }

    /** Contacts ke naam (number nahi), AI ko sahi shakhs chunne mein madad ke liye. */
    fun contactNames(ctx: Context, limit: Int = 300): List<String> {
        return try {
            val names = LinkedHashSet<String>()
            ctx.contentResolver.query(
                ContactsContract.Contacts.CONTENT_URI,
                arrayOf(ContactsContract.Contacts.DISPLAY_NAME),
                "${ContactsContract.Contacts.HAS_PHONE_NUMBER} = 1",
                null,
                null
            )?.use {
                while (it.moveToNext() && names.size < limit) {
                    it.getString(0)?.let { n -> if (n.isNotBlank()) names.add(n) }
                }
            }
            names.toList()
        } catch (e: SecurityException) {
            emptyList()
        }
    }

    fun sendWhatsApp(ctx: Context, number: String, text: String): Boolean {
        val uri = Uri.parse("https://wa.me/$number?text=${Uri.encode(text)}")
        for (pkg in listOf("com.whatsapp", "com.whatsapp.w4b")) {
            val i = Intent(Intent.ACTION_VIEW, uri).setPackage(pkg).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            try {
                ctx.startActivity(i)
                return true
            } catch (e: ActivityNotFoundException) {
                // agla package try karein
            }
        }
        return false
    }

    /** Installed app ko naam se kholta hai, jaise "whatsapp", "camera", "settings". */
    fun openApp(ctx: Context, name: String): Boolean {
        val pm = ctx.packageManager
        val probe = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val n = name.lowercase().trim()
        if (n.isEmpty()) return false
        val match = pm.queryIntentActivities(probe, 0)
            .firstOrNull { it.loadLabel(pm).toString().lowercase().contains(n) } ?: return false
        val launch = pm.getLaunchIntentForPackage(match.activityInfo.packageName) ?: return false
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(launch)
        return true
    }

    fun call(ctx: Context, number: String, direct: Boolean) {
        val action = if (direct) Intent.ACTION_CALL else Intent.ACTION_DIAL
        ctx.startActivity(Intent(action, Uri.parse("tel:+$number")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    fun torch(ctx: Context, on: Boolean): Boolean {
        return try {
            val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return false
            cm.setTorchMode(id, on)
            true
        } catch (e: Exception) {
            false
        }
    }

    /**
     * Headphones / earbuds lage hain? Wired, USB, Bluetooth (A2DP/SCO/LE) aur hearing aid ginte hain.
     * Dhyan rahe: Android Bluetooth speaker ya gaari ke audio ko headphones se alag nahi dikha sakta.
     */
    fun headphonesConnected(ctx: Context): Boolean {
        return try {
            val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val types = mutableSetOf(
                AudioDeviceInfo.TYPE_WIRED_HEADSET,
                AudioDeviceInfo.TYPE_WIRED_HEADPHONES,
                AudioDeviceInfo.TYPE_USB_HEADSET,
                AudioDeviceInfo.TYPE_BLUETOOTH_A2DP,
                AudioDeviceInfo.TYPE_BLUETOOTH_SCO,
                AudioDeviceInfo.TYPE_HEARING_AID
            )
            if (Build.VERSION.SDK_INT >= 31) types.add(AudioDeviceInfo.TYPE_BLE_HEADSET)
            am.getDevices(AudioManager.GET_DEVICES_OUTPUTS).any { it.type in types }
        } catch (e: Exception) {
            false
        }
    }

    fun setAlarm(ctx: Context, hour: Int, minute: Int) {
        val i = Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, hour)
            .putExtra(AlarmClock.EXTRA_MINUTES, minute)
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    }

    fun setTimer(ctx: Context, seconds: Int) {
        val i = Intent(AlarmClock.ACTION_SET_TIMER)
            .putExtra(AlarmClock.EXTRA_LENGTH, seconds)
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    }

    /** mode: up, down, max ya mute. */
    fun volume(ctx: Context, mode: String): Boolean {
        return try {
            val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val s = AudioManager.STREAM_MUSIC
            val max = am.getStreamMaxVolume(s)
            when (mode) {
                "max" -> am.setStreamVolume(s, max, AudioManager.FLAG_SHOW_UI)
                "mute" -> am.setStreamVolume(s, 0, AudioManager.FLAG_SHOW_UI)
                "down" -> am.setStreamVolume(s, maxOf(0, am.getStreamVolume(s) - maxOf(1, max / 5)), AudioManager.FLAG_SHOW_UI)
                else -> am.setStreamVolume(s, minOf(max, am.getStreamVolume(s) + maxOf(1, max / 5)), AudioManager.FLAG_SHOW_UI)
            }
            true
        } catch (e: Exception) {
            false
        }
    }

    fun openUrl(ctx: Context, url: String) {
        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}
