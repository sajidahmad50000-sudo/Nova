package com.nova.assistant

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Nova ka dimaag: sunta hai, samajhta hai, bolta hai, kaam karta hai.
 * NovaService ke andar chalta hai, isliye screen band ya doosri app khuli ho tab bhi kaam karta hai.
 *
 * Do sunne ke tareeqe:
 *  - Wake word mode (Picovoice Porcupine configured ho): "Nova" par jaagta hai, hukm leta hai, phir so jata hai.
 *  - Aam mode: Google speech hamesha sunti hai aur sirf "Nova" se shuru hone wale jumle manti hai.
 *
 * say(roman, urdu): Urdu awaaz (ya cloud awaaz) ho to Urdu script wali line bolta hai, warna Roman Urdu.
 */
class NovaEngine(
    private val ctx: Context,
    private val onFatal: (String) -> Unit
) {
    private val main = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var wake: NovaWake? = null
    private var wakeMode = false
    private var running = false
    private var speaking = false
    private var errCount = 0
    private var busy = false   // AI se jawab ka intezar
    private var paused = false // headphones nahi lage, Nova so raha hai

    /** Agla jumla hukm ki jagah is function ko milta hai (jaise "haan/nahi" ya message ka matan). */
    private var pendingInput: ((String) -> Unit)? = null

    private val SLEEP_TEXT = "Headphones nahi lage, Nova so raha hai"

    private val jokes = listOf(
        "Doctor ne mareez se kaha, aap ko aaram ki zaroorat hai. Mareez bola, to bill kam kar dein, aaram wahin se aa jayega." to
            "ڈاکٹر نے مریض سے کہا، آپ کو آرام کی ضرورت ہے۔ مریض بولا، تو بل کم کر دیں، آرام وہیں سے آ جائے گا۔",
        "Bete ne kaha, abba main exam mein fail ho gaya. Abba bole, koi baat nahi, agle saal teacher ko fail kar denge." to
            "بیٹے نے کہا، ابا میں امتحان میں فیل ہو گیا۔ ابا بولے، کوئی بات نہیں، اگلے سال استاد کو فیل کر دیں گے۔"
    )

    private fun prefs() = ctx.getSharedPreferences("nova", Context.MODE_PRIVATE)
    private fun wakeRequired(): Boolean = prefs().getBoolean("wake", true) && !wakeMode

    // ---------- chalana aur rokna ----------

    fun start() {
        running = true
        errCount = 0
        busy = false
        wakeMode = false
        paused = !headphonesOk()
        if (NovaWake.configured(ctx)) {
            wake = NovaWake(ctx) { onWakeWord() }
            wakeMode = true
        }
        if (paused) {
            NovaBus.add("Nova: Headphones nahi lage, isliye so raha hoon. Headphones lagate hi jaag jaunga.")
            NovaBus.status(SLEEP_TEXT)
            return
        }
        if (wakeMode) {
            if (wake?.start() == true) {
                NovaBus.add("Nova: Wake word mode on hai. Sirf \"Nova\" sun kar jaagunga.")
                NovaBus.status("Nova ka intezar... \"Nova\" boliye")
            } else {
                wake = null
                wakeMode = false
                listen()
            }
        } else listen()
    }

    // ---------- headphones ----------

    private fun headphonesOk(): Boolean = !prefs().getBoolean("headonly", false) || NovaActions.headphonesConnected(ctx)

    /**
     * Headphones lagne, nikalne ya setting badalne par bulaya jata hai.
     * Nahi lage to Nova sunna band kar ke so jata hai, lagte hi dobara jaag jata hai.
     */
    fun recheck() {
        if (!running) return
        val ok = headphonesOk()
        if (!ok && !paused) {
            paused = true
            pendingInput = null
            busy = false
            main.removeCallbacksAndMessages(null)
            destroyRecognizer()
            wake?.stop()
            NovaBus.add("Nova: Headphones nahi lage, isliye so raha hoon.")
            NovaBus.status(SLEEP_TEXT)
        } else if (ok && paused) {
            paused = false
            NovaBus.add("Nova: Headphones lag gaye, sun raha hoon.")
            resume()
        }
    }

    fun stop() {
        running = false
        pendingInput = null
        main.removeCallbacksAndMessages(null)
        destroyRecognizer()
        wake?.stop()
        wake = null
        NovaApp.instance.stop()
    }

    // ---------- wake word ----------

    private fun onWakeWord() {
        if (!running || paused || speaking || busy) return
        wake?.stop()
        destroyRecognizer()
        NovaBus.add("Aap: Nova")
        execute(Command.Wake)
    }

    private fun idleWake() {
        if (paused) return
        destroyRecognizer()
        if (wake?.start() == true) NovaBus.status("Nova ka intezar... \"Nova\" boliye")
        else { wakeMode = false; listen() }   // wake word chala nahi, aam mode par wapas
    }

    /** Sunne ka agla qadam: wake mode mein so jao (jab koi hukm baaqi na ho), warna sunte raho. */
    private fun resume() {
        if (!running || paused) return
        if (wakeMode && pendingInput == null && !busy) idleWake() else listen()
    }

    /** Wake mode mein, jawab na milne par pending hukm kuch der baad khatam karke wapas so jata hai. */
    private fun expireLater(target: (String) -> Unit, ms: Long) {
        main.postDelayed({
            if (running && pendingInput === target) {
                pendingInput = null
                if (wakeMode) idleWake() else NovaBus.status(idleStatus())
            }
        }, ms)
    }

    // ---------- sunna ----------

    private fun destroyRecognizer() {
        recognizer?.destroy()
        recognizer = null
    }

    private fun idleStatus() =
        if (wakeRequired() && pendingInput == null) "Sun raha hoon... \"Nova\" boliye" else "Sun raha hoon..."

    private fun listen() {
        if (!running || paused || speaking || busy) return
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            onFatal("Is phone mein speech recognition nahi hai. Google app update karein.")
            return
        }
        wake?.stop()   // microphone Google speech ko do
        destroyRecognizer()
        val r = SpeechRecognizer.createSpeechRecognizer(ctx)
        r.setRecognitionListener(listener)
        recognizer = r
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            // en-IN Roman Urdu ko behtar pakadta hai. "Urdu mein sunein" on ho to ur-PK (Urdu script).
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, if (prefs().getBoolean("urdu", false)) "ur-PK" else "en-IN")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        }
        NovaBus.status(idleStatus())
        r.startListening(i)
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onPartialResults(partialResults: Bundle?) {
            val t = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (!t.isNullOrBlank()) NovaBus.status(t)
        }

        override fun onResults(results: Bundle?) {
            errCount = 0
            val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (text.isNullOrBlank()) { main.postDelayed({ resume() }, 200); return }
            val spoke = handle(text)
            if (!spoke) main.postDelayed({ resume() }, 200)
        }

        override fun onError(error: Int) {
            if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                onFatal("Microphone ki ijazat chahiye.")
                return
            }
            errCount++
            // Khamoshi (no match / timeout) normal hai, us par ginti nahi barhti.
            if (error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) errCount = 0
            if (errCount > 10) {
                onFatal("Sunne mein masla aa raha hai. Internet check karke dobara shuru karein.")
                return
            }
            val delay = if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1000L else 300L
            main.postDelayed({ resume() }, delay)
        }
    }

    // ---------- bolna ----------

    private fun say(roman: String, urdu: String? = null) {
        val text = if (urdu != null && NovaApp.instance.speaksUrdu()) urdu else roman
        NovaBus.add("Nova: $text")
        NovaBus.status("Nova bol raha hai")
        speaking = true
        wake?.stop()
        destroyRecognizer()
        NovaApp.instance.say(text) {
            speaking = false
            resume()
            if (wakeMode) pendingInput?.let { expireLater(it, 20000) }
        }
    }

    // ---------- hukm ----------

    /** true lautaye to Nova ne kuch bola hai (aur bolne ke baad khud dobara sunega). */
    private fun handle(raw: String): Boolean {
        val waiting = pendingInput
        if (waiting != null) {
            pendingInput = null
            NovaBus.add("Aap: $raw")
            waiting(CommandParser.stripWake(raw))
            return true
        }
        val local = CommandParser.parse(raw, wakeRequired()) ?: return false
        NovaBus.add("Aap: $raw")
        runCommand(raw, local)
        return true
    }

    /** Smart mode on ho to AI se samajhwata hai, warna seedha hukm chalata hai. Sirf "Nova" par AI nahi bulata. */
    private fun runCommand(raw: String, local: Command) {
        if (smartOn() && local !is Command.Wake) {
            busy = true
            destroyRecognizer()
            NovaBus.status("Soch raha hoon...")
            NovaBrain.ask(ctx, CommandParser.stripWake(raw), NovaActions.contactNames(ctx)) { result ->
                busy = false
                if (!running || paused) return@ask
                if (result == null) NovaBus.add("(AI se jawab nahi mila, seedha hukm istemal kar raha hoon.)")
                execute(result ?: local)
            }
        } else execute(local)
    }

    private fun smartOn(): Boolean {
        val p = prefs()
        return p.getBoolean("smart", false) && !p.getString("apikey", "").isNullOrBlank()
    }

    private fun callName(): String = prefs().getString("callname", "Boss").orEmpty().trim().ifEmpty { "Boss" }

    private fun urduName(name: String): String = if (name.equals("boss", ignoreCase = true)) "باس" else name

    /** "Nova" ke baad agla jumla bina dobara "Nova" kahe hukm mana jata hai, magar sirf kuch der. */
    private fun awaitFollowUp() {
        val follow: (String) -> Unit = { text ->
            runCommand(text, CommandParser.parse(text, false) ?: Command.Wake)
        }
        pendingInput = follow
        expireLater(follow, 18000)
    }

    private fun clock(pattern: String, urdu: Boolean): String =
        try {
            SimpleDateFormat(pattern, if (urdu) Locale("ur", "PK") else Locale("en", "PK")).format(Date())
        } catch (e: Exception) {
            SimpleDateFormat(pattern, Locale.ENGLISH).format(Date())
        }

    private fun durationText(sec: Int, urdu: Boolean): String {
        val h = sec / 3600
        val m = (sec % 3600) / 60
        val s = sec % 60
        val parts = mutableListOf<String>()
        if (h > 0) parts.add(if (urdu) "$h گھنٹہ" else "$h ghanta")
        if (m > 0) parts.add(if (urdu) "$m منٹ" else "$m minute")
        if (s > 0) parts.add(if (urdu) "$s سیکنڈ" else "$s second")
        return parts.joinToString(" ")
    }

    private fun execute(cmd: Command) {
        when (cmd) {
            Command.Wake -> {
                val name = callName()
                say("Ji, main yahan hoon. Bataiye $name, kya karna hai?", "جی، میں یہاں ہوں۔ بتائیے ${urduName(name)}، کیا کرنا ہے؟")
                awaitFollowUp()
            }
            Command.Hello -> say("Ji, main Nova hoon. Bataiye, kya karun?", "جی، میں نووا ہوں۔ بتائیے، کیا کروں؟")
            Command.Help -> say(
                "Main WhatsApp message bhej sakta hoon, call kar sakta hoon, koi bhi app khol sakta hoon, torch jala sakta hoon, alarm aur timer laga sakta hoon, awaaz kam zyada kar sakta hoon, YouTube, Google aur map khol sakta hoon, aur waqt, tareekh aur latifa suna sakta hoon.",
                "میں واٹس ایپ پیغام بھیج سکتا ہوں، کال کر سکتا ہوں، کوئی بھی ایپ کھول سکتا ہوں، ٹارچ جلا سکتا ہوں، الارم اور ٹائمر لگا سکتا ہوں، آواز کم زیادہ کر سکتا ہوں، یوٹیوب، گوگل اور نقشہ کھول سکتا ہوں، اور وقت، تاریخ اور لطیفہ سنا سکتا ہوں۔"
            )
            Command.TimeCmd -> say("Abhi " + clock("h:mm a", false) + " hue hain.", "ابھی " + clock("h:mm a", true) + " ہوئے ہیں۔")
            Command.DateCmd -> say("Aaj " + clock("EEEE, d MMMM yyyy", false) + " hai.", "آج " + clock("EEEE، d MMMM yyyy", true) + " ہے۔")
            Command.Joke -> jokes.random().let { say(it.first, it.second) }
            Command.OpenWhatsApp -> {
                if (launch { NovaActions.openApp(ctx, "whatsapp") }) say("WhatsApp on ho gaya hai.", "واٹس ایپ آن ہو گیا ہے۔")
                else say("WhatsApp khul nahi saka. Install hai aur background mein kholne ki ijazat di hai?", "واٹس ایپ کھل نہیں سکا۔ انسٹال ہے اور بیک گراؤنڈ میں کھولنے کی اجازت دی ہے؟")
            }
            is Command.OpenApp -> {
                if (launch { NovaActions.openApp(ctx, cmd.name) }) say("${cmd.name} khol diya.", "ایپ کھول دی۔")
                else say("${cmd.name} naam ki app nahi mili.", "اس نام کی ایپ نہیں ملی۔")
            }
            is Command.Torch -> {
                if (NovaActions.torch(ctx, cmd.on)) {
                    say(if (cmd.on) "Torch on ho gayi." else "Torch band ho gayi.", if (cmd.on) "ٹارچ آن ہو گئی۔" else "ٹارچ بند ہو گئی۔")
                } else say("Is phone mein torch nahi mili.", "اس فون میں ٹارچ نہیں ملی۔")
            }
            is Command.Alarm -> {
                if (cmd.hour < 0) {
                    say("Kitne baje ka alarm laun?", "کتنے بجے کا الارم لگاؤں؟")
                    pendingInput = { t ->
                        val c = CommandParser.parseClock(t)
                        if (c == null) say("Waqt samajh nahi aaya.", "وقت سمجھ نہیں آیا۔") else setAlarm(c.first, c.second)
                    }
                } else setAlarm(cmd.hour, cmd.minute)
            }
            is Command.Timer -> {
                if (cmd.seconds <= 0) {
                    say("Kitni der ka timer laun?", "کتنی دیر کا ٹائمر لگاؤں؟")
                    pendingInput = { t ->
                        val s = CommandParser.parseDuration(t)
                        if (s <= 0) say("Muddat samajh nahi aayi.", "مدت سمجھ نہیں آئی۔") else setTimer(s)
                    }
                } else setTimer(cmd.seconds)
            }
            is Command.Volume -> {
                if (NovaActions.volume(ctx, cmd.mode)) {
                    when (cmd.mode) {
                        "max" -> say("Awaaz poori kar di.", "آواز پوری کر دی۔")
                        "mute" -> say("Awaaz band kar di.", "آواز بند کر دی۔")
                        "down" -> say("Awaaz kam kar di.", "آواز کم کر دی۔")
                        else -> say("Awaaz barha di.", "آواز بڑھا دی۔")
                    }
                } else say("Awaaz badal nahi saka.", "آواز بدل نہیں سکا۔")
            }
            is Command.Call -> callPerson(cmd.name)
            is Command.Message -> messagePerson(cmd.name, cmd.body)
            is Command.Web -> {
                if (cmd.query.isEmpty()) {
                    if (cmd.kind == "maps") say("Kahan ka raasta chahiye?", "کہاں کا راستہ چاہیے؟") else say("Kya dhoondun?", "کیا ڈھونڈوں؟")
                    pendingInput = { q -> openWeb(cmd.kind, q) }
                } else openWeb(cmd.kind, cmd.query)
            }
            is Command.Chat -> say(cmd.reply, cmd.urdu.takeIf { it.isNotBlank() })
            is Command.Unknown -> say(
                "Maaf kijiye, samajh nahi aaya. Aap keh sakte hain: Nova, WhatsApp on karo.",
                "معاف کیجیے، سمجھ نہیں آیا۔ آپ کہہ سکتے ہیں: نووا، واٹس ایپ آن کرو۔"
            )
        }
    }

    /** Doosri app kholne ki koshish. Android band kare to exception aata hai, use yahan pakar lete hain. */
    private fun launch(block: () -> Boolean): Boolean =
        try { block() } catch (e: Exception) { false }

    private fun setAlarm(h: Int, m: Int) {
        val t = "$h:${"%02d".format(m)}"
        if (launch { NovaActions.setAlarm(ctx, h, m); true }) say("$t baje ka alarm laga diya.", "$t بجے کا الارم لگا دیا۔")
        else say("Alarm nahi laga saka.", "الارم نہیں لگا سکا۔")
    }

    private fun setTimer(sec: Int) {
        if (launch { NovaActions.setTimer(ctx, sec); true }) {
            say("${durationText(sec, false)} ka timer laga diya.", "${durationText(sec, true)} کا ٹائمر لگا دیا۔")
        } else say("Timer nahi laga saka.", "ٹائمر نہیں لگا سکا۔")
    }

    private fun openWeb(kind: String, q: String) {
        val enc = java.net.URLEncoder.encode(q, "UTF-8")
        val url = when (kind) {
            "youtube" -> "https://www.youtube.com/results?search_query=$enc"
            "maps" -> "https://www.google.com/maps/search/$enc"
            else -> "https://www.google.com/search?q=$enc"
        }
        if (launch { NovaActions.openUrl(ctx, url); true }) say("$q ke liye khol raha hoon.", "کھول رہا ہوں۔")
        else say("Browser khul nahi saka.", "براؤزر کھل نہیں سکا۔")
    }

    private fun callPerson(name: String) {
        val found = NovaActions.findNumber(ctx, name)
        if (found == null) { say("$name ka number contacts mein nahi mila.", "اس نام کا نمبر کانٹیکٹس میں نہیں ملا۔"); return }
        val canCall = ContextCompat.checkSelfPermission(ctx, Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
        if (launch { NovaActions.call(ctx, found.second, canCall); true }) say("${found.first} ko call kar raha hoon.", "${found.first} کو کال کر رہا ہوں۔")
        else say("Call shuru nahi ho saki.", "کال شروع نہیں ہو سکی۔")
    }

    private fun messagePerson(name: String, body: String) {
        val found = NovaActions.findNumber(ctx, name)
        if (found == null) { say("$name ka number contacts mein nahi mila.", "اس نام کا نمبر کانٹیکٹس میں نہیں ملا۔"); return }
        val (display, number) = found
        if (body.isEmpty()) {
            say("$display ko kya likhun?", "$display کو کیا لکھوں؟")
            pendingInput = { text -> confirmSend(display, number, text) }
        } else confirmSend(display, number, body)
    }

    private fun confirmSend(display: String, number: String, body: String) {
        // Awaaz sirf wahi matan parh sakti hai jo uski zabaan ki script mein ho. Baqi screen par likha jata hai.
        val readable = if (NovaApp.instance.speaksUrdu()) body.any { it.code in 0x0600..0x06FF } else body.all { it.code < 0x0600 }
        if (readable) {
            say("$display ko yeh message bhejun: $body. Haan ya nahi?", "$display کو یہ پیغام بھیجوں: $body۔ ہاں یا نہیں؟")
        } else {
            NovaBus.add("Message: $body")
            say("$display ke liye message tayyar hai, screen par likha hai. Bhejun? Haan ya nahi?", "$display کے لیے پیغام تیار ہے، سکرین پر لکھا ہے۔ بھیجوں؟ ہاں یا نہیں؟")
        }
        pendingInput = { answer ->
            val a = answer.trim()
            when {
                CommandParser.yes.containsMatchIn(a) || a.startsWith("ہاں") || a.startsWith("جی") -> sendNow(display, number, body)
                CommandParser.no.containsMatchIn(a) || a.startsWith("نہیں") -> say("Theek hai, message cancel kar diya.", "ٹھیک ہے، پیغام منسوخ کر دیا۔")
                else -> say("Samajh nahi aaya, isliye message cancel kar diya.", "سمجھ نہیں آیا، اس لیے پیغام منسوخ کر دیا۔")
            }
        }
    }

    private fun sendNow(display: String, number: String, body: String) {
        val autoSend = isAccessibilityOn()
        if (autoSend) NovaAccessibilityService.arm(display)
        val ok = launch { NovaActions.sendWhatsApp(ctx, number, body) }
        if (!ok) {
            say("WhatsApp khul nahi saka. Install hai aur background mein kholne ki ijazat di hai?", "واٹس ایپ کھل نہیں سکا۔ انسٹال ہے اور بیک گراؤنڈ میں کھولنے کی اجازت دی ہے؟")
            return
        }
        // Auto-send hone par WhatsApp se wapas aa kar accessibility service khud "message bhej diya" bolti hai.
        if (!autoSend) say("Message tayyar hai. Send dabayein, ya auto-send on kar lein.", "پیغام تیار ہے۔ بھیجیں دبائیں، یا آٹو سینڈ آن کر لیں۔")
        else {
            NovaBus.add("Nova: $display ko message bhej raha hoon.")
            resume()
        }
    }

    private fun isAccessibilityOn(): Boolean {
        val enabled = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return enabled.contains(ctx.packageName)
    }
}
