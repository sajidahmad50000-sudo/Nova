package com.nova.assistant

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat

/**
 * Phone restart hone par, agar Nova pehle chal raha tha, ek notification dikhata hai.
 * Android microphone wali service ko restart par khud shuru nahi hone deta, isliye notification dabane par
 * Nova khulta hai aur foran sunna shuru kar deta hai (MainActivity.onResume).
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        if (!ctx.getSharedPreferences("nova", Context.MODE_PRIVATE).getBoolean("enabled", false)) return

        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel("nova_boot", "Nova shuru karein", NotificationManager.IMPORTANCE_HIGH))
        }
        val open = PendingIntent.getActivity(
            ctx, 2,
            Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(ctx, "nova_boot")
            .setSmallIcon(R.drawable.ic_stat_nova)
            .setContentTitle("Nova taiyar hai")
            .setContentText("Sunna shuru karne ke liye yahan dabayein")
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        try {
            nm.notify(2, n)
        } catch (e: SecurityException) {
            // Notification ki ijazat na ho to kuch nahi kar sakte.
        }
    }
}
