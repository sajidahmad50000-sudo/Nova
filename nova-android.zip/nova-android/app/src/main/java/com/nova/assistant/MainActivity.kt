package com.nova.assistant

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.widget.doAfterTextChanged

/** Nova ki screen: shuru/band, ijazatein, settings, aur baat cheet ka record. Asli kaam NovaService karti hai. */
class MainActivity : AppCompatActivity() {

    private lateinit var status: TextView
    private lateinit var logView: TextView
    private lateinit var scroll: ScrollView
    private lateinit var micBtn: Button
    private lateinit var a11yBtn: Button
    private lateinit var overlayBtn: Button
    private lateinit var ppnStatus: TextView
    private lateinit var prefs: SharedPreferences

    /** Picovoice ki wake word file (.ppn) chunne ke liye. File app ke private folder mein copy hoti hai. */
    private val pickPpn = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri == null) return@registerForActivityResult
        try {
            contentResolver.openInputStream(uri)?.use { input ->
                NovaWake.keywordFile(this).outputStream().use { out -> input.copyTo(out) }
            }
            Toast.makeText(this, "Wake word file mil gayi. Nova band karke dobara shuru karein.", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "File parh nahi saka.", Toast.LENGTH_LONG).show()
        }
        render()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = getSharedPreferences("nova", Context.MODE_PRIVATE)
        status = findViewById(R.id.status)
        logView = findViewById(R.id.logView)
        scroll = findViewById(R.id.scroll)
        micBtn = findViewById(R.id.micBtn)
        a11yBtn = findViewById(R.id.a11yBtn)
        overlayBtn = findViewById(R.id.overlayBtn)
        ppnStatus = findViewById(R.id.ppnStatus)

        micBtn.setOnClickListener {
            if (NovaBus.running) {
                prefs.edit().putBoolean("enabled", false).apply()   // yaad rakhein ke aap ne khud roka hai
                NovaService.stop(this)
            } else ensurePermissionsThenStart()
        }
        a11yBtn.setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        overlayBtn.setOnClickListener {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        findViewById<Button>(R.id.batteryBtn).setOnClickListener {
            try {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_SETTINGS))
            }
        }
        findViewById<Button>(R.id.pickPpnBtn).setOnClickListener { pickPpn.launch(arrayOf("*/*")) }
        findViewById<Button>(R.id.testVoiceBtn).setOnClickListener { NovaApp.instance.sample() }
        findViewById<Button>(R.id.reportBtn).setOnClickListener { shareReport() }

        // Saaf sidhi settings: text boxes aur checkboxes seedha preferences mein save hote hain.
        bindText(R.id.nameEdit, "callname", "Boss")
        bindText(R.id.pvKeyEdit, "pvkey", "")
        bindText(R.id.keyEdit, "apikey", "")
        bindText(R.id.proxyEdit, "proxyurl", "")
        bindText(R.id.cloudKeyEdit, "cloudkey", "")
        bindCheck(R.id.wakeBox, "wake", true)
        bindCheck(R.id.urduBox, "urdu", false)
        findViewById<CheckBox>(R.id.headBox).apply {
            isChecked = prefs.getBoolean("headonly", false)
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean("headonly", checked).apply()
                NovaService.refresh(this@MainActivity)   // chalte hue Nova ko foran batao
            }
        }
        bindCheck(R.id.loudBox, "loud", true)
        bindCheck(R.id.cloudBox, "cloud", false)
        findViewById<CheckBox>(R.id.smartBox).apply {
            isChecked = prefs.getBoolean("smart", false)
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean("smart", checked).apply()
                if (checked && prefs.getString("apikey", "").isNullOrBlank()) {
                    Toast.makeText(this@MainActivity, "Pehle neeche Claude API key likhein.", Toast.LENGTH_LONG).show()
                }
            }
        }

        val settingsScroll = findViewById<ScrollView>(R.id.settingsScroll)
        settingsScroll.visibility = if (Settings.canDrawOverlays(this)) View.GONE else View.VISIBLE
        findViewById<Button>(R.id.settingsBtn).setOnClickListener {
            val show = settingsScroll.visibility != View.VISIBLE
            settingsScroll.visibility = if (show) View.VISIBLE else View.GONE
            if (show) fillVoices()
        }
        setupSeekBars()
        fillVoices()

        if (NovaBus.lines.isEmpty()) {
            NovaBus.add("Nova: Assalam o alaikum! Neeche \"Nova shuru karein\" dabayein, phir kahein: \"Nova, Sajid ko message karo main late aaunga\".")
        }
        NovaApp.instance.lastCrash()?.let {
            NovaBus.add("Nova: Pichli baar app band hui thi. Settings mein \"Masla bhejein\" se log bhej sakte hain.")
        }
    }

    override fun onResume() {
        super.onResume()
        NovaBus.listener = { render() }
        render()
        // Pehle chal raha tha (aur aap ne khud roka nahi) to khulte hi dobara shuru, jaise restart ke baad.
        val micOk = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (!NovaBus.running && micOk && prefs.getBoolean("enabled", false)) NovaService.start(this)
    }

    override fun onPause() {
        NovaBus.listener = null
        super.onPause()
    }

    private fun render() {
        micBtn.text = if (NovaBus.running) "Nova band karein" else "Nova shuru karein"
        status.text = if (NovaBus.running) NovaBus.statusText else "Nova band hai"
        logView.text = NovaBus.lines.joinToString("\n\n")
        scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
        overlayBtn.visibility = if (Settings.canDrawOverlays(this)) View.GONE else View.VISIBLE
        a11yBtn.text = if (isAccessibilityOn()) "WhatsApp auto-send: on hai" else "WhatsApp auto-send on karein"
        ppnStatus.text = if (NovaWake.keywordFile(this).exists()) "Wake word file maujood hai." else "File abhi nahi chuni."
    }

    private fun isAccessibilityOn(): Boolean {
        val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return enabled.contains(packageName)
    }

    // ---------- settings ke chhote madadgar ----------

    private fun bindText(id: Int, key: String, default: String) {
        val e = findViewById<EditText>(id)
        e.setText(prefs.getString(key, default))
        e.doAfterTextChanged { prefs.edit().putString(key, it?.toString()?.trim().orEmpty()).apply() }
    }

    private fun bindCheck(id: Int, key: String, default: Boolean) {
        val c = findViewById<CheckBox>(id)
        c.isChecked = prefs.getBoolean(key, default)
        c.setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean(key, checked).apply() }
    }

    private fun setupSeekBars() {
        val rate = findViewById<SeekBar>(R.id.rateSeek)
        val pitch = findViewById<SeekBar>(R.id.pitchSeek)
        // rate: 60..180 (progress 0..120), pitch: 70..150 (progress 0..80)
        rate.progress = prefs.getInt("rate", NovaApp.DEFAULT_RATE) - 60
        pitch.progress = prefs.getInt("pitch", NovaApp.DEFAULT_PITCH) - 70
        rate.setOnSeekBarChangeListener(seek { prefs.edit().putInt("rate", it + 60).apply() })
        pitch.setOnSeekBarChangeListener(seek { prefs.edit().putInt("pitch", it + 70).apply() })
    }

    private fun seek(onChange: (Int) -> Unit) = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { if (fromUser) onChange(p) }
        override fun onStartTrackingTouch(s: SeekBar?) {}
        override fun onStopTrackingTouch(s: SeekBar?) {}
    }

    private fun fillVoices() {
        val spinner = findViewById<Spinner>(R.id.voiceSpinner)
        val voices = NovaApp.instance.voiceList()
        val labels = listOf("Khud chunein (behtareen)") + voices.map { "${it.name}  (${it.locale.displayName})" }
        val adapter = ArrayAdapter(this, R.layout.spinner_item, labels)
        adapter.setDropDownViewResource(R.layout.spinner_item)
        spinner.onItemSelectedListener = null
        spinner.adapter = adapter
        val cur = prefs.getString("voice", "").orEmpty()
        spinner.setSelection(maxOf(0, voices.indexOfFirst { it.name == cur } + 1))
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, pos: Int, id: Long) {
                prefs.edit().putString("voice", if (pos == 0) "" else voices[pos - 1].name).apply()
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
    }

    /** Masla bhejein: baat cheet ka record aur aakhri crash, aap ke chune hue app (email, WhatsApp...) ko. */
    private fun shareReport() {
        val sb = StringBuilder()
        sb.append("Nova ${versionName()} | Android ${Build.VERSION.RELEASE} | ${Build.MANUFACTURER} ${Build.MODEL}\n\n")
        sb.append("--- Baat cheet ---\n").append(NovaBus.lines.takeLast(40).joinToString("\n")).append("\n\n")
        sb.append("--- Aakhri crash ---\n").append(NovaApp.instance.lastCrash() ?: "koi nahi")
        val send = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, sb.toString())
        startActivity(Intent.createChooser(send, "Masla bhejein"))
    }

    private fun versionName(): String = try {
        packageManager.getPackageInfo(packageName, 0).versionName ?: ""
    } catch (e: Exception) {
        ""
    }

    // ---------- ijazatein ----------

    private fun neededPermissions(): List<String> {
        val list = mutableListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.CALL_PHONE
        )
        if (Build.VERSION.SDK_INT >= 33) list.add(Manifest.permission.POST_NOTIFICATIONS)
        return list
    }

    private fun ensurePermissionsThenStart() {
        val missing = neededPermissions().filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isEmpty()) startNova() else ActivityCompat.requestPermissions(this, missing.toTypedArray(), 1)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            startNova()
        } else {
            Toast.makeText(this, "Microphone ki ijazat ke baghair Nova sun nahi sakta.", Toast.LENGTH_LONG).show()
        }
    }

    private fun startNova() {
        prefs.edit().putBoolean("enabled", true).apply()
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(
                this,
                "Doosri app kholne ke liye \"Display over other apps\" ki ijazat dein, phir dobara shuru karein.",
                Toast.LENGTH_LONG
            ).show()
        }
        NovaService.start(this)
    }
}
