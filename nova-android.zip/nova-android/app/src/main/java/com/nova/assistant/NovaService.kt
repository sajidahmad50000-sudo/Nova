package com.nova.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat

/**
 * Foreground service: Nova ko screen band ya doosri app khuli hone par bhi zinda rakhti hai.
 * Notification mein "Rokein" ka button hai.
 */
class NovaService : Service() {

    companion object {
        const val ACTION_STOP = "com.nova.assistant.STOP"
        private const val CHANNEL = "nova_listening"
        private const val NOTIF_ID = 1

        fun start(ctx: Context) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, NovaService::class.java))
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, NovaService::class.java))
        }

        /** Setting badli ho (jaise "sirf headphones par") to chalte hue Nova ko batata hai. */
        fun refresh(ctx: Context) {
            if (NovaBus.running) ctx.startService(Intent(ctx, NovaService::class.java).setAction(ACTION_REFRESH))
        }

        const val ACTION_REFRESH = "com.nova.assistant.REFRESH"
    }

    private var engine: NovaEngine? = null

    /** Headphones lagne ya nikalne par engine ko jagata ya sulata hai. */
    private val deviceCallback = object : AudioDeviceCallback() {
        override fun onAudioDevicesAdded(addedDevices: Array<out AudioDeviceInfo>?) { engine?.recheck() }
        override fun onAudioDevicesRemoved(removedDevices: Array<out AudioDeviceInfo>?) { engine?.recheck() }
    }
    private var callbackRegistered = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            getSharedPreferences("nova", Context.MODE_PRIVATE).edit().putBoolean("enabled", false).apply()
            stopSelf()
            return START_NOT_STICKY
        }
        if (intent?.action == ACTION_REFRESH) {
            engine?.recheck()
            return START_NOT_STICKY
        }
        createChannel()
        val type = if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE else 0
        try {
            ServiceCompat.startForeground(this, NOTIF_ID, buildNotification(), type)
        } catch (e: Exception) {
            NovaBus.add("Nova: Background mein shuru nahi ho saka. Nova kholkar dobara koshish karein.")
            stopSelf()
            return START_NOT_STICKY
        }
        if (engine == null) {
            engine = NovaEngine(this) { msg ->
                NovaBus.add("Nova: $msg")
                stopSelf()
            }.also { it.start() }
            NovaBus.add("Nova: Main sun raha hoon. \"Nova\" kehkar hukm dein.")
        }
        if (!callbackRegistered) {
            (getSystemService(Context.AUDIO_SERVICE) as AudioManager)
                .registerAudioDeviceCallback(deviceCallback, Handler(Looper.getMainLooper()))
            callbackRegistered = true
        }
        NovaBus.running = true
        NovaBus.notifyChanged()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        if (callbackRegistered) {
            (getSystemService(Context.AUDIO_SERVICE) as AudioManager).unregisterAudioDeviceCallback(deviceCallback)
            callbackRegistered = false
        }
        engine?.stop()
        engine = null
        NovaBus.running = false
        NovaBus.status("Nova band hai")
        super.onDestroy()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(CHANNEL, "Nova sun raha hai", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
    }

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, NovaService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_nova)
            .setContentTitle("Nova sun raha hai")
            .setContentText("\"Nova\" kehkar hukm dein")
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(0, "Rokein", stop)
            .build()
    }
}
