package com.nova.assistant

import android.content.Context
import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Claude AI se jumla samajhwata hai. Jawab hamesha ek Command hota hai (ya null agar AI tak na pahunch sakein).
 * Sirf woh jumle yahan aate hain jo "Nova" se shuru hon. Contacts ke sirf naam jate hain, number nahi.
 *
 * Do tareeqe:
 *  1. Seedha Anthropic (apni API key phone mein): zaati istemal ke liye.
 *  2. Apna server (Server URL + token): app doosron ko dene ya Play Store ke liye. server/nova-proxy.js dekhein.
 */
object NovaBrain {
    private const val API_URL = "https://api.anthropic.com/v1/messages"
    private const val MODEL = "claude-haiku-5-5"
    private val main = Handler(Looper.getMainLooper())

    private val ACTIONS = listOf(
        "message", "call", "open_whatsapp", "open_app", "torch", "alarm", "timer", "volume",
        "web_search", "youtube", "maps", "time", "date", "joke", "help", "chat", "unknown"
    )

    private const val SYSTEM = """You are Nova, a voice assistant on an Android phone.
The user speaks Roman Urdu, Urdu or English. The text comes from speech recognition and may contain mistakes; use context to correct them. The wake word "Nova" may appear at the start; ignore it.
Pick exactly one action with the nova_command tool.
- message: send a WhatsApp message. contact = the best match from CONTACTS (names may be in Urdu script or Latin letters; match by sound). If nothing matches, put the spoken name. body = what the user wants to send, in the user's own words and script, first person, not reworded. Leave body empty if the user did not say what to write.
- call: contact as above.
- open_whatsapp: just open WhatsApp.
- open_app: app = app name in Latin letters (camera, settings, chrome, ...).
- torch: on = true or false.
- alarm: hour (0-23) and minute. Use -1 for hour if the user gave no time.
- timer: seconds = total length in seconds. Use 0 if the user gave no length.
- volume: direction = up, down, max or mute.
- web_search / youtube / maps: query = what to look for. Leave empty if missing.
- time, date, joke, help: no extra fields.
- chat: any question or talk that needs an answer. Put the answer in reply: one or two short sentences in Roman Urdu using Latin letters only. Also put the same answer in reply_urdu, written in Urdu script.
- unknown: if you cannot tell what is wanted. Put a short clarifying question in reply (Roman Urdu, Latin letters) and in reply_urdu (Urdu script)."""

    fun ask(ctx: Context, text: String, contacts: List<String>, done: (Command?) -> Unit) {
        val p = ctx.getSharedPreferences("nova", Context.MODE_PRIVATE)
        val key = p.getString("apikey", "")?.trim().orEmpty()
        val proxy = p.getString("proxyurl", "")?.trim().orEmpty()
        Thread {
            val result = try {
                if (key.isEmpty()) null else call(key, proxy, text, contacts)
            } catch (e: Exception) {
                null
            }
            main.post { done(result) }
        }.start()
    }

    private fun prop(type: String, desc: String? = null): JSONObject =
        JSONObject().put("type", type).also { if (desc != null) it.put("description", desc) }

    private fun call(key: String, proxy: String, text: String, contacts: List<String>): Command? {
        val tool = JSONObject()
            .put("name", "nova_command")
            .put("description", "Run one phone action for the user.")
            .put(
                "input_schema", JSONObject()
                    .put("type", "object")
                    .put(
                        "properties", JSONObject()
                            .put("action", JSONObject().put("type", "string").put("enum", JSONArray(ACTIONS)))
                            .put("contact", prop("string"))
                            .put("body", prop("string"))
                            .put("app", prop("string"))
                            .put("query", prop("string"))
                            .put("on", prop("boolean"))
                            .put("hour", prop("integer"))
                            .put("minute", prop("integer"))
                            .put("seconds", prop("integer"))
                            .put("direction", JSONObject().put("type", "string").put("enum", JSONArray(listOf("up", "down", "max", "mute"))))
                            .put("reply", prop("string"))
                            .put("reply_urdu", prop("string", "The same reply written in Urdu script."))
                    )
                    .put("required", JSONArray().put("action"))
            )

        val system = SYSTEM + "\nCONTACTS: " + contacts.joinToString(" | ")
        val body = JSONObject()
            .put("model", MODEL)
            .put("max_tokens", 400)
            .put("system", system)
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", text)))
            .put("tools", JSONArray().put(tool))
            .put("tool_choice", JSONObject().put("type", "tool").put("name", "nova_command"))

        val conn = URL(if (proxy.isNotEmpty()) proxy else API_URL).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 8000
            conn.readTimeout = 15000
            conn.doOutput = true
            conn.setRequestProperty("content-type", "application/json")
            if (proxy.isNotEmpty()) {
                conn.setRequestProperty("x-nova-token", key)   // apna server: token
            } else {
                conn.setRequestProperty("x-api-key", key)      // seedha Anthropic: API key
                conn.setRequestProperty("anthropic-version", "2023-06-01")
            }
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            if (conn.responseCode !in 200..299) return null
            val resp = conn.inputStream.bufferedReader().use { it.readText() }
            val content = JSONObject(resp).getJSONArray("content")
            for (i in 0 until content.length()) {
                val block = content.getJSONObject(i)
                if (block.optString("type") == "tool_use") return toCommand(block.getJSONObject("input"))
            }
            return null
        } finally {
            conn.disconnect()
        }
    }

    internal fun toCommand(i: JSONObject): Command? {
        val contact = i.optString("contact", "").trim()
        val body = i.optString("body", "").trim()
        val query = i.optString("query", "").trim()
        val reply = i.optString("reply", "").trim()
        return when (i.optString("action")) {
            "message" -> if (contact.isEmpty()) null else Command.Message(contact, body)
            "call" -> if (contact.isEmpty()) null else Command.Call(contact)
            "open_whatsapp" -> Command.OpenWhatsApp
            "open_app" -> i.optString("app", "").trim().let { if (it.isEmpty()) null else Command.OpenApp(it) }
            "torch" -> Command.Torch(i.optBoolean("on", true))
            "alarm" -> Command.Alarm(i.optInt("hour", -1), i.optInt("minute", 0))
            "timer" -> Command.Timer(i.optInt("seconds", 0))
            "volume" -> Command.Volume(i.optString("direction", "up"))
            "web_search" -> Command.Web("google", query)
            "youtube" -> if (query.isEmpty()) Command.OpenApp("youtube") else Command.Web("youtube", query)
            "maps" -> Command.Web("maps", query)
            "time" -> Command.TimeCmd
            "date" -> Command.DateCmd
            "joke" -> Command.Joke
            "help" -> Command.Help
            "chat", "unknown" -> if (reply.isEmpty()) null else Command.Chat(reply, i.optString("reply_urdu", "").trim())
            else -> null
        }
    }
}
