package com.nova.assistant

sealed class Command {
    object Hello : Command()
    /** Sirf "Nova" bola gaya, hukm abhi baaqi hai. */
    object Wake : Command()
    object Help : Command()
    object TimeCmd : Command()
    object DateCmd : Command()
    object Joke : Command()
    object OpenWhatsApp : Command()
    data class Message(val name: String, val body: String) : Command()
    data class Call(val name: String) : Command()
    data class Torch(val on: Boolean) : Command()
    /** kind: google, youtube ya maps. query khali ho sakti hai. */
    data class Web(val kind: String, val query: String) : Command()
    data class OpenApp(val name: String) : Command()
    /** hour -1 ka matlab waqt nahi bataya gaya. */
    data class Alarm(val hour: Int, val minute: Int) : Command()
    /** seconds 0 ka matlab muddat nahi batayi gayi. */
    data class Timer(val seconds: Int) : Command()
    /** mode: up, down, max ya mute. */
    data class Volume(val mode: String) : Command()
    data class Unknown(val text: String) : Command()
    /** AI ka seedha jawab, jo Nova bas bol deta hai. */
    data class Chat(val reply: String, val urdu: String = "") : Command()
}

/**
 * Roman Urdu / English jumlon ko Command mein badalta hai (bina AI ke).
 * Naya hukm jorna ho to parse() mein ek regex aur NovaEngine.execute() mein ek branch add karein.
 */
object CommandParser {
    private val IC = RegexOption.IGNORE_CASE

    private val wake = Regex("""^(?:(?:hey|hi|ok|okay|hello)\s*,?\s*)?(?:(?:nova|nuva|nora|nawa)\b|نووا|نوا|نوآ)[\s,:!.\-،]*""", IC)
    private val hasWake = Regex("""(?:\b(?:nova|nuva|nora|nawa)\b|نووا|نوا|نوآ)""", IC)

    private val msgUrdu = Regex(
        """^(.+?)\s+(?:ko|ke liye|kay liye)\s+(?:whats\s?app\s+)?(?:message|msg|massage|mesej|sms|text)(?:\s+(?:karo|kar\s?do|kardo|kr\s?do|kro|bhejo|bhej\s?do|send|likho|likh\s?do))?\s*(.*)$""", IC
    )
    private val msgEnglish = Regex(
        """^(?:send\s+)?(?:a\s+)?(?:whats\s?app\s+)?(?:message|msg|text)\s+(?:to\s+)?(\S+)\s*(?:saying|that|:)?\s*(.*)$""", IC
    )
    private val msgUrduScript = Regex(
        """^(.+?)\s+(?:کو|کے لیے|کے لئے)\s+(?:میسج|مسیج|پیغام)\s*(?:کرو|کر دو|بھیجو|بھیج دو)?\s*(.*)$"""
    )
    private val callUrdu = Regex("""^(.+?)\s+(?:ko\s+)?(?:call|phone|fone)\b.*$""", IC)
    private val callEnglish = Regex("""^(?:call|phone)\s+(?:to\s+)?(.+)$""", IC)
    private val torchWord = Regex("""\b(?:torch|flash\s?light|tourch)\b""", IC)
    private val offWord = Regex("""\b(?:band|bund|off|bujha|bujhao|bujhado)\b""", IC)
    private val alarmWord = Regex("""\balarm\b""", IC)
    private val timerWord = Regex("""\b(?:timer|countdown)\b""", IC)
    private val volumeWord = Regex("""\b(?:awaaz|avaz|volume)\b""", IC)
    private val volMax = Regex("""\b(?:full|max|maximum|poori|pura)\b""", IC)
    private val volMute = Regex("""\b(?:mute|khamosh|silent)\b""", IC)
    private val volDown = Regex("""\b(?:kam|down|ghata|ghatao|halki|dheemi|low)\b""", IC)
    private val whatsapp = Regex("""whats\s?app""", IC)
    private val youtube = Regex("""you\s?tube""", IC)
    private val maps = Regex("""\b(?:map|maps|raasta|rasta|directions?)\b""", IC)
    private val search = Regex("""\b(?:search|dhoondo|dhundo|dhoondh|talash|google)\b""", IC)
    private val timeW = Regex("""\b(?:time|waqt|samay|baje)\b""", IC)
    private val dateW = Regex("""\b(?:date|tareekh|tarikh|kya din|aaj kya din)\b""", IC)
    private val jokeW = Regex("""\b(?:latifa|latifay|joke|hasao|hansao)\b""", IC)
    private val helpW = Regex("""\b(?:help|madad|kya kar sakte|kya kar sakta|kya kya)\b""", IC)
    private val helloW = Regex("""\b(?:salam|salaam|assalam\w*|hello|hi|hey)\b""", IC)
    private val openApp1 = Regex("""^(.+?)\s+(?:kholo|khol\s?do|kholiye|open\s?karo|open\s?kar\s?do|chalao|start\s?karo|on\s?karo)$""", IC)
    private val openApp2 = Regex("""^open\s+(.+)$""", IC)
    private val stopWords = Regex(
        """\b(?:google|youtube|you tube|map|maps|raasta|rasta|directions?|search|karo|kar|do|kardo|dhoondo|dhundo|dhoondh|talash|par|pe|per|mein|me|for|on|please|dikhao|dikha|chalao|sunao|kholo|khol|nova)\b""", IC
    )

    val yes = Regex("""^(?:haan|han|ha|yes|ji|ji haan|bhejo|bhej do|send|theek hai|ok|okay|kar do|kardo)\b""", IC)
    val no = Regex("""^(?:nahi|nahin|no|na|cancel|mat|rehne do|ruk)\b""", IC)

    fun stripWake(t: String): String = t.replace(wake, "").trim()

    private fun clean(t: String) = t.lowercase().replace(Regex("[.,!?]"), " ").replace(Regex("\\s+"), " ").trim()

    private fun query(n: String) = n.replace(stopWords, " ").replace(Regex("\\s+"), " ").trim()

    /** "7 baje", "7:30 subah", "shaam 6 baje" se (ghanta, minute). Samajh na aaye to null. */
    fun parseClock(text: String): Pair<Int, Int>? {
        val n = clean(text)
        val m = Regex("""(\d{1,2})(?:[:.](\d{2}))?""").find(n) ?: return null
        var h = m.groupValues[1].toInt()
        val min = m.groupValues[2].ifEmpty { "0" }.toInt()
        if (h > 23 || min > 59) return null
        val pm = Regex("""\b(?:sham|shaam|raat|dopahar|pm)\b""").containsMatchIn(n)
        val am = Regex("""\b(?:subah|savere|sawere|fajr|am)\b""").containsMatchIn(n)
        if (pm && h < 12) h += 12
        if (am && h == 12) h = 0
        return Pair(h, min)
    }

    /** "10 minute", "2 ghante 5 minute", "30 second" ko seconds mein badalta hai. 0 matlab kuch nahi mila. */
    fun parseDuration(text: String): Int {
        val n = clean(text)
        var sec = 0
        Regex("""(\d+)\s*(ghanta|ghante|ghanty|hour|hours|hr|minute|minutes|min|mint|second|seconds|sec)""").findAll(n).forEach {
            val v = it.groupValues[1].toInt()
            val u = it.groupValues[2]
            sec += when {
                u.startsWith("h") || u.startsWith("gh") -> v * 3600
                u.startsWith("m") -> v * 60
                else -> v
            }
        }
        return sec
    }

    /** null ka matlab: "Nova" nahi suna, is jumle ko nazar-andaz karein. */
    fun parse(raw: String, wakeRequired: Boolean): Command? {
        val t = raw.replace(Regex("\\s+"), " ").trim()
        if (t.isEmpty()) return null
        if (wakeRequired && !hasWake.containsMatchIn(t)) return null
        val c = stripWake(t)
        val n = clean(c)
        if (n.isEmpty()) return Command.Wake

        (msgUrdu.find(c) ?: msgEnglish.find(c) ?: msgUrduScript.find(c))?.let { m ->
            val name = m.groupValues[1].replace(Regex("^whats\\s?app\\s+(?:par|pe|per)\\s+", IC), "").trim()
            return Command.Message(name, m.groupValues[2].trim())
        }
        (callUrdu.find(c) ?: callEnglish.find(c))?.let { m ->
            return Command.Call(m.groupValues[1].trim())
        }
        if (alarmWord.containsMatchIn(n)) {
            val clock = parseClock(n)
            return if (clock == null) Command.Alarm(-1, -1) else Command.Alarm(clock.first, clock.second)
        }
        if (timerWord.containsMatchIn(n)) return Command.Timer(parseDuration(n))
        if (volumeWord.containsMatchIn(n)) {
            val mode = when {
                volMax.containsMatchIn(n) -> "max"
                volMute.containsMatchIn(n) -> "mute"
                volDown.containsMatchIn(n) -> "down"
                else -> "up"
            }
            return Command.Volume(mode)
        }
        if (torchWord.containsMatchIn(n)) return Command.Torch(!offWord.containsMatchIn(n))
        if (whatsapp.containsMatchIn(n)) return Command.OpenWhatsApp
        if (youtube.containsMatchIn(n)) {
            val q = query(n)
            return if (q.isEmpty()) Command.OpenApp("youtube") else Command.Web("youtube", q)
        }
        if (maps.containsMatchIn(n)) return Command.Web("maps", query(n))
        if (search.containsMatchIn(n)) return Command.Web("google", query(n))
        if (timeW.containsMatchIn(n)) return Command.TimeCmd
        if (dateW.containsMatchIn(n)) return Command.DateCmd
        if (jokeW.containsMatchIn(n)) return Command.Joke
        if (helpW.containsMatchIn(n)) return Command.Help
        if (helloW.containsMatchIn(n)) return Command.Hello
        (openApp1.find(n) ?: openApp2.find(n))?.let { m -> return Command.OpenApp(m.groupValues[1].trim()) }
        return Command.Unknown(c)
    }
}
