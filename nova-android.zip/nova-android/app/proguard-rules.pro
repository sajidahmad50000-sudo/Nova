# Nova: release build mein shrinking abhi band hai (build.gradle.kts mein isMinifyEnabled = false).
# On karne se pehle ye rules rakhein.
-keep class ai.picovoice.** { *; }
-keep class com.nova.assistant.** { *; }
